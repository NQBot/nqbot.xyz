#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Threading;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.PhillyFranksTools
{
    /// <summary>
    /// PFHistoricalDownloader - Downloads historical minute and tick data to CSV files
    /// Uses NinjaTrader.Data.BarsRequest API for programmatic data retrieval
    /// </summary>
    [CategoryOrder("Download", 1)]
    [CategoryOrder("Output", 2)]
    [CategoryOrder("Advanced", 3)]
    public class PFHistoricalDownloader : Indicator
{
    #region Constants
    private const bool ENABLE_TEST_MODE = true; // Set to true for 3-day testing
    private const int THROTTLE_MS = 350; // Delay between chunks to be polite to provider
    private const int MAX_RETRIES = 3;
    #endregion

    #region Private Fields
    private bool isRunning = false;
    private DispatcherTimer downloadTimer;
    private Queue<ChunkRequest> pendingChunks;
    private int totalChunks = 0;
    private int completedChunks = 0;
    private StreamWriter minuteWriter;
    private StreamWriter tickWriter;
    private readonly object writeLock = new object();
    private string currentStatus = "Ready";
    private int minuteBarCount = 0;
    private int tickCount = 0;
    #endregion

    #region Enums
    public enum CsvTimeZoneType
    {
        [Display(Name = "UTC")]
        Utc,
        [Display(Name = "Local")]
        Local
    }
    #endregion

    #region Helper Classes
    private class ChunkRequest
    {
        public DateTime From { get; set; }
        public DateTime To { get; set; }
        public BarsPeriod Period { get; set; }
        public TradingHours TradingHours { get; set; }
        public bool IsTickData { get; set; }
        public int ChunkIndex { get; set; }
        public int TotalChunks { get; set; }
    }
    #endregion

    #region Properties

    #region Download Category
    [Display(Name = "Days Back", Description = "Number of days of historical data to download", 
        Order = 1, GroupName = "Download")]
    [Range(1, 365)]
    public int DaysBack { get; set; } = 365;

    [Display(Name = "Include Minutes", Description = "Download minute data", 
        Order = 2, GroupName = "Download")]
    public bool IncludeMinutes { get; set; } = true;

    [Display(Name = "Minute Interval", Description = "Minute bar interval", 
        Order = 3, GroupName = "Download")]
    [TypeConverter(typeof(MinuteIntervalConverter))]
    public int MinuteInterval { get; set; } = 1;

    [Display(Name = "Include Ticks", Description = "Download tick data", 
        Order = 4, GroupName = "Download")]
    public bool IncludeTicks { get; set; } = true;

    [Display(Name = "Trading Hours Template", Description = "Optional trading hours template name (leave empty for instrument default)", 
        Order = 5, GroupName = "Download")]
    public string TradingHoursTemplate { get; set; } = string.Empty;

    [Display(Name = "Start Download", Description = "Click to start the download process", 
        Order = 6, GroupName = "Download")]
    public bool StartDownload
    {
        get { return false; }
        set
        {
            if (value && !isRunning)
            {
                BeginDownload();
            }
            else if (value && isRunning)
            {
                Status = "Already running...";
            }
        }
    }
    #endregion

    #region Output Category
    [XmlIgnore]
    [Display(Name = "Output Folder", Description = "Folder where CSV files will be saved", 
        Order = 1, GroupName = "Output")]
    [PropertyEditor("NinjaTrader.Gui.Tools.FilePathEditor")]
    public string OutputFolder { get; set; } = @"C:\Temp\HistoricalData";

    [Browsable(false)]
    public string OutputFolderSerialize
    {
        get { return OutputFolder; }
        set { OutputFolder = value; }
    }

    [Display(Name = "Append to Files", Description = "Append to existing CSV files instead of overwriting", 
        Order = 2, GroupName = "Output")]
    public bool AppendToFiles { get; set; } = false;

    [Display(Name = "CSV Time Zone", Description = "Time zone for CSV timestamps", 
        Order = 3, GroupName = "Output")]
    public CsvTimeZoneType CsvTimeZone { get; set; } = CsvTimeZoneType.Utc;

    [Display(Name = "Status", Description = "Current download status", 
        Order = 4, GroupName = "Output")]
    [ReadOnly(true)]
    public string Status
    {
        get { return currentStatus; }
        private set
        {
            currentStatus = value;
            // Note: Property change notification not available in NinjaScript context
        }
    }
    #endregion

    #region Advanced Category
    [Display(Name = "Chunk Days", Description = "Days per request chunk (smaller values are safer for provider limits)", 
        Order = 1, GroupName = "Advanced")]
    [Range(1, 90)]
    public int ChunkDays { get; set; } = 30;
    #endregion

    #endregion

    #region NinjaScript Methods

    protected override void OnStateChange()
    {
        if (State == State.SetDefaults)
        {
            Description = "Downloads historical minute and tick data to CSV files using BarsRequest API";
            Name = "PFHistoricalDownloader";
            Calculate = Calculate.OnBarClose;
            IsOverlay = true;
            DisplayInDataBox = false;
            DrawOnPricePanel = false;
            PaintPriceMarkers = false;
            ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
            IsSuspendedWhileInactive = false;
        }
        else if (State == State.Configure)
        {
            // Validation
            if (!IncludeMinutes && !IncludeTicks)
            {
                Log("Error: Must enable at least one data type (Minutes or Ticks)", LogLevel.Error);
                Status = "Error: No data types selected";
                return;
            }

            if (!IsValidMinuteInterval(MinuteInterval))
            {
                Log($"Error: Invalid minute interval {MinuteInterval}. Must be 1, 5, or 15", LogLevel.Error);
                Status = "Error: Invalid minute interval";
                return;
            }
        }
        else if (State == State.DataLoaded)
        {
            Print("OnStateChange: DataLoaded - Initializing timer");
            
            try
            {
                // Initialize timer for chunked downloads
                downloadTimer = new DispatcherTimer(DispatcherPriority.Background)
                {
                    Interval = TimeSpan.FromMilliseconds(THROTTLE_MS)
                };
                downloadTimer.Tick += OnDownloadTimerTick;
                
                Print($"Timer initialized successfully with {THROTTLE_MS}ms interval");
            }
            catch (Exception ex)
            {
                Print($"Error initializing timer: {ex}");
                downloadTimer = null;
            }
            
            Print($"Instrument: {Instrument?.FullName ?? "null"}");
            Print($"MasterInstrument: {Instrument?.MasterInstrument?.Name ?? "null"}");
            
            Status = "Ready";
        }
        else if (State == State.Terminated)
        {
            CleanupResources();
        }
    }

    protected override void OnBarUpdate()
    {
        // No real-time processing needed
    }

    #endregion

    #region Download Engine

    private void BeginDownload()
    {
        if (isRunning)
        {
            Status = "Already running...";
            return;
        }

        try
        {
            Print("BeginDownload: Starting...");
            
            // Validate output folder
            if (string.IsNullOrWhiteSpace(OutputFolder))
            {
                Status = "Error: Output folder not specified";
                Print("Error: Output folder is null or empty");
                return;
            }

            Print($"Output folder: {OutputFolder}");
            EnsureFolder(OutputFolder);

            // Reset counters
            minuteBarCount = 0;
            tickCount = 0;
            completedChunks = 0;
            
            Print("Building chunk queue...");
            
            // Build chunk queue
            BuildChunkQueue();
            
            if (pendingChunks == null || pendingChunks.Count == 0)
            {
                Status = "Error: No chunks to download";
                Print("Error: pendingChunks is null or empty");
                return;
            }

            totalChunks = pendingChunks.Count;
            Print($"Total chunks to process: {totalChunks}");
            
            isRunning = true;
            
            // Initialize CSV files
            Print("Initializing CSV files...");
            InitializeCsvFiles();
            Print("CSV files initialized successfully");
            
            Status = $"Starting download of {totalChunks} chunks...";
            Print($"PFHistoricalDownloader: Starting download for {Instrument?.FullName ?? "Unknown"}, {totalChunks} chunks");
            
            // Start the download timer
            if (downloadTimer != null)
            {
                downloadTimer.Start();
                Print("Download timer started");
            }
            else
            {
                Print("Error: downloadTimer is null - using direct processing instead");
                
                // Fallback: Process chunks directly without timer
                Status = "Processing chunks directly (no timer)...";
                ProcessNextChunkDirect();
            }
        }
        catch (Exception ex)
        {
            Status = $"Error starting download: {ex.Message}";
            Print($"PFHistoricalDownloader Error in BeginDownload: {ex}");
            CleanupDownload();
        }
    }

    private void BuildChunkQueue()
    {
        pendingChunks = new Queue<ChunkRequest>();
        
        DateTime endTime = DateTime.Now;
        DateTime startTime = ENABLE_TEST_MODE ? endTime.AddDays(-3) : endTime.AddDays(-DaysBack);
        
        // Get trading hours
        TradingHours tradingHours = GetTradingHours();
        
        // Build chunks
        List<(DateTime from, DateTime to)> dateRanges = BuildDateRanges(startTime, endTime);
        
        int chunkIndex = 0;
        foreach (var range in dateRanges)
        {
            if (IncludeMinutes)
            {
                var period = new BarsPeriod
                {
                    BarsPeriodType = BarsPeriodType.Minute,
                    Value = MinuteInterval
                };
                
                pendingChunks.Enqueue(new ChunkRequest
                {
                    From = range.from,
                    To = range.to,
                    Period = period,
                    TradingHours = tradingHours,
                    IsTickData = false,
                    ChunkIndex = ++chunkIndex,
                    TotalChunks = dateRanges.Count * (IncludeMinutes ? 1 : 0) + (IncludeTicks ? 1 : 0)
                });
            }
            
            if (IncludeTicks)
            {
                var period = new BarsPeriod
                {
                    BarsPeriodType = BarsPeriodType.Tick,
                    Value = 1
                };
                
                pendingChunks.Enqueue(new ChunkRequest
                {
                    From = range.from,
                    To = range.to,
                    Period = period,
                    TradingHours = tradingHours,
                    IsTickData = true,
                    ChunkIndex = ++chunkIndex,
                    TotalChunks = dateRanges.Count * (IncludeMinutes ? 1 : 0) + (IncludeTicks ? 1 : 0)
                });
            }
        }
    }

    private List<(DateTime from, DateTime to)> BuildDateRanges(DateTime start, DateTime end)
    {
        var ranges = new List<(DateTime, DateTime)>();
        DateTime current = start;
        
        Print($"BuildDateRanges: start={start:yyyy-MM-dd HH:mm}, end={end:yyyy-MM-dd HH:mm}, ChunkDays={ChunkDays}");
        
        while (current < end)
        {
            DateTime chunkEnd = current.AddDays(ChunkDays);
            if (chunkEnd > end)
                chunkEnd = end;
                
            ranges.Add((current, chunkEnd));
            Print($"Added range: {current:yyyy-MM-dd HH:mm} to {chunkEnd:yyyy-MM-dd HH:mm}");
            
            current = chunkEnd.AddMinutes(1); // Avoid overlap by 1 minute instead of 1 second
        }
        
        Print($"BuildDateRanges complete: {ranges.Count} ranges created");
        return ranges;
    }

    private TradingHours GetTradingHours()
    {
        if (!string.IsNullOrWhiteSpace(TradingHoursTemplate))
        {
            try
            {
                var th = TradingHours.Get(TradingHoursTemplate);
                if (th != null)
                {
                    Print($"Using trading hours template: {TradingHoursTemplate}");
                    return th;
                }
            }
            catch (Exception ex)
            {
                Print($"Could not load trading hours template '{TradingHoursTemplate}': {ex.Message}");
            }
        }
        
        // Use instrument's default
        return Instrument.MasterInstrument.TradingHours;
    }

    private void OnDownloadTimerTick(object sender, EventArgs e)
    {
        if (pendingChunks == null || pendingChunks.Count == 0)
        {
            CompleteDownload();
            return;
        }

        var chunk = pendingChunks.Dequeue();
        RequestChunk(chunk);
    }

    private void ProcessNextChunkDirect()
    {
        if (pendingChunks == null || pendingChunks.Count == 0)
        {
            CompleteDownload();
            return;
        }

        var chunk = pendingChunks.Dequeue();
        Print($"Processing chunk directly: {chunk.ChunkIndex}/{totalChunks}");
        RequestChunk(chunk);
    }

    private void RequestChunk(ChunkRequest chunk)
    {
        try
        {
            string dataType = chunk.IsTickData ? "Tick" : $"{chunk.Period.Value}m";
            Status = $"{dataType}: {chunk.ChunkIndex}/{totalChunks} chunks ({completedChunks} completed)";
            
            Print($"Requesting {dataType} data: {chunk.From:yyyy-MM-dd HH:mm} to {chunk.To:yyyy-MM-dd HH:mm}");
            Print($"Instrument: {Instrument.FullName}, Period: {chunk.Period.BarsPeriodType} {chunk.Period.Value}");
            
            var request = new BarsRequest(Instrument, chunk.From, chunk.To)
            {
                BarsPeriod = chunk.Period,
                TradingHours = chunk.TradingHours
            };

            // Add debug info about the request
            Print($"BarsRequest created - From: {chunk.From}, To: {chunk.To}, TradingHours: {request.TradingHours?.Name}");

            request.Request((barsRequest, errorCode, errorText) =>
            {
                Print($"BarsRequest callback - ErrorCode: {errorCode}, ErrorText: {errorText}");
                if (barsRequest?.Bars != null)
                {
                    Print($"Received {barsRequest.Bars.Count} bars for {dataType}");
                }
                else
                {
                    Print($"No bars received - BarsRequest.Bars is null");
                }
                
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    HandleBarsRequestComplete(barsRequest, errorCode, errorText, chunk);
                }));
            });
        }
        catch (Exception ex)
        {
            Print($"Error requesting chunk: {ex}");
            Status = $"Error requesting data: {ex.Message}";
            HandleChunkError(chunk);
        }
    }

    private void HandleBarsRequestComplete(BarsRequest request, ErrorCode errorCode, string errorText, ChunkRequest chunk)
    {
        try
        {
            completedChunks++;
            string dataType = chunk.IsTickData ? "Tick" : $"{chunk.Period.Value}m";
            
            Print($"HandleBarsRequestComplete - {dataType} chunk {chunk.ChunkIndex}");
            Print($"ErrorCode: {errorCode}, ErrorText: {errorText ?? "none"}");
            
            if (errorCode != ErrorCode.NoError)
            {
                Print($"BarsRequest error for {dataType}: {errorCode} - {errorText}");
                Status = $"Error: {errorCode} - {errorText}";
                HandleChunkError(chunk);
                return;
            }

            if (request?.Bars != null)
            {
                Print($"Received {request.Bars.Count} bars for {dataType}");
                
                if (request.Bars.Count > 0)
                {
                    if (chunk.IsTickData)
                    {
                        WriteTickData(request.Bars, chunk);
                        tickCount += request.Bars.Count;
                        Print($"Wrote {request.Bars.Count} ticks. Total ticks: {tickCount}");
                    }
                    else
                    {
                        WriteMinuteData(request.Bars, chunk);
                        minuteBarCount += request.Bars.Count;
                        Print($"Wrote {request.Bars.Count} minute bars. Total bars: {minuteBarCount}");
                    }
                }
                else
                {
                    Print($"No data returned for {dataType} chunk {chunk.ChunkIndex} (empty bars collection)");
                }
            }
            else
            {
                Print($"No bars received for {dataType} chunk {chunk.ChunkIndex} - request.Bars is null");
            }
            
            Print($"Completed chunks: {completedChunks}/{totalChunks}");
            
            // If using direct processing (no timer), process next chunk
            if (downloadTimer == null && pendingChunks != null && pendingChunks.Count > 0)
            {
                Print("Timer is null, scheduling next chunk directly");
                // Add a small delay to be polite to the provider
                System.Threading.Thread.Sleep(THROTTLE_MS);
                ProcessNextChunkDirect();
            }
        }
        catch (Exception ex)
        {
            Print($"Error processing bars response: {ex}");
            Status = $"Error processing data: {ex.Message}";
        }
    }

    private void HandleChunkError(ChunkRequest chunk)
    {
        // For now, just continue with next chunk
        // Could implement retry logic here if needed
        Print($"Chunk {chunk.ChunkIndex} failed, continuing...");
    }

    private void CompleteDownload()
    {
        downloadTimer.Stop();
        
        lock (writeLock)
        {
            minuteWriter?.Flush();
            minuteWriter?.Close();
            minuteWriter = null;
            
            tickWriter?.Flush();
            tickWriter?.Close();
            tickWriter = null;
        }
        
        Status = $"Done - {minuteBarCount} minute bars, {tickCount} ticks";
        Print($"PFHistoricalDownloader: Download complete - {minuteBarCount} minute bars, {tickCount} ticks");
        
        isRunning = false;
    }

    #endregion

    #region CSV Writing

    private void InitializeCsvFiles()
    {
        lock (writeLock)
        {
            try
            {
                Print("InitializeCsvFiles: Starting...");
                
                DateTime endTime = DateTime.Now;
                DateTime startTime = ENABLE_TEST_MODE ? endTime.AddDays(-3) : endTime.AddDays(-DaysBack);
                
                string dateRange = $"{startTime:yyyyMMdd}-{endTime:yyyyMMdd}";
                Print($"Date range for filenames: {dateRange}");
                
                if (Instrument?.MasterInstrument?.Name == null)
                {
                    throw new Exception("Instrument or MasterInstrument.Name is null");
                }
                
                string instrumentName = Instrument.MasterInstrument.Name;
                Print($"Instrument name: {instrumentName}");
                
                if (IncludeMinutes)
                {
                    string minuteFile = Path.Combine(OutputFolder, $"{instrumentName}_{MinuteInterval}m_{dateRange}.csv");
                    Print($"Creating minute file: {minuteFile}");
                    
                    bool writeHeader = !AppendToFiles || !File.Exists(minuteFile);
                    minuteWriter = new StreamWriter(minuteFile, AppendToFiles) { AutoFlush = false };
                    
                    if (writeHeader)
                    {
                        minuteWriter.WriteLine("ts_unix_ms,ts_iso,open,high,low,close,volume");
                        Print("Minute file header written");
                    }
                }
                
                if (IncludeTicks)
                {
                    string tickFile = Path.Combine(OutputFolder, $"{instrumentName}_tick_{dateRange}.csv");
                    Print($"Creating tick file: {tickFile}");
                    
                    bool writeHeader = !AppendToFiles || !File.Exists(tickFile);
                    tickWriter = new StreamWriter(tickFile, AppendToFiles) { AutoFlush = false };
                    
                    if (writeHeader)
                    {
                        tickWriter.WriteLine("ts_unix_ms,ts_iso,price,volume");
                        Print("Tick file header written");
                    }
                }
                
                Print("InitializeCsvFiles: Complete");
            }
            catch (Exception ex)
            {
                Print($"Error in InitializeCsvFiles: {ex}");
                throw new Exception($"Failed to initialize CSV files: {ex.Message}", ex);
            }
        }
    }

    private void WriteMinuteData(Bars bars, ChunkRequest chunk)
    {
        if (minuteWriter == null) return;
        
        lock (writeLock)
        {
            try
            {
                for (int i = 0; i < bars.Count; i++)
                {
                    DateTime barTime = bars.GetTime(i);
                    long unixMs = ToUnixMs(barTime, CsvTimeZone);
                    string iso = ToIso(barTime, CsvTimeZone);
                    
                    string line = string.Format(CultureInfo.InvariantCulture,
                        "{0},{1},{2:F5},{3:F5},{4:F5},{5:F5},{6}",
                        unixMs, iso,
                        bars.GetOpen(i),
                        bars.GetHigh(i),
                        bars.GetLow(i),
                        bars.GetClose(i),
                        bars.GetVolume(i));
                        
                    minuteWriter.WriteLine(line);
                }
                
                minuteWriter.Flush();
            }
            catch (Exception ex)
            {
                Print($"Error writing minute data: {ex}");
                throw;
            }
        }
    }

    private void WriteTickData(Bars bars, ChunkRequest chunk)
    {
        if (tickWriter == null) return;
        
        lock (writeLock)
        {
            try
            {
                for (int i = 0; i < bars.Count; i++)
                {
                    DateTime tickTime = bars.GetTime(i);
                    long unixMs = ToUnixMs(tickTime, CsvTimeZone);
                    string iso = ToIso(tickTime, CsvTimeZone);
                    
                    string line = string.Format(CultureInfo.InvariantCulture,
                        "{0},{1},{2:F5},{3}",
                        unixMs, iso,
                        bars.GetClose(i), // Tick price
                        bars.GetVolume(i));
                        
                    tickWriter.WriteLine(line);
                }
                
                tickWriter.Flush();
            }
            catch (Exception ex)
            {
                Print($"Error writing tick data: {ex}");
                throw;
            }
        }
    }

    #endregion

    #region Helper Methods

    private long ToUnixMs(DateTime dt, CsvTimeZoneType timeZone)
    {
        DateTime targetTime = timeZone == CsvTimeZoneType.Utc ? dt.ToUniversalTime() : dt.ToLocalTime();
        return (long)(targetTime - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;
    }

    private string ToIso(DateTime dt, CsvTimeZoneType timeZone)
    {
        DateTime targetTime = timeZone == CsvTimeZoneType.Utc ? dt.ToUniversalTime() : dt.ToLocalTime();
        return targetTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture);
    }

    private void EnsureFolder(string path)
    {
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
            Print($"Created output directory: {path}");
        }
    }

    private bool IsValidMinuteInterval(int interval)
    {
        return interval == 1 || interval == 5 || interval == 15;
    }

    private void CleanupDownload()
    {
        isRunning = false;
        downloadTimer?.Stop();
        CleanupResources();
    }

    private void CleanupResources()
    {
        downloadTimer?.Stop();
        
        lock (writeLock)
        {
            minuteWriter?.Close();
            minuteWriter = null;
            
            tickWriter?.Close();
            tickWriter = null;
        }
    }

    #endregion

    #region Type Converters

    public class MinuteIntervalConverter : TypeConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(new int[] { 1, 5, 15 });
        }

        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }
    }

    #endregion
}

}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PhillyFranksTools.PFHistoricalDownloader[] cachePFHistoricalDownloader;
		public PhillyFranksTools.PFHistoricalDownloader PFHistoricalDownloader()
		{
			return PFHistoricalDownloader(Input);
		}

		public PhillyFranksTools.PFHistoricalDownloader PFHistoricalDownloader(ISeries<double> input)
		{
			if (cachePFHistoricalDownloader != null)
				for (int idx = 0; idx < cachePFHistoricalDownloader.Length; idx++)
					if (cachePFHistoricalDownloader[idx] != null &&  cachePFHistoricalDownloader[idx].EqualsInput(input))
						return cachePFHistoricalDownloader[idx];
			return CacheIndicator<PhillyFranksTools.PFHistoricalDownloader>(new PhillyFranksTools.PFHistoricalDownloader(), input, ref cachePFHistoricalDownloader);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PhillyFranksTools.PFHistoricalDownloader PFHistoricalDownloader()
		{
			return indicator.PFHistoricalDownloader(Input);
		}

		public Indicators.PhillyFranksTools.PFHistoricalDownloader PFHistoricalDownloader(ISeries<double> input )
		{
			return indicator.PFHistoricalDownloader(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PhillyFranksTools.PFHistoricalDownloader PFHistoricalDownloader()
		{
			return indicator.PFHistoricalDownloader(Input);
		}

		public Indicators.PhillyFranksTools.PFHistoricalDownloader PFHistoricalDownloader(ISeries<double> input )
		{
			return indicator.PFHistoricalDownloader(input);
		}
	}
}

#endregion
