#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.PhillyFranksTools
{
    public class BollingerBandWidth : Indicator
    {
        private Bollinger bollinger;
        private double previousDistance = 0;
        private int squeezeBarCount = 0;
        
        // Squeeze detection parameters
        private double squeezeThreshold = 0.8; // Percentage of recent average for squeeze detection
        private int lookbackPeriod = 20; // Bars to look back for squeeze calculation
        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Measures the distance between Bollinger Band upper and lower bands with expansion/contraction coloring and squeeze detection.";
                Name = "Bollinger Band Width";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                DisplayInDataBox = true;
                DrawOnPricePanel = false;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                IsSuspendedWhileInactive = true;
                
                // Bollinger Band Parameters
                Period = 20;
                NumStdDev = 2.0;
                
                // Display Options
                UseLineGraph = false;
                MatchDataSeriesWidth = true;
                
                // Colors
                ExpandingColor = Brushes.LimeGreen;
                ContractingColor = Brushes.Red;
                SqueezeColor = Brushes.Yellow;
                
                // Squeeze Settings
                EnableSqueezeDetection = true;
                SqueezeThresholdPercent = 80;
                SqueezeLookbackBars = 20;
                
                AddPlot(Brushes.Blue, "BBWidth");
                
                // Set default plot style to Bar with data series width matching
                Plots[0].PlotStyle = PlotStyle.Bar;
                Plots[0].Width = 1;
            }
            else if (State == State.DataLoaded)
            {
                bollinger = Bollinger(Close, NumStdDev, Period);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < Period)
                return;
                
            // Calculate distance between upper and lower Bollinger Bands
            double upperBand = bollinger.Upper[0];
            double lowerBand = bollinger.Lower[0];
            double currentDistance = upperBand - lowerBand;
            
            // Keep the raw point difference (don't convert to ticks)
            BBWidth[0] = currentDistance;
            
            // Determine if bands are expanding or contracting
            bool isExpanding = false;
            bool isSqueezing = false;
            
            if (CurrentBar > 0)
            {
                // For comparison, always use the previous completed bar's distance
                double comparisonDistance;
                if (Calculate == Calculate.OnEachTick && !IsFirstTickOfBar)
                {
                    // On each tick (not first tick), compare to the last completed bar
                    double prevUpperBand = bollinger.Upper[1];
                    double prevLowerBand = bollinger.Lower[1];
                    comparisonDistance = prevUpperBand - prevLowerBand;
                }
                else
                {
                    // On bar close or first tick of bar, use stored previous distance
                    comparisonDistance = previousDistance;
                }
                
                isExpanding = currentDistance > comparisonDistance;
                
                // Squeeze Detection
                if (EnableSqueezeDetection && CurrentBar >= SqueezeLookbackBars)
                {
                    double averageDistance = 0;
                    for (int i = 1; i <= SqueezeLookbackBars; i++)
                    {
                        if (CurrentBar - i >= 0)
                        {
                            double pastUpper = bollinger.Upper[i];
                            double pastLower = bollinger.Lower[i];
                            averageDistance += (pastUpper - pastLower);
                        }
                    }
                    averageDistance /= SqueezeLookbackBars;
                    
                    double squeezeThresholdValue = averageDistance * (SqueezeThresholdPercent / 100.0);
                    isSqueezing = currentDistance <= squeezeThresholdValue;
                    
                    if (isSqueezing)
                        squeezeBarCount++;
                    else
                        squeezeBarCount = 0;
                }
            }
            
            // Set colors based on state
            if (isSqueezing)
            {
                PlotBrushes[0][0] = SqueezeColor;
            }
            else if (isExpanding)
            {
                PlotBrushes[0][0] = ExpandingColor;
            }
            else
            {
                PlotBrushes[0][0] = ContractingColor;
            }
            
            // Set plot style based on UseLineGraph selection
            if (UseLineGraph)
            {
                Plots[0].PlotStyle = PlotStyle.Line;
                Plots[0].Width = 2;
            }
            else
            {
                Plots[0].PlotStyle = PlotStyle.Bar;
                // Use either data series width or default width based on setting
                if (MatchDataSeriesWidth && ChartBars != null)
                {
                    Plots[0].Width = Math.Max(1, (int)(ChartControl.BarWidth));
                }
                else
                {
                    Plots[0].Width = 1;
                }
            }
            
            // Only update previousDistance on bar close or first tick of new bar
            if (Calculate == Calculate.OnBarClose || IsFirstTickOfBar)
            {
                previousDistance = currentDistance;
            }
        }
        
        public override string DisplayName
        {
            get { return "PhillyFranks Tools - BB Width"; }
        }

        #region Properties
        
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Period", Description="Number of bars used for Bollinger Band calculation", Order=1, GroupName="Bollinger Band Parameters")]
        public int Period { get; set; }

        [NinjaScriptProperty]
        [Range(0.1, double.MaxValue)]
        [Display(Name="Num Std Dev", Description="Number of standard deviations for Bollinger Bands", Order=2, GroupName="Bollinger Band Parameters")]
        public double NumStdDev { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name="Use Line Graph", Description="Display as Line instead of Bar", Order=1, GroupName="Display Options")]
        public bool UseLineGraph { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name="Match Data Series Width", Description="Match bar width to chart's data series width", Order=2, GroupName="Display Options")]
        public bool MatchDataSeriesWidth { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="Expanding Color", Description="Color when bands are expanding", Order=2, GroupName="Display Options")]
        public Brush ExpandingColor { get; set; }

        [Browsable(false)]
        public string ExpandingColorSerializable
        {
            get { return Serialize.BrushToString(ExpandingColor); }
            set { ExpandingColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="Contracting Color", Description="Color when bands are contracting", Order=3, GroupName="Display Options")]
        public Brush ContractingColor { get; set; }

        [Browsable(false)]
        public string ContractingColorSerializable
        {
            get { return Serialize.BrushToString(ContractingColor); }
            set { ContractingColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="Squeeze Color", Description="Color during squeeze conditions", Order=4, GroupName="Display Options")]
        public Brush SqueezeColor { get; set; }

        [Browsable(false)]
        public string SqueezeColorSerializable
        {
            get { return Serialize.BrushToString(SqueezeColor); }
            set { SqueezeColor = Serialize.StringToBrush(value); }
        }
        
        [NinjaScriptProperty]
        [Display(Name="Enable Squeeze Detection", Description="Enable detection of squeeze conditions", Order=1, GroupName="Squeeze Settings")]
        public bool EnableSqueezeDetection { get; set; }
        
        [NinjaScriptProperty]
        [Range(1, 100)]
        [Display(Name="Squeeze Threshold %", Description="Percentage of average distance to trigger squeeze", Order=2, GroupName="Squeeze Settings")]
        public int SqueezeThresholdPercent { get; set; }
        
        [NinjaScriptProperty]
        [Range(5, 100)]
        [Display(Name="Squeeze Lookback Bars", Description="Number of bars to look back for squeeze calculation", Order=3, GroupName="Squeeze Settings")]
        public int SqueezeLookbackBars { get; set; }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> BBWidth
        {
            get { return Values[0]; }
        }

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PhillyFranksTools.BollingerBandWidth[] cacheBollingerBandWidth;
		public PhillyFranksTools.BollingerBandWidth BollingerBandWidth(int period, double numStdDev, bool useLineGraph, bool matchDataSeriesWidth, Brush expandingColor, Brush contractingColor, Brush squeezeColor, bool enableSqueezeDetection, int squeezeThresholdPercent, int squeezeLookbackBars)
		{
			return BollingerBandWidth(Input, period, numStdDev, useLineGraph, matchDataSeriesWidth, expandingColor, contractingColor, squeezeColor, enableSqueezeDetection, squeezeThresholdPercent, squeezeLookbackBars);
		}

		public PhillyFranksTools.BollingerBandWidth BollingerBandWidth(ISeries<double> input, int period, double numStdDev, bool useLineGraph, bool matchDataSeriesWidth, Brush expandingColor, Brush contractingColor, Brush squeezeColor, bool enableSqueezeDetection, int squeezeThresholdPercent, int squeezeLookbackBars)
		{
			if (cacheBollingerBandWidth != null)
				for (int idx = 0; idx < cacheBollingerBandWidth.Length; idx++)
					if (cacheBollingerBandWidth[idx] != null && cacheBollingerBandWidth[idx].Period == period && cacheBollingerBandWidth[idx].NumStdDev == numStdDev && cacheBollingerBandWidth[idx].UseLineGraph == useLineGraph && cacheBollingerBandWidth[idx].MatchDataSeriesWidth == matchDataSeriesWidth && cacheBollingerBandWidth[idx].ExpandingColor == expandingColor && cacheBollingerBandWidth[idx].ContractingColor == contractingColor && cacheBollingerBandWidth[idx].SqueezeColor == squeezeColor && cacheBollingerBandWidth[idx].EnableSqueezeDetection == enableSqueezeDetection && cacheBollingerBandWidth[idx].SqueezeThresholdPercent == squeezeThresholdPercent && cacheBollingerBandWidth[idx].SqueezeLookbackBars == squeezeLookbackBars && cacheBollingerBandWidth[idx].EqualsInput(input))
						return cacheBollingerBandWidth[idx];
			return CacheIndicator<PhillyFranksTools.BollingerBandWidth>(new PhillyFranksTools.BollingerBandWidth(){ Period = period, NumStdDev = numStdDev, UseLineGraph = useLineGraph, MatchDataSeriesWidth = matchDataSeriesWidth, ExpandingColor = expandingColor, ContractingColor = contractingColor, SqueezeColor = squeezeColor, EnableSqueezeDetection = enableSqueezeDetection, SqueezeThresholdPercent = squeezeThresholdPercent, SqueezeLookbackBars = squeezeLookbackBars }, input, ref cacheBollingerBandWidth);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PhillyFranksTools.BollingerBandWidth BollingerBandWidth(int period, double numStdDev, bool useLineGraph, bool matchDataSeriesWidth, Brush expandingColor, Brush contractingColor, Brush squeezeColor, bool enableSqueezeDetection, int squeezeThresholdPercent, int squeezeLookbackBars)
		{
			return indicator.BollingerBandWidth(Input, period, numStdDev, useLineGraph, matchDataSeriesWidth, expandingColor, contractingColor, squeezeColor, enableSqueezeDetection, squeezeThresholdPercent, squeezeLookbackBars);
		}

		public Indicators.PhillyFranksTools.BollingerBandWidth BollingerBandWidth(ISeries<double> input , int period, double numStdDev, bool useLineGraph, bool matchDataSeriesWidth, Brush expandingColor, Brush contractingColor, Brush squeezeColor, bool enableSqueezeDetection, int squeezeThresholdPercent, int squeezeLookbackBars)
		{
			return indicator.BollingerBandWidth(input, period, numStdDev, useLineGraph, matchDataSeriesWidth, expandingColor, contractingColor, squeezeColor, enableSqueezeDetection, squeezeThresholdPercent, squeezeLookbackBars);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PhillyFranksTools.BollingerBandWidth BollingerBandWidth(int period, double numStdDev, bool useLineGraph, bool matchDataSeriesWidth, Brush expandingColor, Brush contractingColor, Brush squeezeColor, bool enableSqueezeDetection, int squeezeThresholdPercent, int squeezeLookbackBars)
		{
			return indicator.BollingerBandWidth(Input, period, numStdDev, useLineGraph, matchDataSeriesWidth, expandingColor, contractingColor, squeezeColor, enableSqueezeDetection, squeezeThresholdPercent, squeezeLookbackBars);
		}

		public Indicators.PhillyFranksTools.BollingerBandWidth BollingerBandWidth(ISeries<double> input , int period, double numStdDev, bool useLineGraph, bool matchDataSeriesWidth, Brush expandingColor, Brush contractingColor, Brush squeezeColor, bool enableSqueezeDetection, int squeezeThresholdPercent, int squeezeLookbackBars)
		{
			return indicator.BollingerBandWidth(input, period, numStdDev, useLineGraph, matchDataSeriesWidth, expandingColor, contractingColor, squeezeColor, enableSqueezeDetection, squeezeThresholdPercent, squeezeLookbackBars);
		}
	}
}

#endregion
