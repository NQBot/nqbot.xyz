#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
#endregion

public enum FloatingClockTimeZone
{
    Local,
    UTC,
    Custom
}

namespace NinjaTrader.NinjaScript.Indicators.PhillyFranksTools
{
    /// <summary>
    /// PhillyFrank's Tools - Floating Local Clock
    /// A professional-grade floating clock indicator that follows the price level
    /// with multiple time zones and customizable appearance options.
    /// 
    /// Features:
    /// - Floats at current price level to the right of candles
    /// - Multiple time zone support (Local, UTC, Custom)
    /// - Customizable fonts, colors, and background styling
    /// - Real-time updates every second
    /// - Professional transparency controls
    /// 
    /// Created by: PhillyFrank
    /// Version: 1.0 (Floating)
    /// </summary>
    public class FloatingLocalClock : Indicator
    {
        private string clockText = "";
        private SharpDX.DirectWrite.TextFormat textFormat;
        private SharpDX.Direct2D1.SolidColorBrush textBrush;
        private SharpDX.Direct2D1.SolidColorBrush backgroundBrush;
        private DateTime lastUpdateTime;
        private System.Windows.Threading.DispatcherTimer uiTimer;
        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"PhillyFrank's Tools - Floating Local Clock: Displays a customizable clock that floats at the current price level with multiple time zones and appearance settings.";
                Name = "Floating Local Clock";
                Calculate = Calculate.OnEachTick;
                IsOverlay = true;
                DisplayInDataBox = false;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = false;
                DrawVerticalGridLines = false;
                PaintPriceMarkers = false;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                IsSuspendedWhileInactive = false;
                
                // Default settings
                TimeZoneSelection = FloatingClockTimeZone.Local;
                CustomTimeZoneId = "Eastern Standard Time";
                ShowSeconds = true;
                Use24HourFormat = false;
                ShowDate = false;
                DateFormat = "MM/dd/yyyy";
                BarsToTheRight = 5;
                PriceOffset = 0;
                FontSize = 12;
                FontFamilyName = "Arial";
                TextColor = System.Windows.Media.Brushes.White;
                BackgroundColor = System.Windows.Media.Brushes.Black;
                BackgroundOpacity = 0.7;
                ShowBackground = true;
            }
            else if (State == State.Active)
            {
                // Initialize last update time
                lastUpdateTime = DateTime.MinValue;
            }
            else if (State == State.Terminated)
            {
                // Clean up the timer
                if (uiTimer != null)
                {
                    uiTimer.Stop();
                    uiTimer = null;
                }
                
                // Clean up DirectX resources
                textFormat?.Dispose();
                textBrush?.Dispose();
                backgroundBrush?.Dispose();
            }
        }

        protected override void OnBarUpdate()
        {
            // This method can be empty now - timer handles updates
        }

        private void UpdateClockText()
        {
            DateTime currentTime = GetCurrentTime();
            
            string timeFormat = "";
            if (Use24HourFormat)
            {
                timeFormat = ShowSeconds ? "HH:mm:ss" : "HH:mm";
            }
            else
            {
                timeFormat = ShowSeconds ? "hh:mm:ss tt" : "hh:mm tt";
            }
            
            clockText = currentTime.ToString(timeFormat);
            
            if (ShowDate)
            {
                clockText = currentTime.ToString(DateFormat) + "\n" + clockText;
            }
        }

        private DateTime GetCurrentTime()
        {
            DateTime now = DateTime.Now;
            
            switch (TimeZoneSelection)
            {
                case FloatingClockTimeZone.Local:
                    return now;
                    
                case FloatingClockTimeZone.UTC:
                    return DateTime.UtcNow;
                    
                case FloatingClockTimeZone.Custom:
                    try
                    {
                        TimeZoneInfo customTimeZone = TimeZoneInfo.FindSystemTimeZoneById(CustomTimeZoneId);
                        return TimeZoneInfo.ConvertTime(DateTime.UtcNow, customTimeZone);
                    }
                    catch
                    {
                        return now; // Fallback to local time if custom timezone fails
                    }
                    
                default:
                    return now;
            }
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            // Start the timer on first render if not already started
            if (uiTimer == null && ChartControl != null)
            {
                uiTimer = new System.Windows.Threading.DispatcherTimer(System.Windows.Threading.DispatcherPriority.Background);
                uiTimer.Interval = TimeSpan.FromSeconds(1);
                uiTimer.Tick += (s, e) => 
                {
                    if (ChartControl != null && !ChartControl.Dispatcher.CheckAccess())
                        return;
                    try 
                    { 
                        ChartControl?.InvalidateVisual(); 
                    } 
                    catch { }
                };
                uiTimer.Start();
            }
            
            // Always update the clock text on every render
            UpdateClockText();

            // Create DirectX resources if needed
            if (textFormat == null)
            {
                textFormat = new SharpDX.DirectWrite.TextFormat(
                    Core.Globals.DirectWriteFactory,
                    FontFamilyName,
                    (float)FontSize);
            }

            if (textBrush == null || textBrush.IsDisposed)
            {
                var wpfTextBrush = TextColor as System.Windows.Media.SolidColorBrush;
                textBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, 
                    new SharpDX.Color4(wpfTextBrush.Color.R / 255f,
                                       wpfTextBrush.Color.G / 255f,
                                       wpfTextBrush.Color.B / 255f,
                                       wpfTextBrush.Color.A / 255f));
            }

            if (ShowBackground && (backgroundBrush == null || backgroundBrush.IsDisposed))
            {
                var wpfBackgroundBrush = BackgroundColor as System.Windows.Media.SolidColorBrush;
                if (wpfBackgroundBrush != null)
                {
                    backgroundBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget,
                        new SharpDX.Color4(wpfBackgroundBrush.Color.R / 255f,
                                           wpfBackgroundBrush.Color.G / 255f,
                                           wpfBackgroundBrush.Color.B / 255f,
                                           (float)BackgroundOpacity));
                }
            }

            // Get current price and bar position
            if (CurrentBar < 0 || Closes[0].Count == 0)
                return;

            double currentPrice = 0;
            
            // Get the most current price based on market state
            if (State == State.Realtime && BarsInProgress == 0)
            {
                // Use the current bid/ask midpoint for more accurate positioning
                currentPrice = (GetCurrentBid() + GetCurrentAsk()) / 2;
                
                // If bid/ask not available, use last price
                if (currentPrice == 0)
                    currentPrice = Close[0];
            }
            else
            {
                // Use the close of the current bar
                currentPrice = Close[0];
            }
            
            int currentBarIndex = ChartBars.ToIndex;
            
            // Calculate X position (to the right of current bar)
            int barsFromRight = ChartBars.ToIndex - currentBarIndex + BarsToTheRight;
            float x = chartControl.GetXByBarIndex(ChartBars, currentBarIndex + BarsToTheRight);
            
            // Calculate Y position (at current price level with offset)
            float y = chartScale.GetYByValue(currentPrice + PriceOffset * TickSize);

            // Measure text
            var textLayout = new SharpDX.DirectWrite.TextLayout(
                Core.Globals.DirectWriteFactory,
                clockText,
                textFormat,
                ChartPanel.W,
                ChartPanel.H);

            float textWidth = textLayout.Metrics.Width;
            float textHeight = textLayout.Metrics.Height;

            // Center the text vertically at the price level
            y -= textHeight / 2;

            // Make sure the clock stays within chart boundaries
            if (x + textWidth > ChartPanel.W - 10)
                x = ChartPanel.W - textWidth - 10;
            if (x < 10)
                x = 10;
            if (y < 10)
                y = 10;
            if (y + textHeight > ChartPanel.H - 10)
                y = ChartPanel.H - textHeight - 10;

            // Draw background if enabled and brush exists
            if (ShowBackground && backgroundBrush != null && BackgroundOpacity > 0)
            {
                var backgroundRect = new SharpDX.RectangleF(x - 5, y - 2, textWidth + 10, textHeight + 4);
                RenderTarget.FillRectangle(backgroundRect, backgroundBrush);
            }

            // Draw the text
            RenderTarget.DrawTextLayout(new SharpDX.Vector2(x, y), textLayout, textBrush);
            
            textLayout.Dispose();
        }

        private double GetCurrentPrice()
        {
            // This method is no longer needed - price logic moved to OnRender
            return 0;
        }

        #region Properties
        
        [NinjaScriptProperty]
        [Display(Name = "Time Zone", Description = "Select the time zone to display", Order = 1, GroupName = "Time Settings")]
        public FloatingClockTimeZone TimeZoneSelection { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Custom Time Zone ID", Description = "Time zone ID when using Custom option (e.g., 'Eastern Standard Time', 'Pacific Standard Time')", Order = 2, GroupName = "Time Settings")]
        public string CustomTimeZoneId { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Seconds", Description = "Display seconds in the time", Order = 3, GroupName = "Time Settings")]
        public bool ShowSeconds { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "24-Hour Format", Description = "Use 24-hour time format instead of 12-hour", Order = 4, GroupName = "Time Settings")]
        public bool Use24HourFormat { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Date", Description = "Display the date above the time", Order = 5, GroupName = "Time Settings")]
        public bool ShowDate { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Date Format", Description = "Date format string (e.g., MM/dd/yyyy, dd/MM/yyyy)", Order = 6, GroupName = "Time Settings")]
        public string DateFormat { get; set; }

        [NinjaScriptProperty]
        [Range(0, 50)]
        [Display(Name = "Bars To The Right", Description = "Number of bars to the right of current bar to display clock", Order = 1, GroupName = "Position")]
        public int BarsToTheRight { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Price Offset (Ticks)", Description = "Vertical offset in ticks from current price", Order = 2, GroupName = "Position")]
        public int PriceOffset { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Font Size", Description = "Size of the clock text", Order = 1, GroupName = "Appearance")]
        public double FontSize { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Font Family", Description = "Font family name for the clock text (e.g., Arial, Times New Roman)", Order = 2, GroupName = "Appearance")]
        public string FontFamilyName { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Text Color", Description = "Color of the clock text", Order = 3, GroupName = "Appearance")]
        public System.Windows.Media.Brush TextColor { get; set; }

        [Browsable(false)]
        public string TextColorSerializable
        {
            get { return Serialize.BrushToString(TextColor); }
            set { TextColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [Display(Name = "Show Background", Description = "Show background behind the clock", Order = 4, GroupName = "Appearance")]
        public bool ShowBackground { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Background Color", Description = "Background color of the clock", Order = 5, GroupName = "Appearance")]
        public System.Windows.Media.Brush BackgroundColor { get; set; }

        [Browsable(false)]
        public string BackgroundColorSerializable
        {
            get { return Serialize.BrushToString(BackgroundColor); }
            set { BackgroundColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [Range(0.0, 1.0)]
        [Display(Name = "Background Opacity", Description = "Opacity of the background (0.0 = transparent, 1.0 = opaque)", Order = 6, GroupName = "Appearance")]
        public double BackgroundOpacity { get; set; }

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PhillyFranksTools.FloatingLocalClock[] cacheFloatingLocalClock;
		public PhillyFranksTools.FloatingLocalClock FloatingLocalClock(FloatingClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, int barsToTheRight, int priceOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			return FloatingLocalClock(Input, timeZoneSelection, customTimeZoneId, showSeconds, use24HourFormat, showDate, dateFormat, barsToTheRight, priceOffset, fontSize, fontFamilyName, textColor, showBackground, backgroundColor, backgroundOpacity);
		}

		public PhillyFranksTools.FloatingLocalClock FloatingLocalClock(ISeries<double> input, FloatingClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, int barsToTheRight, int priceOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			if (cacheFloatingLocalClock != null)
				for (int idx = 0; idx < cacheFloatingLocalClock.Length; idx++)
					if (cacheFloatingLocalClock[idx] != null && cacheFloatingLocalClock[idx].TimeZoneSelection == timeZoneSelection && cacheFloatingLocalClock[idx].CustomTimeZoneId == customTimeZoneId && cacheFloatingLocalClock[idx].ShowSeconds == showSeconds && cacheFloatingLocalClock[idx].Use24HourFormat == use24HourFormat && cacheFloatingLocalClock[idx].ShowDate == showDate && cacheFloatingLocalClock[idx].DateFormat == dateFormat && cacheFloatingLocalClock[idx].BarsToTheRight == barsToTheRight && cacheFloatingLocalClock[idx].PriceOffset == priceOffset && cacheFloatingLocalClock[idx].FontSize == fontSize && cacheFloatingLocalClock[idx].FontFamilyName == fontFamilyName && cacheFloatingLocalClock[idx].TextColor == textColor && cacheFloatingLocalClock[idx].ShowBackground == showBackground && cacheFloatingLocalClock[idx].BackgroundColor == backgroundColor && cacheFloatingLocalClock[idx].BackgroundOpacity == backgroundOpacity && cacheFloatingLocalClock[idx].EqualsInput(input))
						return cacheFloatingLocalClock[idx];
			return CacheIndicator<PhillyFranksTools.FloatingLocalClock>(new PhillyFranksTools.FloatingLocalClock(){ TimeZoneSelection = timeZoneSelection, CustomTimeZoneId = customTimeZoneId, ShowSeconds = showSeconds, Use24HourFormat = use24HourFormat, ShowDate = showDate, DateFormat = dateFormat, BarsToTheRight = barsToTheRight, PriceOffset = priceOffset, FontSize = fontSize, FontFamilyName = fontFamilyName, TextColor = textColor, ShowBackground = showBackground, BackgroundColor = backgroundColor, BackgroundOpacity = backgroundOpacity }, input, ref cacheFloatingLocalClock);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PhillyFranksTools.FloatingLocalClock FloatingLocalClock(FloatingClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, int barsToTheRight, int priceOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			return indicator.FloatingLocalClock(Input, timeZoneSelection, customTimeZoneId, showSeconds, use24HourFormat, showDate, dateFormat, barsToTheRight, priceOffset, fontSize, fontFamilyName, textColor, showBackground, backgroundColor, backgroundOpacity);
		}

		public Indicators.PhillyFranksTools.FloatingLocalClock FloatingLocalClock(ISeries<double> input , FloatingClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, int barsToTheRight, int priceOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			return indicator.FloatingLocalClock(input, timeZoneSelection, customTimeZoneId, showSeconds, use24HourFormat, showDate, dateFormat, barsToTheRight, priceOffset, fontSize, fontFamilyName, textColor, showBackground, backgroundColor, backgroundOpacity);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PhillyFranksTools.FloatingLocalClock FloatingLocalClock(FloatingClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, int barsToTheRight, int priceOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			return indicator.FloatingLocalClock(Input, timeZoneSelection, customTimeZoneId, showSeconds, use24HourFormat, showDate, dateFormat, barsToTheRight, priceOffset, fontSize, fontFamilyName, textColor, showBackground, backgroundColor, backgroundOpacity);
		}

		public Indicators.PhillyFranksTools.FloatingLocalClock FloatingLocalClock(ISeries<double> input , FloatingClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, int barsToTheRight, int priceOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			return indicator.FloatingLocalClock(input, timeZoneSelection, customTimeZoneId, showSeconds, use24HourFormat, showDate, dateFormat, barsToTheRight, priceOffset, fontSize, fontFamilyName, textColor, showBackground, backgroundColor, backgroundOpacity);
		}
	}
}

#endregion
