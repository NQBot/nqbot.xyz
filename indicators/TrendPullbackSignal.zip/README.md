# Trend Pullback Signal - manual signal indicator (NinjaTrader 8)

One file. It marks a trend-pullback setup on your chart, prices the entry, the stop and
the target, and sounds an alert. **It places no orders. You do.**

There is no strategy in this download and nothing in it trades for you. That is on
purpose: most funding companies do not allow automated trading on an evaluation or funded
account, and an indicator you act on by hand is a different thing from a robot. Read your
own contract; the rule is theirs to change.

---

## Read this first

- **No edge is claimed.** This is a defined rule set you can watch work and judge for
  yourself. Our own tests over years of 1-minute NQ data did not find a reliable edge in
  it, and nothing here says it makes money.
- **Its history is simulated.** These rules once ran as an automated strategy in a
  simulated evaluation arena that is now closed. Those results are on the website's Eval
  Arena page. They are simulated, they are not a track record, and the strategy is no
  longer distributed.
- **The simulated outcomes the indicator draws** (the diamonds, the open points) are a
  model of what the rules would have done, not a record of any trade anyone took. They do
  not know what you really did.
- **You are responsible for every order you place**, and for the rules of the account you
  place it on.

---

## What you need

| | |
|---|---|
| Platform | NinjaTrader 8 (8.1.x) |
| Instrument | NQ or MNQ. The stop floor and cap are written in NQ points |
| Chart | **1-minute**, ETH (24-hour) session template |
| Time zone | **US Eastern**: Tools > Options > General > Time zone. Every session hour here is Eastern |
| Warmup | 25 bars minimum; 100+ before the regime line means much |

On another instrument the 15-40 point stop clamp is meaningless and you must re-derive it.

---

## Install

1. Control Center > **Tools > Import > NinjaScript Add-On...** and pick `TrendPullbackSignal.zip`.
2. Restart NinjaTrader, or **Tools > New NinjaScript > Compile**.
3. Add **TrendPullbackSignal** to a 1-minute NQ chart (it is listed under PhillyFranksTools).

If the importer objects to the extra files in the archive, extract the zip by hand and
copy `Indicators\TrendPullbackSignal.cs` into
`Documents\NinjaTrader 8\bin\Custom\Indicators\`, then compile.

---

## The setup, in plain English

1. **Trend.** EMA(20) sloping faster than the slope minimum, with price on the right side
   of it (long above, short below). The Asian and US presets also need ADX(14) above 25.
2. **Pullback.** Price comes back to within 0.3 x ATR(14) of the level: the EMA, the window
   VWAP, or whichever of the two is further from price, depending on the preset.
3. **Trigger.** The European preset takes the touch. The Asian and US presets want a
   rejection wick that closes back on the right side of the level.
4. **Entry.** A limit 25% of the trigger bar's range back inside that bar. **It is live for
   one bar only.**
5. **Bracket.** Stop = 1.5 x ATR(14), never tighter than 15 points and never wider than 40.
   Target = the stop scaled by the preset's reward-to-risk (2R on every preset), capped at 3R.
6. **Clock.** Nothing new is priced from 15:30 ET, and a followed trade still open at 15:45 ET
   is closed in the simulation.

### Presets

| Preset | Window (ET) | ADX | EMA slope | Level | Trigger |
|---|---|---|---|---|---|
| VariantB_European (default) | 03:00-08:00 | off | 0.3 | EMA or VWAP | touch |
| VariantA_Asian | 20:00-01:30 | at least 25 | 0.5 | VWAP | rejection |
| VariantA_US | 09:30-15:30 | at least 25 | 0.5 | VWAP | rejection |
| Custom | yours | yours | yours | yours | yours |

A window is not a cosmetic setting: the same rules on different hours are a different test.
If you move it, you are not tuning, you are testing something new. A tuned Custom setup is
your configuration, not a published one.

---

## Trading it by hand

When a setup fires you get an arrow, a sound, a dashed line at the limit price, and the
panel tells you what to place:

```
TREND PULLBACK - MANUAL FOLLOW
Variant B - European (03:00-08:00 ET)
Clock 04:12   window 03:00-08:00
Regime Quiet trend
------------------------------------------
WORKING LIMIT - LONG
Valid for THIS BAR ONLY
Limit     24310.25
Stop loss 24292.00   (18.25 pts)
Target    24346.75   (36.5 pts)
Risk      $365 per contract
------------------------------------------
Setups filled today 1 / 99    target 0  stop loss 0
YOU place the orders. Nothing here trades.
```

**The limit is live for one bar.** Place it as a limit order with a one-minute life, or
cancel it at the close of the next bar. Often a third or more of setups never come back to
the limit and are simply skipped. Not chasing the bar that triggered it is the design, not a
missed trade.

Once price reaches the limit the indicator tracks the trade: stop and target lines, open
points, and a diamond when the simulated bracket resolves.

| Marker | Meaning |
|---|---|
| Arrow up / down | Setup fired on this bar's close |
| Dashed line | The limit price, live for one bar |
| Grey dot | Limit expired unfilled: stand down |
| Solid red / green lines | Stop and target once filled |
| Diamond | Simulated bracket resolved (green target, red stop, gold session flat) |

### Sounds

Three moments can have a sound, picked from the sounds NinjaTrader ships with (or
`Custom`, which plays the file named in **Custom sound file**). `None` raises no alert for
that event at all. **Enable alerts** is the master switch.

| Event | Default |
|---|---|
| Setup armed | `Alert1` |
| Limit filled | `None` |
| Limit expired | `None` |

### Deliberately pessimistic tracking

- On the bar the limit fills, **only the stop is checked**. Crediting a target on the fill
  bar is the commonest way a backtest reports profit it never made.
- After that, a bar that touches both stop and target is recorded as a **stop**.
- A gap through your limit fills at the open, in your favour.

---

## Settings

| Group | What is in it |
|---|---|
| 1. Setup | Preset, Show visuals |
| 2. Custom rules | Used only with the Custom preset: ADX filter and threshold, EMA slope, pullback level, trigger, stop and target points, session start and end, Fixed bracket |
| 3. Filters | Max setups per session (default 99, effectively no cap), avoid lunch chop (12:00-13:00), your own news blackout windows, and the optional cooldown |
| 4. Display | Panel on/off, corner, size and offsets, label size, plot the pullback level, risk per trade (shows how many contracts that budget buys; sizing stays your decision), hide the panel outside the session, and "Show 'you place the orders' line" |
| 5. Alerts | Master switch, the three sounds, custom sound file |
| 6. Colors | Long, short, stop, target, panel text and background |

**Cooldown (on by default).** After a followed setup closes, no new setup is published for
15 minutes after a win or 45 after a loss. Every number is yours, and **Use cooldown** turns
it off. A setup that expires unfilled is not a trade and starts no cooldown.

---

## Things you should know

- **The VWAP is window-anchored.** It accumulates only on bars inside the entry window and
  resets at midnight, so it will not match a standard VWAP. That is deliberate.
- **Everything evaluates on bar close.** If you change `Calculate`, the indicator forces it
  back to `OnBarClose`, because an intrabar version would show setups that vanish.
- **The news blackout is empty and manual.** Nothing is downloaded or guessed. Fill in
  `0830-0900;1400-1430` yourself, or leave it blank.
- **Failures print to the NinjaScript Output window** (Control Center > New > NinjaScript
  Output). Look there first.
- **Entry, Stop and Target are also plots.** While a setup is pending or open they carry the limit (then
  the fill) price, the stop and the target, so you can read them in the Data Box or pick them as an input
  series for another indicator or an alert. Between setups they are empty. Style them under Plots.
- **Label offset (bars)** under 4. Display moves the limit, target and stop loss labels to the right of the
  latest bar so they do not sit on the candles (default 6, 0 keeps them at the latest bar). The right margin
  of the chart has to be wide enough to show them.

### Optional call log (off by default)

If you create a text file named `NQBotFollowerCallLog.txt` in `Documents\NinjaTrader 8` and
put a folder path on its first line, the indicator appends one JSON line per call (setup,
fill, exit, alert) to `TrendPullbackSignal_calls_<day>.jsonl` in that folder, in realtime
only. Without the file nothing is written. The indicator makes no network calls.

---

## Files

```
Indicators/TrendPullbackSignal.cs   the signal engine and the manual display
LICENSE                             MIT
Info.xml                            NinjaTrader import descriptor
```

---

## Risk, licence, and what this is not

MIT licence. See `LICENSE`. Use it, change it, share it. If you modify it to place orders
automatically, that is your choice and your risk, and it may breach your funding agreement.

**These are trade signals.** The indicator tells you a direction, an entry price, a stop and
a target. Treat that with the seriousness it deserves, even though it sends no order.

**Nothing here is financial advice.** The author is not a registered investment adviser,
commodity trading advisor or broker, and nothing in this package is a recommendation to buy
or sell anything or a solicitation to trade. It is published for education and research.
Trading futures carries a substantial risk of loss, is not suitable for every investor, and
you can lose more than you deposit. Simulated performance especially does not indicate
future results.

**Test it in simulation first, for long enough to watch it lose**, and never trade money you
cannot afford to lose.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND. See `LICENSE`.
