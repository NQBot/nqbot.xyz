// ============================================================================
// ChartPool.cs - Off-Screen Chart Pool Manager
// ============================================================================
// Creates off-screen charts using WPF rendering - no visible windows needed
// ============================================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;

namespace NinjaTrader.NinjaScript.AddOns
{
    public class ChartPool : IDisposable
    {
        private readonly ChartExportConfig _config;
        private readonly string _outputFolder;
        private readonly List<ChartView> _views;
        private readonly object _lockObject = new object();
        private bool _isInitialized;
        private bool _isDisposed;
        
        public ChartPool(ChartExportConfig config, string outputFolder)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));
            _outputFolder = outputFolder ?? throw new ArgumentNullException(nameof(outputFolder));
            _views = new List<ChartView>();
        }
        
        public async Task InitializeAsync()
        {
            if (_isInitialized) return;
            
            lock (_lockObject)
            {
                if (_isInitialized) return;
                
                foreach (var view in _views)
                    view.Dispose();
                _views.Clear();
                
                foreach (var viewConfig in _config.Views)
                {
                    if (!viewConfig.Enabled)
                    {
                        LogMessage($"Skipping disabled view: {viewConfig.InstrumentName} {viewConfig.TimeframePeriodDisplay}{viewConfig.TimeframeTypeShort}");
                        continue;
                    }

                    try
                    {
                        var view = new ChartView(viewConfig, _outputFolder, _config.EnableArchive, _config.ArchiveFolder);
                        _views.Add(view);
                    }
                    catch (Exception ex)
                    {
                        LogMessage($"Error creating view {viewConfig.InstrumentName}: {ex.Message}");
                    }
                }
            }
            
            // Initialize bars for all views in parallel
            var tasks = _views.Select(v => Task.Run(() => v.InitializeBars())).ToArray();
            await Task.WhenAll(tasks);
            
            _isInitialized = true;
            LogMessage($"Chart pool initialized: {_views.Count} views");
        }
        
        public List<ExportResult> RunExportCycle(bool forcedExport = false)
        {
            var results = new List<ExportResult>();
            
            if (!_isInitialized)
            {
                LogMessage("Pool not initialized.");
                return results;
            }
            
            var now = DateTime.UtcNow;
            
            foreach (var view in _views)
            {
                try
                {
                    if (!forcedExport && !view.ShouldExport(now))
                        continue;
                    
                    var result = view.Export();
                    if (result != null)
                    {
                        results.Add(result);
                        view.MarkExported(now);
                    }
                }
                catch (Exception ex)
                {
                    LogMessage($"Export error {view.ViewId}: {ex.Message}");
                }
            }
            
            return results;
        }
        
        public void Dispose()
        {
            if (_isDisposed) return;
            
            lock (_lockObject)
            {
                foreach (var view in _views)
                {
                    try { view.Dispose(); } catch { }
                }
                _views.Clear();
                _isDisposed = true;
            }
        }
        
        private void LogMessage(string message)
        {
            NinjaTrader.Code.Output.Process($"[ChartPool] {message}", PrintTo.OutputTab1);
        }
    }
    
    public class ChartView : IDisposable
    {
        private readonly ChartViewConfig _config;
        private readonly string _outputFolder;
        private readonly string _filename;
        private readonly int _chartWidth;
        private readonly int _chartHeight;
        private readonly int _volumePanelHeight;
        private readonly bool _enableArchive;
        private readonly string _archiveFolder;

        private Bars _bars;
        private Instrument _instrument;
        private bool _barsLoaded;
        private DateTime _lastExportTime;
        private DateTime _lastExportedBarTime;
        private bool _isDisposed;
        private readonly object _lockObject = new object();

        public string ViewId => $"{_config.InstrumentRoot}_{_config.TimeframePeriodDisplay}{_config.TimeframeTypeShort}";

        public ChartView(ChartViewConfig config, string outputFolder, bool enableArchive = false, string archiveFolder = null)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));
            _outputFolder = outputFolder ?? throw new ArgumentNullException(nameof(outputFolder));
            _enableArchive = enableArchive;
            _archiveFolder = archiveFolder;

            _filename = $"{_config.InstrumentRoot}_{_config.TimeframePeriodDisplay}{_config.TimeframeTypeShort}.png";
            _chartWidth = config.ChartWidth > 0 ? config.ChartWidth : 800;
            _chartHeight = config.ChartHeight > 0 ? config.ChartHeight : 600;
            _volumePanelHeight = config.ShowVolume ? 80 : 0;
            _lastExportTime = DateTime.MinValue;
        }
        
        public void InitializeBars()
        {
            try
            {
                _instrument = Instrument.GetInstrument(_config.InstrumentName);
                if (_instrument == null)
                {
                    LogMessage($"Instrument not found: {_config.InstrumentName}");
                    return;
                }

                LogMessage($"Instrument {_instrument.FullName}: TickSize={_instrument.MasterInstrument.TickSize}");

                var barsPeriod = new BarsPeriod
                {
                    BarsPeriodType = GetBarsPeriodType(_config.TimeframeType),
                    Value = _config.TimeframePeriod
                };

                // Request enough days of data to get barsBack bars
                int daysNeeded = CalculateDaysNeeded(_config.TimeframePeriod, _config.TimeframeType, _config.BarsBack);
                var toDate = DateTime.Now.AddMinutes(1); // Extend slightly past current time
                var fromDate = toDate.AddDays(-daysNeeded);

                LogMessage($"InitializeBars {ViewId}: Requesting from {fromDate:yyyy-MM-dd HH:mm} to {toDate:yyyy-MM-dd HH:mm}");

                var barsRequest = new BarsRequest(_instrument, fromDate, toDate);
                barsRequest.BarsPeriod = barsPeriod;
                barsRequest.TradingHours = TradingHours.Get("Default 24 x 7");
                barsRequest.MergePolicy = MergePolicy.MergeBackAdjusted;

                var waitHandle = new ManualResetEvent(false);

                // Callback receives (BarsRequest request, ErrorCode, string) - access bars via request.Bars
                barsRequest.Request((request, errorCode, errorMessage) =>
                {
                    if (errorCode == ErrorCode.NoError && request.Bars != null)
                    {
                        _bars = request.Bars;
                        _barsLoaded = true;

                        DateTime lastBarTime = DateTime.MinValue;
                        if (_bars.Count > 0)
                            lastBarTime = _bars.GetTime(_bars.Count - 1);

                        LogMessage($"Loaded {_bars.Count} bars for {ViewId}, lastBar={lastBarTime:yyyy-MM-dd HH:mm:ss}");
                    }
                    else
                    {
                        LogMessage($"BarsRequest failed for {ViewId}: {errorCode} - {errorMessage}");
                    }
                    waitHandle.Set();
                });

                // Wait for completion with timeout
                if (!waitHandle.WaitOne(TimeSpan.FromSeconds(60)))
                {
                    LogMessage($"BarsRequest timeout for {ViewId}");
                }
            }
            catch (Exception ex)
            {
                LogMessage($"InitializeBars error for {ViewId}: {ex.Message}");
            }
        }
        
        private int CalculateDaysNeeded(int period, string type, int barsBack)
        {
            // Estimate days needed to get enough bars
            switch (type?.ToLower())
            {
                case "minute":
                    // ~23 hours of trading per day for futures
                    int minutesPerDay = 23 * 60;
                    int totalMinutes = barsBack * period;
                    return Math.Max(7, (totalMinutes / minutesPerDay) + 5);
                case "day":
                    return barsBack + 10;
                case "tick":
                    return Math.Max(3, barsBack / 10000);
                default:
                    return 30;
            }
        }
        
        private BarsPeriodType GetBarsPeriodType(string type)
        {
            switch (type?.ToLower())
            {
                case "minute": return BarsPeriodType.Minute;
                case "second": return BarsPeriodType.Second;
                case "tick": return BarsPeriodType.Tick;
                case "day": return BarsPeriodType.Day;
                case "week": return BarsPeriodType.Week;
                case "month": return BarsPeriodType.Month;
                case "range": return BarsPeriodType.Range;
                case "volume": return BarsPeriodType.Volume;
                default: return BarsPeriodType.Minute;
            }
        }
        
        public bool ShouldExport(DateTime now)
        {
            // Check minimum interval first
            double elapsed = (now - _lastExportTime).TotalMilliseconds;
            if (elapsed < _config.ExportIntervalMs)
                return false;

            // Refresh bars to get latest data
            RefreshBars();

            // Check if we have a new bar close
            if (_bars == null || _bars.Count == 0)
            {
                LogMessage($"ShouldExport {ViewId}: No bars available");
                return false;
            }

            DateTime currentLastBarTime = _bars.GetTime(_bars.Count - 1);

            // First export or new bar detected
            if (_lastExportedBarTime == DateTime.MinValue)
            {
                LogMessage($"ShouldExport {ViewId}: First export, lastBar={currentLastBarTime:HH:mm:ss}");
                return true;
            }

            bool hasNewBar = currentLastBarTime > _lastExportedBarTime;
            if (hasNewBar)
            {
                LogMessage($"ShouldExport {ViewId}: New bar detected {_lastExportedBarTime:HH:mm:ss} -> {currentLastBarTime:HH:mm:ss}");
            }

            return hasNewBar;
        }

        private void RefreshBars()
        {
            if (_instrument == null) return;

            try
            {
                var barsPeriod = new BarsPeriod
                {
                    BarsPeriodType = GetBarsPeriodType(_config.TimeframeType),
                    Value = _config.TimeframePeriod
                };

                int daysNeeded = CalculateDaysNeeded(_config.TimeframePeriod, _config.TimeframeType, _config.BarsBack);
                var toDate = DateTime.Now.AddMinutes(1); // Extend slightly past current time
                var fromDate = toDate.AddDays(-daysNeeded);

                var barsRequest = new BarsRequest(_instrument, fromDate, toDate);
                barsRequest.BarsPeriod = barsPeriod;
                barsRequest.TradingHours = TradingHours.Get("Default 24 x 7");
                barsRequest.MergePolicy = MergePolicy.MergeBackAdjusted;

                var waitHandle = new ManualResetEvent(false);
                bool success = false;
                int barCount = 0;
                DateTime lastBarTime = DateTime.MinValue;

                barsRequest.Request((request, errorCode, errorMessage) =>
                {
                    if (errorCode == ErrorCode.NoError && request.Bars != null)
                    {
                        _bars = request.Bars;
                        _barsLoaded = true;
                        success = true;
                        barCount = _bars.Count;
                        if (barCount > 0)
                            lastBarTime = _bars.GetTime(_bars.Count - 1);
                    }
                    else
                    {
                        LogMessage($"RefreshBars {ViewId} error: {errorCode} - {errorMessage}");
                    }
                    waitHandle.Set();
                });

                if (!waitHandle.WaitOne(TimeSpan.FromSeconds(10)))
                {
                    LogMessage($"RefreshBars {ViewId}: Timeout waiting for bars");
                }
                else if (success)
                {
                    LogMessage($"RefreshBars {ViewId}: Got {barCount} bars, lastBar={lastBarTime:yyyy-MM-dd HH:mm:ss}");
                }
            }
            catch (Exception ex)
            {
                LogMessage($"RefreshBars error for {ViewId}: {ex.Message}");
            }
        }

        public void MarkExported(DateTime time)
        {
            _lastExportTime = time;
            if (_bars != null && _bars.Count > 0)
                _lastExportedBarTime = _bars.GetTime(_bars.Count - 1);
        }
        
        public ExportResult Export()
        {
            if (!_barsLoaded || _bars == null || _bars.Count == 0)
            {
                LogMessage($"Export {ViewId}: No bars loaded");
                return null;
            }

            LogMessage($"Export {ViewId}: Starting export with {_bars.Count} bars");

            lock (_lockObject)
            {
                try
                {
                    var bitmap = RenderChartToBitmap();
                    if (bitmap == null)
                    {
                        LogMessage($"Export {ViewId}: RenderChartToBitmap returned null");
                        return null;
                    }

                    var outputPath = Path.Combine(_outputFolder, _filename);
                    var tempPath = outputPath + ".tmp";

                    LogMessage($"Export {ViewId}: Writing to {outputPath}");

                    SaveBitmapAsPng(bitmap, tempPath);

                    // Check if temp file was created
                    if (!File.Exists(tempPath))
                    {
                        LogMessage($"Export {ViewId}: Temp file not created!");
                        return null;
                    }

                    if (File.Exists(outputPath))
                    {
                        try
                        {
                            File.Delete(outputPath);
                        }
                        catch (Exception delEx)
                        {
                            LogMessage($"Export {ViewId}: Failed to delete existing file: {delEx.Message}");
                            // Try to clean up temp file
                            try { File.Delete(tempPath); } catch { }
                            return null;
                        }
                    }

                    File.Move(tempPath, outputPath);

                    DateTime? lastBarTime = null;
                    if (_bars.Count > 0)
                        lastBarTime = _bars.GetTime(_bars.Count - 1);

                    LogMessage($"Export {ViewId}: SUCCESS - wrote {_filename}");

                    // Archive copy with timestamp if enabled
                    if (_enableArchive && !string.IsNullOrEmpty(_archiveFolder))
                    {
                        try
                        {
                            var now = DateTime.Now;
                            var nowUtc = DateTime.UtcNow;

                            // Create date/time subfolder: F:\gatekeeper_live_samples\2026-01-13\1430\
                            var dateFolder = Path.Combine(_archiveFolder, now.ToString("yyyy-MM-dd"));
                            var timeFolder = Path.Combine(dateFolder, now.ToString("HHmm"));
                            if (!Directory.Exists(timeFolder))
                                Directory.CreateDirectory(timeFolder);

                            // Simple filename without timestamp (folder provides context): NQ_1m.png
                            var archiveFilename = $"{_config.InstrumentRoot}_{_config.TimeframePeriodDisplay}{_config.TimeframeTypeShort}.png";
                            var archivePath = Path.Combine(timeFolder, archiveFilename);

                            File.Copy(outputPath, archivePath, overwrite: true);

                            // Create JSON metadata and append to labels.jsonl in time folder
                            var archiveMeta = new ArchiveMetadata
                            {
                                ImageFilename = archiveFilename,
                                Instrument = _config.InstrumentName,
                                Timeframe = $"{_config.TimeframePeriodDisplay}{_config.TimeframeTypeShort}",
                                ArchiveTimestamp = nowUtc.ToString("yyyy-MM-ddTHH:mm:ssZ"),
                                ArchiveTimestampLocal = now.ToString("yyyy-MM-dd HH:mm:ss"),
                                BarsInChart = _bars.Count
                            };

                            // Get last bar OHLCV data if available
                            if (_bars.Count > 0)
                            {
                                int lastIdx = _bars.Count - 1;
                                var barTime = _bars.GetTime(lastIdx);
                                archiveMeta.LastBarTime = barTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ");
                                archiveMeta.LastBarTimeLocal = barTime.ToString("yyyy-MM-dd HH:mm:ss");
                                archiveMeta.LastBarOpen = _bars.GetOpen(lastIdx);
                                archiveMeta.LastBarHigh = _bars.GetHigh(lastIdx);
                                archiveMeta.LastBarLow = _bars.GetLow(lastIdx);
                                archiveMeta.LastBarClose = _bars.GetClose(lastIdx);
                                archiveMeta.LastBarVolume = _bars.GetVolume(lastIdx);
                            }

                            // Append to labels.jsonl in the time folder
                            var labelsPath = Path.Combine(timeFolder, "labels.jsonl");
                            var jsonLine = SimpleJson.SerializeArchiveMetadata(archiveMeta) + Environment.NewLine;
                            File.AppendAllText(labelsPath, jsonLine);

                            LogMessage($"Export {ViewId}: Archived to {now:yyyy-MM-dd}\\{now:HHmm}\\{archiveFilename}");
                        }
                        catch (Exception archiveEx)
                        {
                            LogMessage($"Export {ViewId}: Archive failed - {archiveEx.Message}");
                        }
                    }

                    return new ExportResult
                    {
                        Filename = _filename,
                        Instrument = _config.InstrumentName,
                        Timeframe = $"{_config.TimeframePeriodDisplay}{_config.TimeframeTypeShort}",
                        LastBarTime = lastBarTime
                    };
                }
                catch (Exception ex)
                {
                    LogMessage($"Export error for {ViewId}: {ex.GetType().Name}: {ex.Message}");
                    return null;
                }
            }
        }
        
        private RenderTargetBitmap RenderChartToBitmap()
        {
            var canvas = new Canvas
            {
                Width = _chartWidth,
                Height = _chartHeight,
                Background = new SolidColorBrush(Color.FromRgb(24, 26, 31))
            };
            
            int mainPanelHeight = _chartHeight - _volumePanelHeight - 70;
            int rightMargin = 150;
            int leftMargin = 10;
            int topMargin = 35;
            int chartAreaWidth = _chartWidth - leftMargin - rightMargin;
            
            var barsData = ExtractBarsData();
            if (barsData.Count == 0) return null;
            
            // Price range with padding
            double minPrice = barsData.Min(b => b.Low);
            double maxPrice = barsData.Max(b => b.High);
            double priceRange = maxPrice - minPrice;
            double pricePadding = priceRange * 0.05;
            minPrice -= pricePadding;
            maxPrice += pricePadding;
            priceRange = maxPrice - minPrice;
            
            if (priceRange <= 0) priceRange = 1;
            
            // Bar dimensions
            double barWidth = (double)chartAreaWidth / barsData.Count;
            double candleWidth = Math.Max(1, barWidth * 0.7);
            double wickWidth = Math.Max(1, candleWidth * 0.2);
            
            // Draw candles
            for (int i = 0; i < barsData.Count; i++)
            {
                var bar = barsData[i];
                double x = leftMargin + (i * barWidth) + (barWidth / 2);
                
                double openY = topMargin + mainPanelHeight - ((bar.Open - minPrice) / priceRange * mainPanelHeight);
                double closeY = topMargin + mainPanelHeight - ((bar.Close - minPrice) / priceRange * mainPanelHeight);
                double highY = topMargin + mainPanelHeight - ((bar.High - minPrice) / priceRange * mainPanelHeight);
                double lowY = topMargin + mainPanelHeight - ((bar.Low - minPrice) / priceRange * mainPanelHeight);
                
                bool isBullish = bar.Close >= bar.Open;
                var candleColor = isBullish
                    ? new SolidColorBrush(Color.FromRgb(38, 166, 154))
                    : new SolidColorBrush(Color.FromRgb(239, 83, 80));
                
                // Wick
                var wick = new System.Windows.Shapes.Line
                {
                    X1 = x, Y1 = highY, X2 = x, Y2 = lowY,
                    Stroke = candleColor, StrokeThickness = wickWidth
                };
                canvas.Children.Add(wick);
                
                // Body
                double bodyTop = Math.Min(openY, closeY);
                double bodyHeight = Math.Max(1, Math.Abs(closeY - openY));
                
                var body = new System.Windows.Shapes.Rectangle
                {
                    Width = candleWidth, Height = bodyHeight, Fill = candleColor
                };
                Canvas.SetLeft(body, x - candleWidth / 2);
                Canvas.SetTop(body, bodyTop);
                canvas.Children.Add(body);
            }
            
            // Price scale
            DrawPriceScale(canvas, minPrice, maxPrice, rightMargin, topMargin, mainPanelHeight);
            
            // Time scale
            DrawTimeScale(canvas, barsData, leftMargin, chartAreaWidth, topMargin + mainPanelHeight);
            
            // Volume panel
            if (_config.ShowVolume && _volumePanelHeight > 0)
            {
                DrawVolumePanel(canvas, barsData, leftMargin, chartAreaWidth,
                    topMargin + mainPanelHeight + 25, _volumePanelHeight - 25, barWidth);
            }
            
            // Chart label
            DrawChartLabel(canvas, leftMargin, 5);
            
            // Render to bitmap
            canvas.Measure(new Size(_chartWidth, _chartHeight));
            canvas.Arrange(new Rect(0, 0, _chartWidth, _chartHeight));
            canvas.UpdateLayout();
            
            var bitmap = new RenderTargetBitmap(_chartWidth, _chartHeight, 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(canvas);
            
            return bitmap;
        }
        
        private void DrawPriceScale(Canvas canvas, double minPrice, double maxPrice,
            int rightMargin, int topMargin, int height)
        {
            double priceRange = maxPrice - minPrice;
            if (priceRange <= 0) return;

            // Get tick size from instrument metadata
            double tickSize = 0.01; // fallback
            if (_instrument?.MasterInstrument != null)
                tickSize = _instrument.MasterInstrument.TickSize;

            // Calculate a "nice" step that's a multiple of tickSize
            // Target approximately 6-10 labels
            int targetLabels = Math.Max(4, Math.Min(10, height / 60));
            double rawStep = priceRange / targetLabels;

            // Find the nearest "nice" multiple of tickSize
            // Nice multiples: 1, 2, 5, 10, 20, 25, 50, 100, etc. times tickSize
            double[] niceMultipliers = { 1, 2, 4, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000 };
            double stepInTicks = rawStep / tickSize;
            double bestMultiplier = 1;
            foreach (var mult in niceMultipliers)
            {
                if (mult >= stepInTicks)
                {
                    bestMultiplier = mult;
                    break;
                }
                bestMultiplier = mult;
            }
            double priceStep = bestMultiplier * tickSize;

            // Round minPrice down and maxPrice up to tick boundaries
            double tickAlignedMin = Math.Floor(minPrice / tickSize) * tickSize;
            double tickAlignedMax = Math.Ceiling(maxPrice / tickSize) * tickSize;

            // Find the first label price (round up from minPrice to next step boundary)
            double firstLabel = Math.Ceiling(tickAlignedMin / priceStep) * priceStep;

            var textColor = new SolidColorBrush(Color.FromRgb(160, 160, 160));

            // Draw labels at tick-aligned prices
            for (double price = firstLabel; price <= tickAlignedMax; price += priceStep)
            {
                double y = topMargin + height - ((price - minPrice) / priceRange * height);

                // Skip if outside visible area
                if (y < topMargin - 10 || y > topMargin + height + 10)
                    continue;

                // Use instrument's FormatPrice for proper formatting
                string priceText;
                if (_instrument?.MasterInstrument != null)
                    priceText = _instrument.MasterInstrument.FormatPrice(price);
                else
                    priceText = price.ToString("F2");

                var label = new TextBlock
                {
                    Text = priceText,
                    Foreground = textColor,
                    FontSize = 27,
                    FontFamily = new FontFamily("Consolas")
                };
                Canvas.SetLeft(label, _chartWidth - rightMargin + 4);
                Canvas.SetTop(label, y - 10);
                canvas.Children.Add(label);
            }
        }
        
        private void DrawTimeScale(Canvas canvas, List<BarData> bars, int leftMargin,
            int chartWidth, int topOffset)
        {
            if (bars.Count == 0) return;
            
            var textColor = new SolidColorBrush(Color.FromRgb(160, 160, 160));
            double barWidth = (double)chartWidth / bars.Count;
            int step = Math.Max(1, bars.Count / 6);
            
            for (int i = 0; i < bars.Count; i += step)
            {
                double x = leftMargin + (i * barWidth) + (barWidth / 2);
                var time = bars[i].Time;
                
                string timeStr = (_config.TimeframePeriod >= 1440 || _config.TimeframeType?.ToLower() == "day")
                    ? time.ToString("MM/dd")
                    : time.ToString("HH:mm");
                
                var label = new TextBlock
                {
                    Text = timeStr,
                    Foreground = textColor,
                    FontSize = 27,
                    FontFamily = new FontFamily("Consolas")
                };
                Canvas.SetLeft(label, x - 25);
                Canvas.SetTop(label, topOffset + 4);
                canvas.Children.Add(label);
            }
        }
        
        private void DrawVolumePanel(Canvas canvas, List<BarData> bars, int leftMargin,
            int chartWidth, int topOffset, int panelHeight, double barWidth)
        {
            if (bars.Count == 0) return;
            
            long maxVolume = bars.Max(b => b.Volume);
            if (maxVolume == 0) maxVolume = 1;
            
            for (int i = 0; i < bars.Count; i++)
            {
                var bar = bars[i];
                double x = leftMargin + (i * barWidth) + (barWidth / 2);
                double volHeight = ((double)bar.Volume / maxVolume) * panelHeight;
                
                bool isBullish = bar.Close >= bar.Open;
                var volColor = isBullish
                    ? new SolidColorBrush(Color.FromArgb(100, 38, 166, 154))
                    : new SolidColorBrush(Color.FromArgb(100, 239, 83, 80));
                
                double volBarWidth = Math.Max(1, barWidth * 0.7);
                
                var volBar = new System.Windows.Shapes.Rectangle
                {
                    Width = volBarWidth, Height = Math.Max(1, volHeight), Fill = volColor
                };
                Canvas.SetLeft(volBar, x - volBarWidth / 2);
                Canvas.SetTop(volBar, topOffset + panelHeight - volHeight);
                canvas.Children.Add(volBar);
            }
        }
        
        private void DrawChartLabel(Canvas canvas, int leftMargin, int topMargin)
        {
            var textColor = new SolidColorBrush(Color.FromRgb(200, 200, 200));
            var label = new TextBlock
            {
                Text = $"{_config.InstrumentRoot} {_config.TimeframePeriodDisplay}{_config.TimeframeTypeShort}",
                Foreground = textColor,
                FontSize = 27,
                FontWeight = FontWeights.Bold,
                FontFamily = new FontFamily("Segoe UI")
            };
            Canvas.SetLeft(label, leftMargin + 5);
            Canvas.SetTop(label, topMargin);
            canvas.Children.Add(label);
        }
        
        private List<BarData> ExtractBarsData()
        {
            var result = new List<BarData>();
            if (_bars == null || _bars.Count == 0) return result;
            
            // Get the last N bars based on barsBack config
            int startIdx = Math.Max(0, _bars.Count - _config.BarsBack);
            
            for (int i = startIdx; i < _bars.Count; i++)
            {
                result.Add(new BarData
                {
                    Time = _bars.GetTime(i),
                    Open = _bars.GetOpen(i),
                    High = _bars.GetHigh(i),
                    Low = _bars.GetLow(i),
                    Close = _bars.GetClose(i),
                    Volume = _bars.GetVolume(i)
                });
            }
            
            return result;
        }
        
        private void SaveBitmapAsPng(RenderTargetBitmap bitmap, string path)
        {
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using (var stream = new FileStream(path, FileMode.Create))
            {
                encoder.Save(stream);
            }
        }
        
        public void Dispose()
        {
            if (_isDisposed) return;
            lock (_lockObject)
            {
                _bars = null;
                _instrument = null;
                _isDisposed = true;
            }
        }
        
        private void LogMessage(string message)
        {
            NinjaTrader.Code.Output.Process($"[ChartView:{ViewId}] {message}", PrintTo.OutputTab1);
        }
    }
    
    internal class BarData
    {
        public DateTime Time { get; set; }
        public double Open { get; set; }
        public double High { get; set; }
        public double Low { get; set; }
        public double Close { get; set; }
        public long Volume { get; set; }
    }
}
