# Chart Export AddOn for NinjaTrader 8

Export NinjaTrader charts as PNG images for AI/ML vision model analysis.

## Features

- **Automatic chart export** - Exports on bar close, not fixed intervals
- **Multiple views** - Export different instruments and timeframes simultaneously
- **Off-screen rendering** - No visible windows required, works even when NT8 is minimized
- **AI-optimized output** - Clean candlestick charts with price/time scales
- **Tick-aligned price axis** - Price labels always respect the instrument's native tick size (e.g., 0.25 for NQ)
- **JSON metadata** - Each export cycle writes `meta.json` with timestamps and bar times
- **GUI configuration** - Easy setup via Tools menu with DataGrid editor
- **Volume panel** - Optional volume display below price chart
- **Atomic file writes** - Files are written to temp then renamed, preventing partial reads

## Installation

### Option 1: Import ZIP (Easiest)

1. Download `ChartExportAddOn.zip`
2. In NinjaTrader 8: **Tools → Import → NinjaScript Add-on...**
3. Select the downloaded ZIP file
4. Restart NinjaTrader 8

### Option 2: Manual Installation

1. Copy these 4 files to `Documents\NinjaTrader 8\bin\Custom\AddOns\`:
   - `ChartExportAddOn.cs`
   - `ChartExportConfigWindow.cs`
   - `ChartExportModels.cs`
   - `ChartPool.cs`

2. In NinjaTrader 8: **Tools → NinjaScript Editor**
3. Press **Ctrl+Shift+B** to compile (or F5)
4. Access via **Tools → Chart Export** in the Control Center

## Configuration File

On first run, create `ChartExportConfig.json` in your NinjaTrader 8 Documents folder:

**Location:** `Documents\NinjaTrader 8\ChartExportConfig.json`

Example configuration:
```json
{
  "baseCycleIntervalMs": 5000,
  "outputFolder": "C:\\NQBot\\chart_exports\\chart_images",
  "views": [
    {
      "enabled": true,
      "instrumentName": "NQ 03-26",
      "timeframePeriod": 15,
      "timeframeType": "Minute",
      "barsBack": 40,
      "exportIntervalMs": 60000,
      "showVolume": false,
      "chartWidth": 1280,
      "chartHeight": 720
    }
  ]
}
```

## Usage

### Menu Options

Access via **Tools → Chart Export** in the Control Center:

| Menu Item | Description |
|-----------|-------------|
| **Start Export** | Begin automatic export cycle (exports on bar close) |
| **Stop Export** | Stop exporting |
| **Configure...** | Open configuration window |
| **Reload Config** | Reload config without restart |
| **Open Config Folder** | Open folder containing config JSON |
| **Open Output** | Open folder containing exported PNGs |
| **Export Now** | Force immediate export (bypasses bar-close detection) |

### Configuration Window

Open **Tools → Chart Export → Configure...** to set up:

**Global Settings:**
- **Output Folder** - Where PNG files are saved
- **Base Cycle (ms)** - How often the export timer checks for new bars (default: 5000ms)

**Chart Views (DataGrid):**

| Column | Description |
|--------|-------------|
| Enabled | Toggle export for this view |
| Instrument | Full instrument name (e.g., `NQ 03-26`, `ES 03-26`) |
| TF Type | Minute, Day, Week, Tick, Second |
| Period | Timeframe value (1, 5, 15, 60, etc.) |
| Bars | Number of bars to display on chart |
| Export (ms) | Minimum interval between exports for this view |
| Volume | Show volume panel below chart |
| Width/Height | Image dimensions in pixels |

**Row Controls:**
- **Add View** - Add a new chart view
- **Duplicate** - Copy selected view
- **Remove** - Delete selected view
- **Move Up/Down** - Reorder views

### Bar-Close Detection

The addon intelligently exports only when a new bar closes:
- 15-minute chart exports at :00, :15, :30, :45
- 30-minute chart exports at :00, :30
- 60-minute chart exports at :00

This prevents redundant exports and ensures you always get complete bars.

### Output Files

Each configured view exports to:
```
{OutputFolder}\{InstrumentRoot}_{Period}{Type}.png
```

Examples: `NQ_15m.png`, `ES_5m.png`, `CL_60h.png` (60-minute shows as "h" for hour)

A `meta.json` file is written with each export cycle:
```json
{
  "cycleTimestamp": "2025-12-28T19:30:00.000Z",
  "cycleTimestampLocal": "2025-12-28T14:30:00.000-05:00",
  "imagesExported": 3,
  "images": [
    {
      "filename": "NQ_15m.png",
      "instrument": "NQ 03-26",
      "timeframe": "15m",
      "lastBarTime": "2025-12-28T19:15:00.000Z",
      "lastBarTimeLocal": "2025-12-28T14:15:00.000-05:00"
    }
  ]
}
```

## Recommended Settings for AI Vision Models

| Use Case | Width | Height | Notes |
|----------|-------|--------|-------|
| High detail | 1280 | 720 | Full analysis, larger files |
| Balanced | 800 | 600 | Good quality, faster processing |
| Fast/VL models | 600 | 400 | Quick inference, smaller files |

## Troubleshooting

**Debug log location:** `Documents\ChartExportDebug.log`

### Common Issues

1. **"Instrument not found"**
   - Ensure the instrument name matches exactly, including contract month
   - Example: `NQ 03-26` not `NQ` or `NQ03-26`

2. **No images exported**
   - Check that market is open (futures closed on weekends)
   - Verify instrument has valid data subscription
   - Ensure output folder exists and is writable
   - Check debug log for errors

3. **Menu doesn't appear**
   - Restart NinjaTrader 8
   - Check NinjaScript Output window for compilation errors

4. **Images not updating automatically**
   - Bar-close detection waits for new bars to complete
   - Use "Export Now" to force immediate export
   - During market close, no new bars = no new exports

### Windows Explorer Timestamp Display Bug

**Known Issue:** Windows Explorer may show stale timestamps on exported files even though the content is updated correctly.

This occurs because the addon uses atomic file writes (write to temp file, delete old, rename temp to final). Windows Explorer sometimes caches the old file's metadata.

**The files ARE being updated correctly.** You can verify with:
- PowerShell: `Get-ChildItem 'C:\path\to\output\*.png' | Select Name, LastWriteTime`
- Or simply open the image - it will show current price data

**Workarounds:**
- Press F5 in Explorer to refresh
- Close and reopen the Explorer window
- Navigate away from the folder and back

**Important:** Your AI/ML system will read the correct, fresh data regardless of what Explorer displays.

## Technical Details

- **Rendering:** WPF off-screen rendering with RenderTargetBitmap
- **Data:** BarsRequest API for historical/streaming bar data
- **Trading Hours:** Uses "Default 24 x 7" for futures
- **Price Axis:** Automatically aligned to instrument tick size using MasterInstrument.TickSize
- **File Format:** PNG with dark theme (background: #181A1F)
- **Chart Style:** Candlestick with green (#26A69A) bullish / red (#EF5350) bearish

## Requirements

- NinjaTrader 8
- Windows 10/11 (uses WPF for rendering)
- Valid market data subscription for configured instruments
- .NET Framework 4.8 (included with NT8)

## File Structure

```
Documents\NinjaTrader 8\
├── bin\Custom\AddOns\
│   ├── ChartExportAddOn.cs      # Main addon, menu integration
│   ├── ChartExportConfigWindow.cs # Configuration UI
│   ├── ChartExportModels.cs     # Data models, JSON parsing
│   └── ChartPool.cs             # Off-screen rendering
├── ChartExportConfig.json       # Your configuration
└── ChartExportDebug.log         # Debug output

Output Folder (configurable)\
├── NQ_15m.png
├── ES_5m.png
└── meta.json
```

## License

MIT License - See LICENSE file

## Author

PhillyFrank

## Contributing

Issues and pull requests welcome on GitHub!

## Changelog

### v1.0.0
- Initial release
- Off-screen chart rendering
- Bar-close detection for intelligent exports
- Tick-aligned price axis
- GUI configuration window
- Multiple instrument/timeframe support
