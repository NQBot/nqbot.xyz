# Chart Export AddOn for NinjaTrader 8

Export NinjaTrader charts as PNG images for AI/ML vision model analysis.

## Features

- **Automatic chart export** - Configurable intervals per instrument/timeframe
- **Multiple views** - Export different instruments and timeframes simultaneously
- **Off-screen rendering** - No visible windows required, runs in background
- **AI-optimized output** - Clean candlestick charts with price/time scales
- **JSON metadata** - Each export cycle writes `meta.json` with timestamps
- **GUI configuration** - Easy setup via Tools menu
- **Volume panel** - Optional volume display below price chart

## Installation

1. Copy these 4 files to `Documents\NinjaTrader 8\bin\Custom\AddOns\`:
   - `chartexportaddon.cs`
   - `ChartExportConfigWindow.cs`
   - `chartexportmodels.cs`
   - `chartpool.cs`

2. Restart NinjaTrader 8, or compile manually:
   - Go to **Tools → New NinjaScript → Compile**

3. Access via **Tools → Chart Export** in the Control Center

## Usage

### Menu Options

| Menu Item | Description |
|-----------|-------------|
| **Start Export** | Begin automatic export cycle |
| **Stop Export** | Stop exporting |
| **Configure...** | Open configuration window |
| **Reload Config** | Reload config without restart |
| **Open Config Folder** | Open folder containing config JSON |
| **Open Output** | Open folder containing exported PNGs |
| **Export Now** | Run single export cycle immediately |

### Configuration

Open **Tools → Chart Export → Configure...** to set up:

**Global Settings:**
- **Output Folder** - Where PNG files are saved
- **Base Cycle (ms)** - How often the export timer ticks (default: 1000ms)

**Chart Views:**
- **Enabled** - Toggle export for this view
- **Instrument** - Full instrument name (e.g., `ES 03-25`, `NQ 06-25`)
- **TF Type** - Minute, Day, Week, Tick, Second
- **Period** - Timeframe value (1, 5, 15, 60, etc.)
- **Bars** - Number of bars to display
- **Export (ms)** - Minimum interval between exports for this view
- **Volume** - Show volume panel below chart
- **Width/Height** - Image dimensions in pixels

### Output Files

Each configured view exports to:
```
{OutputFolder}\{Instrument}_{Period}{Type}.png
```

Example: `ES_5m.png`, `NQ_1m.png`, `CL_15m.png`

A `meta.json` file is also written with each cycle:
```json
{
  "cycleTimestamp": "2025-01-15T14:30:00.000Z",
  "cycleTimestampLocal": "2025-01-15T09:30:00.000-05:00",
  "imagesExported": 2,
  "images": [
    {
      "filename": "ES_5m.png",
      "instrument": "ES 03-25",
      "timeframe": "5m",
      "lastBarTime": "2025-01-15T14:25:00.000Z"
    }
  ]
}
```

## Recommended Settings for AI Vision Models

For faster processing with vision-language models:

| Use Case | Width | Height | Notes |
|----------|-------|--------|-------|
| High detail | 1280 | 720 | Full analysis |
| Balanced | 800 | 600 | Good quality, faster |
| Fast/VL models | 600 | 400 | Quick inference |

## Troubleshooting

**Debug log location:** `Documents\ChartExportDebug.log`

**Common issues:**

1. **"Instrument not found"** - Ensure the instrument name matches exactly (including contract month, e.g., `ES 03-25`)

2. **No images exported** - Check that:
   - Market is open or has historical data
   - Instrument is valid and has data
   - Output folder exists and is writable

3. **Menu doesn't appear** - Try restarting NinjaTrader. Check Output window for errors.

## Requirements

- NinjaTrader 8
- Windows (uses WPF for rendering)
- Valid market data subscription for configured instruments

## License

MIT License - See LICENSE file

## Author

PhillyFrank

## Contributing

Issues and pull requests welcome!
