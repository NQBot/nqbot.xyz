// ============================================================================
// ChartExportModels.cs - Configuration and Data Models
// ============================================================================
// Manual JSON parsing - no external dependencies required
// ============================================================================

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace NinjaTrader.NinjaScript.AddOns
{
    #region Manual JSON Helper
    
    /// <summary>
    /// Minimal JSON helper that works in NT8's restricted environment
    /// </summary>
    public static class SimpleJson
    {
        public static string Serialize(ChartExportConfig config)
        {
            var sb = new StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine($"  \"baseCycleIntervalMs\": {config.BaseCycleIntervalMs},");
            sb.AppendLine($"  \"outputFolder\": \"{EscapeString(config.OutputFolder)}\",");
            sb.AppendLine($"  \"enableArchive\": {config.EnableArchive.ToString().ToLower()},");
            sb.AppendLine($"  \"archiveFolder\": \"{EscapeString(config.ArchiveFolder)}\",");
            sb.AppendLine("  \"views\": [");
            
            for (int i = 0; i < config.Views.Count; i++)
            {
                var v = config.Views[i];
                sb.AppendLine("    {");
                sb.AppendLine($"      \"enabled\": {v.Enabled.ToString().ToLower()},");
                sb.AppendLine($"      \"instrumentName\": \"{EscapeString(v.InstrumentName)}\",");
                sb.AppendLine($"      \"timeframePeriod\": {v.TimeframePeriod},");
                sb.AppendLine($"      \"timeframeType\": \"{v.TimeframeType}\",");
                sb.AppendLine($"      \"barsBack\": {v.BarsBack},");
                sb.AppendLine($"      \"exportIntervalMs\": {v.ExportIntervalMs},");
                sb.AppendLine($"      \"showVolume\": {v.ShowVolume.ToString().ToLower()},");
                sb.AppendLine($"      \"chartWidth\": {v.ChartWidth},");
                sb.AppendLine($"      \"chartHeight\": {v.ChartHeight}");
                sb.Append("    }");
                if (i < config.Views.Count - 1) sb.Append(",");
                sb.AppendLine();
            }
            
            sb.AppendLine("  ]");
            sb.AppendLine("}");
            return sb.ToString();
        }
        
        public static ChartExportConfig DeserializeConfig(string json)
        {
            var config = new ChartExportConfig();

            // Parse baseCycleIntervalMs
            var cycleMatch = Regex.Match(json, @"""baseCycleIntervalMs""\s*:\s*(\d+)");
            if (cycleMatch.Success)
                config.BaseCycleIntervalMs = int.Parse(cycleMatch.Groups[1].Value);

            // Parse outputFolder
            var folderMatch = Regex.Match(json, @"""outputFolder""\s*:\s*""([^""]+)""");
            if (folderMatch.Success)
                config.OutputFolder = UnescapeString(folderMatch.Groups[1].Value);

            // Parse enableArchive
            var archiveEnabledMatch = Regex.Match(json, @"""enableArchive""\s*:\s*(true|false)");
            if (archiveEnabledMatch.Success)
                config.EnableArchive = archiveEnabledMatch.Groups[1].Value == "true";

            // Parse archiveFolder
            var archiveFolderMatch = Regex.Match(json, @"""archiveFolder""\s*:\s*""([^""]+)""");
            if (archiveFolderMatch.Success)
                config.ArchiveFolder = UnescapeString(archiveFolderMatch.Groups[1].Value);

            // Parse views array
            var viewsMatch = Regex.Match(json, @"""views""\s*:\s*\[(.*)\]", RegexOptions.Singleline);
            if (viewsMatch.Success)
            {
                var viewsJson = viewsMatch.Groups[1].Value;
                var viewMatches = Regex.Matches(viewsJson, @"\{([^{}]+)\}");
                
                foreach (Match vm in viewMatches)
                {
                    var viewJson = vm.Groups[1].Value;
                    var view = new ChartViewConfig();

                    var enabledMatch = Regex.Match(viewJson, @"""enabled""\s*:\s*(true|false)");
                    if (enabledMatch.Success) view.Enabled = enabledMatch.Groups[1].Value == "true";

                    var instMatch = Regex.Match(viewJson, @"""instrumentName""\s*:\s*""([^""]+)""");
                    if (instMatch.Success) view.InstrumentName = instMatch.Groups[1].Value;
                    
                    var periodMatch = Regex.Match(viewJson, @"""timeframePeriod""\s*:\s*(\d+)");
                    if (periodMatch.Success) view.TimeframePeriod = int.Parse(periodMatch.Groups[1].Value);
                    
                    var typeMatch = Regex.Match(viewJson, @"""timeframeType""\s*:\s*""([^""]+)""");
                    if (typeMatch.Success) view.TimeframeType = typeMatch.Groups[1].Value;
                    
                    var barsMatch = Regex.Match(viewJson, @"""barsBack""\s*:\s*(\d+)");
                    if (barsMatch.Success) view.BarsBack = int.Parse(barsMatch.Groups[1].Value);
                    
                    var intervalMatch = Regex.Match(viewJson, @"""exportIntervalMs""\s*:\s*(\d+)");
                    if (intervalMatch.Success) view.ExportIntervalMs = int.Parse(intervalMatch.Groups[1].Value);
                    
                    var volMatch = Regex.Match(viewJson, @"""showVolume""\s*:\s*(true|false)");
                    if (volMatch.Success) view.ShowVolume = volMatch.Groups[1].Value == "true";
                    
                    var widthMatch = Regex.Match(viewJson, @"""chartWidth""\s*:\s*(\d+)");
                    if (widthMatch.Success) view.ChartWidth = int.Parse(widthMatch.Groups[1].Value);
                    
                    var heightMatch = Regex.Match(viewJson, @"""chartHeight""\s*:\s*(\d+)");
                    if (heightMatch.Success) view.ChartHeight = int.Parse(heightMatch.Groups[1].Value);
                    
                    config.Views.Add(view);
                }
            }
            
            return config;
        }
        
        public static string SerializeMetadata(ExportMetadata meta)
        {
            var sb = new StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine($"  \"cycleTimestamp\": \"{meta.CycleTimestamp}\",");
            sb.AppendLine($"  \"cycleTimestampLocal\": \"{meta.CycleTimestampLocal}\",");
            sb.AppendLine($"  \"imagesExported\": {meta.ImagesExported},");
            sb.AppendLine("  \"images\": [");
            
            for (int i = 0; i < meta.Images.Count; i++)
            {
                var img = meta.Images[i];
                sb.AppendLine("    {");
                sb.AppendLine($"      \"filename\": \"{EscapeString(img.Filename)}\",");
                sb.AppendLine($"      \"instrument\": \"{EscapeString(img.Instrument)}\",");
                sb.AppendLine($"      \"timeframe\": \"{img.Timeframe}\",");
                sb.AppendLine($"      \"lastBarTime\": \"{img.LastBarTime ?? ""}\",");
                sb.AppendLine($"      \"lastBarTimeLocal\": \"{img.LastBarTimeLocal ?? ""}\"");
                sb.Append("    }");
                if (i < meta.Images.Count - 1) sb.Append(",");
                sb.AppendLine();
            }
            
            sb.AppendLine("  ]");
            sb.AppendLine("}");
            return sb.ToString();
        }
        
        public static string SerializeArchiveMetadata(ArchiveMetadata meta)
        {
            var sb = new StringBuilder();
            sb.Append("{");
            sb.Append($"\"imageFilename\":\"{EscapeString(meta.ImageFilename)}\",");
            sb.Append($"\"instrument\":\"{EscapeString(meta.Instrument)}\",");
            sb.Append($"\"timeframe\":\"{meta.Timeframe}\",");
            sb.Append($"\"archiveTimestamp\":\"{meta.ArchiveTimestamp}\",");
            sb.Append($"\"archiveTimestampLocal\":\"{meta.ArchiveTimestampLocal}\",");
            sb.Append($"\"lastBarTime\":\"{meta.LastBarTime ?? ""}\",");
            sb.Append($"\"lastBarTimeLocal\":\"{meta.LastBarTimeLocal ?? ""}\",");
            sb.Append($"\"lastBarOpen\":{meta.LastBarOpen.ToString(CultureInfo.InvariantCulture)},");
            sb.Append($"\"lastBarHigh\":{meta.LastBarHigh.ToString(CultureInfo.InvariantCulture)},");
            sb.Append($"\"lastBarLow\":{meta.LastBarLow.ToString(CultureInfo.InvariantCulture)},");
            sb.Append($"\"lastBarClose\":{meta.LastBarClose.ToString(CultureInfo.InvariantCulture)},");
            sb.Append($"\"lastBarVolume\":{meta.LastBarVolume},");
            sb.Append($"\"barsInChart\":{meta.BarsInChart}");
            sb.Append("}");
            return sb.ToString();
        }

        private static string EscapeString(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"");
        }
        
        private static string UnescapeString(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\\\", "\\").Replace("\\\"", "\"");
        }
    }
    
    #endregion
    
    #region Configuration Models
    
    public class ChartExportConfig
    {
        /// <summary>
        /// Base timer tick interval in ms (default 1000)
        /// </summary>
        public int BaseCycleIntervalMs { get; set; } = 1000;

        /// <summary>
        /// Output folder for PNG files (default: Documents\ChartExports\)
        /// </summary>
        public string OutputFolder { get; set; } = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ChartExports") + @"\";

        /// <summary>
        /// Enable archiving (saves timestamped copy to archive folder)
        /// </summary>
        public bool EnableArchive { get; set; } = false;

        /// <summary>
        /// Archive folder for timestamped copies (for ML training data)
        /// </summary>
        public string ArchiveFolder { get; set; } = @"F:\gatekeeper_live_samples";

        /// <summary>
        /// List of chart views to export
        /// </summary>
        public List<ChartViewConfig> Views { get; set; } = new List<ChartViewConfig>();
    }
    
    public class ChartViewConfig
    {
        /// <summary>
        /// Whether this view is enabled for export
        /// </summary>
        public bool Enabled { get; set; } = true;

        /// <summary>
        /// Full instrument name (e.g., "NQ 03-26")
        /// </summary>
        public string InstrumentName { get; set; }

        /// <summary>
        /// Timeframe period (1, 5, 15, 60, etc.)
        /// </summary>
        public int TimeframePeriod { get; set; } = 1;

        /// <summary>
        /// Timeframe type: "Minute", "Second", "Tick", "Day"
        /// </summary>
        public string TimeframeType { get; set; } = "Minute";

        /// <summary>
        /// Number of bars to display on chart
        /// </summary>
        public int BarsBack { get; set; } = 200;

        /// <summary>
        /// Per-view export interval in ms (throttling)
        /// </summary>
        public int ExportIntervalMs { get; set; } = 2000;
        
        /// <summary>
        /// Show volume panel below price
        /// </summary>
        public bool ShowVolume { get; set; } = false;
        
        /// <summary>
        /// Chart image width in pixels (lower = smaller file, faster for VL models)
        /// Suggested: 1200 for high-res, 800 for medium, 400-600 for VL models
        /// </summary>
        public int ChartWidth { get; set; } = 800;
        
        /// <summary>
        /// Chart image height in pixels
        /// Suggested: 800 for high-res, 600 for medium, 300-400 for VL models
        /// </summary>
        public int ChartHeight { get; set; } = 600;
        
        // Computed properties
        public string InstrumentRoot
        {
            get
            {
                if (string.IsNullOrEmpty(InstrumentName)) return "UNKNOWN";
                var name = InstrumentName.TrimStart('/');
                var parts = name.Split(new[] { ' ', '-' }, StringSplitOptions.RemoveEmptyEntries);
                return parts.Length > 0 ? parts[0] : name;
            }
        }
        
        public string TimeframeTypeShort
        {
            get
            {
                switch (TimeframeType?.ToLower())
                {
                    case "minute":
                        // Convert 60+ minutes to hours for cleaner filenames
                        if (TimeframePeriod >= 60 && TimeframePeriod % 60 == 0)
                            return "h";
                        return "m";
                    case "second": return "s";
                    case "tick": return "t";
                    case "day": return "D";
                    case "week": return "W";
                    case "month": return "M";
                    default: return "m";
                }
            }
        }

        /// <summary>
        /// Returns the period value for display (converts 60/240 minutes to 1/4 hours)
        /// </summary>
        public int TimeframePeriodDisplay
        {
            get
            {
                if (TimeframeType?.ToLower() == "minute" && TimeframePeriod >= 60 && TimeframePeriod % 60 == 0)
                    return TimeframePeriod / 60;
                return TimeframePeriod;
            }
        }
    }
    
    #endregion
    
    #region Export Models
    
    public class ExportResult
    {
        public string Filename { get; set; }
        public string Instrument { get; set; }
        public string Timeframe { get; set; }
        public DateTime? LastBarTime { get; set; }
    }
    
    public class ExportMetadata
    {
        public string CycleTimestamp { get; set; }
        public string CycleTimestampLocal { get; set; }
        public int ImagesExported { get; set; }
        public List<ImageMetadata> Images { get; set; } = new List<ImageMetadata>();
    }
    
    public class ImageMetadata
    {
        public string Filename { get; set; }
        public string Instrument { get; set; }
        public string Timeframe { get; set; }
        public string LastBarTime { get; set; }
        public string LastBarTimeLocal { get; set; }
    }

    /// <summary>
    /// Metadata for archived chart images (for ML training data)
    /// </summary>
    public class ArchiveMetadata
    {
        public string ImageFilename { get; set; }
        public string Instrument { get; set; }
        public string Timeframe { get; set; }
        public string ArchiveTimestamp { get; set; }
        public string ArchiveTimestampLocal { get; set; }
        public string LastBarTime { get; set; }
        public string LastBarTimeLocal { get; set; }
        public double LastBarOpen { get; set; }
        public double LastBarHigh { get; set; }
        public double LastBarLow { get; set; }
        public double LastBarClose { get; set; }
        public long LastBarVolume { get; set; }
        public int BarsInChart { get; set; }
    }

    #endregion
}
