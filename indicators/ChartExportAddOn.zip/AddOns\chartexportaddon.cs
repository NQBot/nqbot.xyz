// ============================================================================
// ChartExportAddOn - Chart Image Export for AI Processing
// ============================================================================
// Exports NinjaTrader charts as PNG images for AI/ML vision model analysis.
// Supports multiple instruments, timeframes, and configurable export intervals.
// ============================================================================

#region Using declarations
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    public class ChartExportAddOn : AddOnBase
    {
        private NTMenuItem _mainMenuItem;
        private ChartPool _chartPool;
        private DispatcherTimer _exportTimer;
        private ChartExportConfig _config;
        private string _configPath;
        private string _outputFolder;
        private bool _isRunning;
        private object _lockObject;
        private string _logPath;
        private ChartExportConfigWindow _configWindow;

        private void FileLog(string msg)
        {
            try
            {
                if (_logPath == null)
                    _logPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ChartExportDebug.log");
                File.AppendAllText(_logPath, DateTime.Now.ToString("HH:mm:ss.fff") + " " + msg + "\r\n");
            }
            catch { }
        }

        private void LogMessage(string msg)
        {
            try { NinjaTrader.Code.Output.Process("[ChartExport] " + msg, PrintTo.OutputTab1); } catch { }
        }

        protected override void OnStateChange()
        {
            try
            {
                FileLog("OnStateChange: " + State.ToString());

                if (State == State.SetDefaults)
                {
                    Description = "Chart Export AddOn";
                    Name = "ChartExportAddOn";
                    _lockObject = new object();
                    FileLog("SetDefaults OK");
                }
                else if (State == State.Active)
                {
                    FileLog("Active...");
                    _configPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NinjaTrader 8", "ChartExportConfig.json");
                    LoadConfiguration();
                    _outputFolder = (_config != null && !string.IsNullOrEmpty(_config.OutputFolder)) ? _config.OutputFolder : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ChartExports") + @"\";
                    EnsureOutputDirectory();
                    LogMessage("ChartExportAddOn loaded");
                    FileLog("Active OK");
                }
                else if (State == State.Terminated)
                {
                    FileLog("Terminated");
                    Cleanup();
                }
            }
            catch (Exception ex) { FileLog("OnStateChange ERR: " + ex.ToString()); }
        }

        protected override void OnWindowCreated(Window window)
        {
            try
            {
                string wtype = window.GetType().FullName ?? "null";
                string wtitle = "";
                try { wtitle = window.Title ?? ""; } catch { wtitle = "(error getting title)"; }
                FileLog("WindowCreated: Type=" + wtype + " Title=" + wtitle);

                // Check multiple ways to identify Control Center
                bool isCC = wtype.Contains("ControlCenter") ||
                           wtype.Contains("ControlCenterWindow") ||
                           wtitle.Contains("Control Center") ||
                           wtitle.Contains("NinjaTrader");

                if (!isCC)
                {
                    FileLog("  -> Skipping (not Control Center)");
                    return;
                }

                FileLog("  -> Control Center detected, scheduling menu addition...");
                window.Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() => { AddMenu(window); }));
            }
            catch (Exception ex)
            {
                FileLog("OnWindowCreated ERROR: " + ex.GetType().Name + ": " + ex.Message);
            }
        }

        private void AddMenu(Window window)
        {
            try
            {
                FileLog("AddMenu start for window: " + window.GetType().FullName);

                // Try NT8's FindFirst method for Tools menu (the standard NT8 way)
                MenuItem tools = null;

                // Method 1: Try to use FindFirst if available on ControlCenter
                try
                {
                    // Use reflection to call FindFirst("ControlCenterMenuItemTools")
                    var findFirstMethod = window.GetType().GetMethod("FindFirst", new Type[] { typeof(string) });
                    if (findFirstMethod != null)
                    {
                        FileLog("Found FindFirst method, trying ControlCenterMenuItemTools...");
                        var result = findFirstMethod.Invoke(window, new object[] { "ControlCenterMenuItemTools" });
                        if (result is MenuItem mi)
                        {
                            tools = mi;
                            FileLog("SUCCESS: Found Tools menu via FindFirst!");
                        }
                        else
                        {
                            FileLog("FindFirst returned: " + (result?.GetType().Name ?? "null"));
                        }
                    }
                    else
                    {
                        FileLog("FindFirst method not found on window type");
                    }
                }
                catch (Exception ex) { FileLog("FindFirst error: " + ex.Message); }

                // Method 2: Safe shallow search for Menu
                if (tools == null)
                {
                    FileLog("Trying safe shallow search...");
                    try
                    {
                        // Explore window structure safely (max 3 levels)
                        tools = SafeFindToolsMenu(window, 0);
                    }
                    catch (Exception ex) { FileLog("Safe search error: " + ex.Message); }
                }

                // Method 3: Schedule a deferred retry if not found
                if (tools == null)
                {
                    FileLog("Tools not found, scheduling deferred retry...");
                    var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
                    int retryCount = 0;
                    timer.Tick += (s, e) =>
                    {
                        retryCount++;
                        if (retryCount > 5)
                        {
                            timer.Stop();
                            FileLog("FAIL: Gave up after 5 retries");
                            return;
                        }
                        FileLog("Deferred retry " + retryCount);
                        try
                        {
                            var foundTools = SafeFindToolsMenu(window, 0);
                            if (foundTools != null)
                            {
                                timer.Stop();
                                FileLog("SUCCESS: Found Tools on retry " + retryCount);
                                AddChartExportSubmenu(foundTools);
                            }
                        }
                        catch (Exception ex) { FileLog("Retry error: " + ex.Message); }
                    };
                    timer.Start();
                    return;
                }

                if (tools == null) { FileLog("FAIL: Could not find Tools menu"); return; }

                FileLog("SUCCESS: Found Tools menu!");
                AddChartExportSubmenu(tools);
            }
            catch (Exception ex) { FileLog("AddMenu ERR: " + ex.ToString()); }
        }

        private void AddMenuRetry(Window window, int attempt)
        {
            if (attempt > 3)
            {
                FileLog("FAIL: Max retries reached, giving up on menu addition");
                return;
            }

            try
            {
                FileLog("AddMenuRetry attempt " + attempt);
                List<Menu> allMenus = new List<Menu>();
                FindAllMenus(window, allMenus, 0);
                var uniqueMenus = new HashSet<Menu>(allMenus);

                Menu menu = null;
                foreach (var m in uniqueMenus)
                {
                    int itemCount = 0;
                    try { itemCount = m.Items.Count; } catch { }
                    if (menu == null || itemCount > (menu?.Items?.Count ?? 0))
                        menu = m;
                }

                if (menu == null || menu.Items.Count < 2)
                {
                    FileLog("Still no suitable menu, scheduling another retry...");
                    var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(500) };
                    timer.Tick += (s, e) =>
                    {
                        timer.Stop();
                        AddMenuRetry(window, attempt + 1);
                    };
                    timer.Start();
                    return;
                }

                // Found menu, now find Tools
                MenuItem tools = null;
                foreach (object item in menu.Items)
                {
                    MenuItem mi = item as MenuItem;
                    if (mi != null)
                    {
                        string h = "";
                        try { h = mi.Header?.ToString()?.Replace("_", "") ?? ""; } catch { }
                        if (h.Equals("Tools", StringComparison.OrdinalIgnoreCase))
                            tools = mi;
                    }
                }

                if (tools == null)
                {
                    FileLog("FAIL: Found menu but no Tools item");
                    return;
                }

                FileLog("SUCCESS in retry: Found Tools menu!");
                AddChartExportSubmenu(tools);
            }
            catch (Exception ex)
            {
                FileLog("AddMenuRetry ERROR: " + ex.Message);
            }
        }

        private void AddChartExportSubmenu(MenuItem tools)
        {
            try
            {
                // Find an existing NTMenuItem in Tools to copy its style
                Style existingStyle = null;
                System.Windows.Media.Brush existingForeground = null;
                System.Windows.Media.FontFamily existingFontFamily = null;
                double existingFontSize = 12;

                foreach (var item in tools.Items)
                {
                    if (item is NTMenuItem existingItem)
                    {
                        existingStyle = existingItem.Style;
                        existingForeground = existingItem.Foreground;
                        existingFontFamily = existingItem.FontFamily;
                        existingFontSize = existingItem.FontSize;
                        FileLog($"Found existing NTMenuItem style: Font={existingFontFamily}, Size={existingFontSize}");
                        break;
                    }
                    else if (item is MenuItem mi && existingStyle == null)
                    {
                        existingForeground = mi.Foreground;
                        existingFontFamily = mi.FontFamily;
                        existingFontSize = mi.FontSize;
                    }
                }

                // Helper to apply style to NTMenuItem
                Action<NTMenuItem> applyStyle = (menuItem) =>
                {
                    if (existingStyle != null)
                        menuItem.Style = existingStyle;
                    if (existingForeground != null)
                        menuItem.Foreground = existingForeground;
                    if (existingFontFamily != null)
                        menuItem.FontFamily = existingFontFamily;
                    if (existingFontSize > 0)
                        menuItem.FontSize = existingFontSize;
                    menuItem.IsEnabled = true;
                };

                _mainMenuItem = new NTMenuItem();
                _mainMenuItem.Header = "Chart Export";
                applyStyle(_mainMenuItem);

                NTMenuItem start = new NTMenuItem();
                start.Header = "Start Export";
                applyStyle(start);
                start.Click += (s, e) => { try { StartExport(); } catch (Exception ex) { FileLog("StartExport error: " + ex.Message); } };
                _mainMenuItem.Items.Add(start);

                NTMenuItem stop = new NTMenuItem();
                stop.Header = "Stop Export";
                applyStyle(stop);
                stop.Click += (s, e) => { try { StopExport(); } catch (Exception ex) { FileLog("StopExport error: " + ex.Message); } };
                _mainMenuItem.Items.Add(stop);

                _mainMenuItem.Items.Add(new Separator());

                NTMenuItem configure = new NTMenuItem();
                configure.Header = "Configure...";
                applyStyle(configure);
                configure.Click += (s, e) => { try { OpenConfigWindow(); } catch (Exception ex) { FileLog("Configure error: " + ex.Message); } };
                _mainMenuItem.Items.Add(configure);

                NTMenuItem reload = new NTMenuItem();
                reload.Header = "Reload Config";
                applyStyle(reload);
                reload.Click += (s, e) => { try { ReloadConfiguration(); } catch (Exception ex) { FileLog("Reload error: " + ex.Message); } };
                _mainMenuItem.Items.Add(reload);

                NTMenuItem openCfg = new NTMenuItem();
                openCfg.Header = "Open Config Folder";
                applyStyle(openCfg);
                openCfg.Click += (s, e) => { try { OpenConfigFolder(); } catch (Exception ex) { FileLog("OpenConfig error: " + ex.Message); } };
                _mainMenuItem.Items.Add(openCfg);

                NTMenuItem openOut = new NTMenuItem();
                openOut.Header = "Open Output";
                applyStyle(openOut);
                openOut.Click += (s, e) => { try { OpenOutputFolder(); } catch (Exception ex) { FileLog("OpenOutput error: " + ex.Message); } };
                _mainMenuItem.Items.Add(openOut);

                _mainMenuItem.Items.Add(new Separator());

                NTMenuItem expNow = new NTMenuItem();
                expNow.Header = "Export Now";
                applyStyle(expNow);
                expNow.Click += (s, e) => { try { ExportSingleCycle(); } catch (Exception ex) { FileLog("ExportNow error: " + ex.Message); } };
                _mainMenuItem.Items.Add(expNow);

                NTMenuItem test = new NTMenuItem();
                test.Header = "Test";
                applyStyle(test);
                test.Click += (s, e) => { FileLog("Test clicked!"); LogMessage("Test OK"); MessageBox.Show("Chart Export is working!\nLog: " + _logPath); };
                _mainMenuItem.Items.Add(test);

                tools.Items.Add(_mainMenuItem);
                FileLog("Chart Export menu added successfully!");
                LogMessage("Chart Export ready");
            }
            catch (Exception ex)
            {
                FileLog("AddChartExportSubmenu ERROR: " + ex.Message);
            }
        }

        protected override void OnWindowDestroyed(Window window)
        {
            try { if (window.GetType().FullName.Contains("ControlCenter")) { _mainMenuItem = null; } } catch { }
        }

        private MenuItem SafeFindToolsMenu(DependencyObject parent, int depth)
        {
            // Safety: max 8 levels deep
            if (parent == null || depth > 8) return null;

            try
            {
                // Log what we're looking at (first 5 levels to see structure)
                if (depth <= 5)
                {
                    string typeName = parent.GetType().Name;
                    string extra = "";
                    // Log extra info for interesting types
                    if (parent is FrameworkElement fe && !string.IsNullOrEmpty(fe.Name))
                        extra = " Name='" + fe.Name + "'";
                    if (parent is ItemsControl ic)
                        extra += " Items=" + ic.Items.Count;
                    if (parent is ContentControl cc && cc.Content != null)
                        extra += " Content=" + cc.Content.GetType().Name;
                    FileLog(new string(' ', depth * 2) + "L" + depth + ": " + typeName + extra);
                }

                // If this is a Menu, search its items for Tools
                if (parent is Menu menu)
                {
                    FileLog(new string(' ', depth * 2) + "  Found Menu with " + menu.Items.Count + " items!");
                    foreach (var item in menu.Items)
                    {
                        if (item is MenuItem mi)
                        {
                            string header = "";
                            try { header = mi.Header?.ToString()?.Replace("_", "") ?? ""; } catch { }
                            FileLog(new string(' ', depth * 2) + "    MenuItem: '" + header + "'");
                            if (header.Equals("Tools", StringComparison.OrdinalIgnoreCase))
                            {
                                return mi;
                            }
                        }
                    }
                }

                // Search children (limited)
                int childCount = 0;
                try { childCount = System.Windows.Media.VisualTreeHelper.GetChildrenCount(parent); } catch { return null; }

                childCount = Math.Min(childCount, 50); // Safety limit

                for (int i = 0; i < childCount; i++)
                {
                    DependencyObject child = null;
                    try { child = System.Windows.Media.VisualTreeHelper.GetChild(parent, i); } catch { continue; }

                    var result = SafeFindToolsMenu(child, depth + 1);
                    if (result != null) return result;
                }
            }
            catch (Exception ex)
            {
                if (depth == 0) FileLog("SafeFindToolsMenu error: " + ex.Message);
            }

            return null;
        }

        private Menu FindMenu(DependencyObject p)
        {
            if (p == null) return null;
            try
            {
                if (p is Menu m) return m;
                int c = System.Windows.Media.VisualTreeHelper.GetChildrenCount(p);
                for (int i = 0; i < c; i++)
                {
                    var r = FindMenu(System.Windows.Media.VisualTreeHelper.GetChild(p, i));
                    if (r != null) return r;
                }
            }
            catch { }
            return null;
        }

        private void FindAllMenus(DependencyObject p, List<Menu> results, int depth = 0)
        {
            if (p == null || depth > 50) return; // Limit depth to prevent stack overflow
            try
            {
                if (p is Menu m) results.Add(m);

                // Search visual tree only (logical tree can cause cycles)
                int c = System.Windows.Media.VisualTreeHelper.GetChildrenCount(p);
                for (int i = 0; i < c; i++)
                {
                    FindAllMenus(System.Windows.Media.VisualTreeHelper.GetChild(p, i), results, depth + 1);
                }
            }
            catch { }
        }

        public void StartExport()
        {
            FileLog("StartExport called");
            if (_lockObject == null) _lockObject = new object();
            lock (_lockObject)
            {
                if (_isRunning) { FileLog("Already running"); LogMessage("Already running"); return; }
                if (_config == null || _config.Views == null || _config.Views.Count == 0)
                {
                    FileLog("No views configured");
                    LogMessage("No views");
                    return;
                }
                FileLog("Config has " + _config.Views.Count + " views, output=" + _outputFolder);

                if (_chartPool != null) _chartPool.Dispose();
                _chartPool = new ChartPool(_config, _outputFolder);

                // Initialize asynchronously then start timer
                Task.Run(() =>
                {
                    try
                    {
                        FileLog("Initializing chart pool...");
                        _chartPool.InitializeAsync().Wait();
                        FileLog("Chart pool initialized");

                        // Start timer on UI thread after init completes
                        Application.Current.Dispatcher.Invoke(() =>
                        {
                            _exportTimer = new DispatcherTimer(DispatcherPriority.Background);
                            _exportTimer.Interval = TimeSpan.FromMilliseconds(_config.BaseCycleIntervalMs);
                            _exportTimer.Tick += OnTick;
                            _exportTimer.Start();
                            FileLog("Timer started, interval=" + _config.BaseCycleIntervalMs + "ms");
                        });
                    }
                    catch (Exception ex)
                    {
                        FileLog("Init ERROR: " + ex.ToString());
                    }
                });

                _isRunning = true;
                LogMessage("Started");
                FileLog("Started");
            }
        }

        public void StopExport()
        {
            if (_lockObject == null) _lockObject = new object();
            lock (_lockObject)
            {
                if (!_isRunning) return;
                Application.Current.Dispatcher.Invoke(() => { if (_exportTimer != null) { _exportTimer.Stop(); _exportTimer = null; } });
                _isRunning = false;
                LogMessage("Stopped");
            }
        }

        private int _tickCount = 0;
        private void OnTick(object s, EventArgs e)
        {
            _tickCount++;
            try
            {
                if (_chartPool == null)
                {
                    FileLog("OnTick: chartPool is null");
                    return;
                }

                var r = _chartPool.RunExportCycle();
                if (r != null && r.Count > 0)
                {
                    FileLog("OnTick #" + _tickCount + ": Exported " + r.Count + " images");
                    WriteMetadata(DateTime.UtcNow, r);
                }
                else if (_tickCount <= 5 || _tickCount % 10 == 0)
                {
                    // Log first few ticks and every 10th after
                    FileLog("OnTick #" + _tickCount + ": No images exported");
                }
            }
            catch (Exception ex)
            {
                FileLog("OnTick ERROR: " + ex.Message);
            }
        }

        private void ExportSingleCycle()
        {
            FileLog("ExportSingleCycle called");
            Task.Run(() => {
                try
                {
                    FileLog("ExportSingleCycle: Creating/initializing pool...");
                    if (_chartPool == null)
                    {
                        FileLog("Creating new ChartPool, output=" + _outputFolder);
                        _chartPool = new ChartPool(_config, _outputFolder);
                    }
                    _chartPool.InitializeAsync().Wait();
                    FileLog("ExportSingleCycle: Pool initialized, running export...");

                    Application.Current.Dispatcher.Invoke(() => {
                        var r = _chartPool.RunExportCycle(forcedExport: true);
                        if (r != null && r.Count > 0)
                        {
                            FileLog("ExportSingleCycle: Exported " + r.Count + " images");
                            foreach (var img in r)
                                FileLog("  - " + img.Filename);
                            WriteMetadata(DateTime.UtcNow, r);
                            LogMessage("Exported " + r.Count);
                        }
                        else
                        {
                            FileLog("ExportSingleCycle: No images exported");
                            LogMessage("No images");
                        }
                    });
                }
                catch (Exception ex)
                {
                    FileLog("ExportSingleCycle ERROR: " + ex.ToString());
                }
            });
        }

        private void LoadConfiguration()
        {
            try
            {
                if (File.Exists(_configPath)) { _config = SimpleJson.DeserializeConfig(File.ReadAllText(_configPath)); FileLog("Loaded " + _config.Views.Count); }
                else { _config = CreateDefaultConfig(); SaveConfiguration(); FileLog("Created default"); }
            }
            catch { _config = CreateDefaultConfig(); }
        }

        private ChartExportConfig CreateDefaultConfig()
        {
            var c = new ChartExportConfig(); c.BaseCycleIntervalMs = 1000; c.OutputFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ChartExports") + @"\"; c.Views = new List<ChartViewConfig>();
            var v = new ChartViewConfig(); v.InstrumentName = "ES 00-00"; v.TimeframePeriod = 1; v.TimeframeType = "Minute"; v.BarsBack = 150; v.ExportIntervalMs = 2000; v.ChartWidth = 800; v.ChartHeight = 600;
            c.Views.Add(v);
            return c;
        }

        private void SaveConfiguration() { try { var d = Path.GetDirectoryName(_configPath); if (!Directory.Exists(d)) Directory.CreateDirectory(d); File.WriteAllText(_configPath, SimpleJson.Serialize(_config)); } catch { } }
        private void ReloadConfiguration() { bool w = _isRunning; if (w) StopExport(); LoadConfiguration(); if (_config != null) _outputFolder = _config.OutputFolder; if (_chartPool != null) _chartPool.Dispose(); _chartPool = new ChartPool(_config, _outputFolder); if (w) StartExport(); LogMessage("Reloaded"); }
        private void OpenConfigFolder() { try { System.Diagnostics.Process.Start("explorer.exe", Path.GetDirectoryName(_configPath)); } catch { } }
        private void OpenOutputFolder() { try { EnsureOutputDirectory(); System.Diagnostics.Process.Start("explorer.exe", _outputFolder); } catch { } }

        private void OpenConfigWindow()
        {
            try
            {
                // Only allow one config window at a time
                if (_configWindow != null && _configWindow.IsLoaded)
                {
                    _configWindow.Activate();
                    return;
                }

                _configWindow = new ChartExportConfigWindow(_configPath, () =>
                {
                    // This is called when "Save & Reload" is clicked
                    ReloadConfiguration();
                });

                _configWindow.Closed += (s, e) => { _configWindow = null; };
                _configWindow.Show();
                FileLog("Config window opened");
            }
            catch (Exception ex)
            {
                FileLog("OpenConfigWindow ERROR: " + ex.Message);
                MessageBox.Show("Error opening config window: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void WriteMetadata(DateTime t, List<ExportResult> r)
        {
            try
            {
                var m = new ExportMetadata(); m.CycleTimestamp = t.ToString("o"); m.CycleTimestampLocal = t.ToLocalTime().ToString("o"); m.ImagesExported = r.Count; m.Images = new List<ImageMetadata>();
                foreach (var x in r) { var im = new ImageMetadata(); im.Filename = x.Filename; im.Instrument = x.Instrument; im.Timeframe = x.Timeframe; im.LastBarTime = x.LastBarTime.HasValue ? x.LastBarTime.Value.ToString("o") : ""; im.LastBarTimeLocal = x.LastBarTime.HasValue ? x.LastBarTime.Value.ToLocalTime().ToString("o") : ""; m.Images.Add(im); }
                var p = Path.Combine(_outputFolder, "meta.json"); var tmp = p + ".tmp"; File.WriteAllText(tmp, SimpleJson.SerializeMetadata(m)); if (File.Exists(p)) File.Delete(p); File.Move(tmp, p);
            }
            catch { }
        }

        private void EnsureOutputDirectory() { try { if (!Directory.Exists(_outputFolder)) Directory.CreateDirectory(_outputFolder); } catch { } }
        private void Cleanup()
        {
            try
            {
                StopExport();
                if (_chartPool != null) { _chartPool.Dispose(); _chartPool = null; }
                if (_configWindow != null) { try { _configWindow.Close(); } catch { } _configWindow = null; }
            }
            catch { }
        }
    }
}