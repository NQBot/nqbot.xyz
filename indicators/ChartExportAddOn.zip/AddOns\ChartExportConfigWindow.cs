// ============================================================================
// ChartExportConfigWindow.cs - Configuration UI for Chart Export AddOn
// ============================================================================
// WPF Window built programmatically (no XAML) for NT8 compatibility
// ============================================================================

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Media;
using WinForms = System.Windows.Forms;

namespace NinjaTrader.NinjaScript.AddOns
{
    public class ChartExportConfigWindow : Window
    {
        private readonly string _configPath;
        private readonly Action _onReloadRequested;

        private TextBox _outputFolderBox;
        private TextBox _baseCycleBox;
        private CheckBox _enableArchiveBox;
        private TextBox _archiveFolderBox;
        private DataGrid _viewsGrid;
        private ObservableCollection<ViewConfigItem> _viewItems;
        private TextBlock _statusText;

        public ChartExportConfigWindow(string configPath, Action onReloadRequested)
        {
            _configPath = configPath;
            _onReloadRequested = onReloadRequested;

            InitializeWindow();
            LoadConfig();
        }

        private void InitializeWindow()
        {
            Title = "Chart Export Configuration";
            Width = 1100;
            Height = 650;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = new SolidColorBrush(Color.FromRgb(30, 30, 30));

            var mainGrid = new Grid();
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            mainGrid.Margin = new Thickness(10);

            // Global settings section
            var globalPanel = CreateGlobalSettingsPanel();
            Grid.SetRow(globalPanel, 0);
            mainGrid.Children.Add(globalPanel);

            // Views DataGrid
            var viewsPanel = CreateViewsPanel();
            Grid.SetRow(viewsPanel, 1);
            mainGrid.Children.Add(viewsPanel);

            // Row control buttons
            var rowControlPanel = CreateRowControlPanel();
            Grid.SetRow(rowControlPanel, 2);
            mainGrid.Children.Add(rowControlPanel);

            // Bottom buttons
            var buttonPanel = CreateButtonPanel();
            Grid.SetRow(buttonPanel, 3);
            mainGrid.Children.Add(buttonPanel);

            Content = mainGrid;
        }

        private StackPanel CreateGlobalSettingsPanel()
        {
            var panel = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };

            var headerText = new TextBlock
            {
                Text = "Global Settings",
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 0, 0, 8)
            };
            panel.Children.Add(headerText);

            var settingsGrid = new Grid();
            settingsGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            settingsGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(400) });
            settingsGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            settingsGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            settingsGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(100) });
            settingsGrid.RowDefinitions.Add(new RowDefinition());
            settingsGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(8) }); // Spacer
            settingsGrid.RowDefinitions.Add(new RowDefinition());

            // Row 0: Output Folder
            var folderLabel = CreateLabel("Output Folder:");
            Grid.SetColumn(folderLabel, 0);
            Grid.SetRow(folderLabel, 0);
            settingsGrid.Children.Add(folderLabel);

            _outputFolderBox = CreateTextBox();
            _outputFolderBox.Width = 380;
            Grid.SetColumn(_outputFolderBox, 1);
            Grid.SetRow(_outputFolderBox, 0);
            settingsGrid.Children.Add(_outputFolderBox);

            var browseBtn = CreateButton("Browse...", 70);
            browseBtn.Click += (s, e) => BrowseFolder();
            Grid.SetColumn(browseBtn, 2);
            Grid.SetRow(browseBtn, 0);
            settingsGrid.Children.Add(browseBtn);

            // Base Cycle Interval
            var cycleLabel = CreateLabel("Base Cycle (ms):");
            cycleLabel.Margin = new Thickness(20, 0, 5, 0);
            Grid.SetColumn(cycleLabel, 3);
            Grid.SetRow(cycleLabel, 0);
            settingsGrid.Children.Add(cycleLabel);

            _baseCycleBox = CreateTextBox();
            _baseCycleBox.Width = 80;
            Grid.SetColumn(_baseCycleBox, 4);
            Grid.SetRow(_baseCycleBox, 0);
            settingsGrid.Children.Add(_baseCycleBox);

            // Row 2: Archive Settings
            _enableArchiveBox = new CheckBox
            {
                Content = "Enable Archive",
                Foreground = Brushes.White,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 10, 0)
            };
            Grid.SetColumn(_enableArchiveBox, 0);
            Grid.SetRow(_enableArchiveBox, 2);
            settingsGrid.Children.Add(_enableArchiveBox);

            _archiveFolderBox = CreateTextBox();
            _archiveFolderBox.Width = 380;
            Grid.SetColumn(_archiveFolderBox, 1);
            Grid.SetRow(_archiveFolderBox, 2);
            settingsGrid.Children.Add(_archiveFolderBox);

            var archiveBrowseBtn = CreateButton("Browse...", 70);
            archiveBrowseBtn.Click += (s, e) => BrowseArchiveFolder();
            Grid.SetColumn(archiveBrowseBtn, 2);
            Grid.SetRow(archiveBrowseBtn, 2);
            settingsGrid.Children.Add(archiveBrowseBtn);

            var archiveHint = CreateLabel("(timestamped copies for ML training)");
            archiveHint.Foreground = Brushes.Gray;
            archiveHint.FontSize = 11;
            archiveHint.Margin = new Thickness(20, 0, 0, 0);
            Grid.SetColumn(archiveHint, 3);
            Grid.SetColumnSpan(archiveHint, 2);
            Grid.SetRow(archiveHint, 2);
            settingsGrid.Children.Add(archiveHint);

            panel.Children.Add(settingsGrid);
            return panel;
        }

        private void BrowseArchiveFolder()
        {
            try
            {
                var dialog = new WinForms.FolderBrowserDialog();
                dialog.SelectedPath = _archiveFolderBox.Text;
                if (dialog.ShowDialog() == WinForms.DialogResult.OK)
                {
                    _archiveFolderBox.Text = dialog.SelectedPath;
                    if (!_archiveFolderBox.Text.EndsWith("\\"))
                        _archiveFolderBox.Text += "\\";
                }
            }
            catch
            {
                MessageBox.Show("Please type the folder path directly.", "Browse Not Available", MessageBoxButton.OK);
            }
        }

        private Grid CreateViewsPanel()
        {
            var panel = new Grid { Margin = new Thickness(0, 5, 0, 5) };

            var headerText = new TextBlock
            {
                Text = "Chart Views",
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 0, 0, 5)
            };

            panel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            panel.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            Grid.SetRow(headerText, 0);
            panel.Children.Add(headerText);

            _viewItems = new ObservableCollection<ViewConfigItem>();

            _viewsGrid = new DataGrid
            {
                AutoGenerateColumns = false,
                CanUserAddRows = false,
                CanUserDeleteRows = false,
                CanUserReorderColumns = false,
                SelectionMode = DataGridSelectionMode.Single,
                Background = new SolidColorBrush(Color.FromRgb(45, 45, 45)),
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(60, 60, 60)),
                GridLinesVisibility = DataGridGridLinesVisibility.All,
                HorizontalGridLinesBrush = new SolidColorBrush(Color.FromRgb(60, 60, 60)),
                VerticalGridLinesBrush = new SolidColorBrush(Color.FromRgb(60, 60, 60)),
                RowBackground = new SolidColorBrush(Color.FromRgb(45, 45, 45)),
                AlternatingRowBackground = new SolidColorBrush(Color.FromRgb(50, 50, 50)),
                HeadersVisibility = DataGridHeadersVisibility.Column,
                ItemsSource = _viewItems
            };

            // Style for column headers
            var headerStyle = new Style(typeof(DataGridColumnHeader));
            headerStyle.Setters.Add(new Setter(BackgroundProperty, new SolidColorBrush(Color.FromRgb(60, 60, 60))));
            headerStyle.Setters.Add(new Setter(ForegroundProperty, Brushes.White));
            headerStyle.Setters.Add(new Setter(PaddingProperty, new Thickness(5, 3, 5, 3)));
            headerStyle.Setters.Add(new Setter(BorderBrushProperty, new SolidColorBrush(Color.FromRgb(80, 80, 80))));
            headerStyle.Setters.Add(new Setter(BorderThicknessProperty, new Thickness(0, 0, 1, 1)));
            _viewsGrid.ColumnHeaderStyle = headerStyle;

            // Define columns
            _viewsGrid.Columns.Add(new DataGridCheckBoxColumn
            {
                Header = "Enabled",
                Binding = new Binding("Enabled") { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
                Width = 60
            });

            _viewsGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Instrument",
                Binding = new Binding("InstrumentName") { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
                Width = 120
            });

            // Timeframe Type as ComboBox
            var tfTypeColumn = new DataGridComboBoxColumn
            {
                Header = "TF Type",
                SelectedItemBinding = new Binding("TimeframeType") { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
                Width = 80
            };
            tfTypeColumn.ItemsSource = new[] { "Minute", "Day", "Week", "Tick", "Second" };
            _viewsGrid.Columns.Add(tfTypeColumn);

            _viewsGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Period",
                Binding = new Binding("TimeframePeriod") { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
                Width = 55
            });

            _viewsGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Bars",
                Binding = new Binding("BarsBack") { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
                Width = 50
            });

            _viewsGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Export (ms)",
                Binding = new Binding("ExportIntervalMs") { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
                Width = 80
            });

            _viewsGrid.Columns.Add(new DataGridCheckBoxColumn
            {
                Header = "Volume",
                Binding = new Binding("ShowVolume") { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
                Width = 55
            });

            _viewsGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Width",
                Binding = new Binding("ChartWidth") { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
                Width = 55
            });

            _viewsGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Height",
                Binding = new Binding("ChartHeight") { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
                Width = 55
            });

            Grid.SetRow(_viewsGrid, 1);
            panel.Children.Add(_viewsGrid);

            return panel;
        }

        private StackPanel CreateRowControlPanel()
        {
            var panel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Left,
                Margin = new Thickness(0, 5, 0, 10)
            };

            var addBtn = CreateButton("Add View", 80);
            addBtn.Click += (s, e) => AddView();
            panel.Children.Add(addBtn);

            var dupBtn = CreateButton("Duplicate", 80);
            dupBtn.Click += (s, e) => DuplicateView();
            panel.Children.Add(dupBtn);

            var removeBtn = CreateButton("Remove", 70);
            removeBtn.Click += (s, e) => RemoveView();
            panel.Children.Add(removeBtn);

            var upBtn = CreateButton("Move Up", 70);
            upBtn.Click += (s, e) => MoveViewUp();
            panel.Children.Add(upBtn);

            var downBtn = CreateButton("Move Down", 80);
            downBtn.Click += (s, e) => MoveViewDown();
            panel.Children.Add(downBtn);

            return panel;
        }

        private Grid CreateButtonPanel()
        {
            var panel = new Grid { Margin = new Thickness(0, 10, 0, 0) };
            panel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            panel.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            _statusText = new TextBlock
            {
                Foreground = Brushes.LightGray,
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(_statusText, 0);
            panel.Children.Add(_statusText);

            var buttonStack = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right
            };

            var saveBtn = CreateButton("Save", 80);
            saveBtn.Click += (s, e) => Save(reload: false);
            buttonStack.Children.Add(saveBtn);

            var saveReloadBtn = CreateButton("Save && Reload", 100);
            saveReloadBtn.Click += (s, e) => Save(reload: true);
            buttonStack.Children.Add(saveReloadBtn);

            var cancelBtn = CreateButton("Cancel", 80);
            cancelBtn.Click += (s, e) => Close();
            buttonStack.Children.Add(cancelBtn);

            Grid.SetColumn(buttonStack, 1);
            panel.Children.Add(buttonStack);

            return panel;
        }

        private TextBlock CreateLabel(string text)
        {
            return new TextBlock
            {
                Text = text,
                Foreground = Brushes.White,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 5, 0)
            };
        }

        private TextBox CreateTextBox()
        {
            return new TextBox
            {
                Background = new SolidColorBrush(Color.FromRgb(50, 50, 50)),
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(80, 80, 80)),
                Padding = new Thickness(3),
                Margin = new Thickness(0, 0, 5, 0)
            };
        }

        private Button CreateButton(string text, int width)
        {
            return new Button
            {
                Content = text,
                Width = width,
                Height = 26,
                Margin = new Thickness(3),
                Background = new SolidColorBrush(Color.FromRgb(60, 60, 60)),
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(80, 80, 80))
            };
        }

        private void LoadConfig()
        {
            try
            {
                _viewItems.Clear();

                ChartExportConfig config = null;
                if (File.Exists(_configPath))
                {
                    var json = File.ReadAllText(_configPath);
                    config = SimpleJson.DeserializeConfig(json);
                }

                if (config == null)
                {
                    config = new ChartExportConfig();
                    config.Views.Add(new ChartViewConfig
                    {
                        Enabled = true,
                        InstrumentName = "ES 00-00",
                        TimeframePeriod = 1,
                        TimeframeType = "Minute",
                        BarsBack = 200,
                        ExportIntervalMs = 60000,
                        ChartWidth = 1280,
                        ChartHeight = 720
                    });
                }

                _outputFolderBox.Text = config.OutputFolder ?? System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ChartExports") + @"\";
                _baseCycleBox.Text = config.BaseCycleIntervalMs.ToString();
                _enableArchiveBox.IsChecked = config.EnableArchive;
                _archiveFolderBox.Text = config.ArchiveFolder ?? @"F:\gatekeeper_live_samples";

                foreach (var view in config.Views)
                {
                    _viewItems.Add(new ViewConfigItem
                    {
                        Enabled = view.Enabled,
                        InstrumentName = view.InstrumentName ?? "",
                        TimeframeType = view.TimeframeType ?? "Minute",
                        TimeframePeriod = view.TimeframePeriod,
                        BarsBack = view.BarsBack,
                        ExportIntervalMs = view.ExportIntervalMs,
                        ShowVolume = view.ShowVolume,
                        ChartWidth = view.ChartWidth > 0 ? view.ChartWidth : 1280,
                        ChartHeight = view.ChartHeight > 0 ? view.ChartHeight : 720
                    });
                }

                _statusText.Text = $"Loaded {_viewItems.Count} views";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading config: {ex.Message}", "Load Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                _statusText.Text = "Error loading config";
            }
        }

        private void BrowseFolder()
        {
            try
            {
                var dialog = new WinForms.FolderBrowserDialog();
                dialog.SelectedPath = _outputFolderBox.Text;
                if (dialog.ShowDialog() == WinForms.DialogResult.OK)
                {
                    _outputFolderBox.Text = dialog.SelectedPath;
                    if (!_outputFolderBox.Text.EndsWith("\\"))
                        _outputFolderBox.Text += "\\";
                }
            }
            catch
            {
                // Fallback if Windows.Forms not available
                MessageBox.Show("Please type the folder path directly.", "Browse Not Available", MessageBoxButton.OK);
            }
        }

        private void AddView()
        {
            _viewItems.Add(new ViewConfigItem
            {
                Enabled = true,
                InstrumentName = "ES 00-00",
                TimeframeType = "Minute",
                TimeframePeriod = 1,
                BarsBack = 200,
                ExportIntervalMs = 60000,
                ShowVolume = false,
                ChartWidth = 1280,
                ChartHeight = 720
            });
            _viewsGrid.SelectedIndex = _viewItems.Count - 1;
        }

        private void DuplicateView()
        {
            if (_viewsGrid.SelectedItem is ViewConfigItem selected)
            {
                var copy = new ViewConfigItem
                {
                    Enabled = selected.Enabled,
                    InstrumentName = selected.InstrumentName,
                    TimeframeType = selected.TimeframeType,
                    TimeframePeriod = selected.TimeframePeriod,
                    BarsBack = selected.BarsBack,
                    ExportIntervalMs = selected.ExportIntervalMs,
                    ShowVolume = selected.ShowVolume,
                    ChartWidth = selected.ChartWidth,
                    ChartHeight = selected.ChartHeight
                };
                int idx = _viewItems.IndexOf(selected);
                _viewItems.Insert(idx + 1, copy);
                _viewsGrid.SelectedIndex = idx + 1;
            }
        }

        private void RemoveView()
        {
            if (_viewsGrid.SelectedItem is ViewConfigItem selected)
            {
                int idx = _viewItems.IndexOf(selected);
                _viewItems.Remove(selected);
                if (_viewItems.Count > 0)
                    _viewsGrid.SelectedIndex = Math.Min(idx, _viewItems.Count - 1);
            }
        }

        private void MoveViewUp()
        {
            if (_viewsGrid.SelectedItem is ViewConfigItem selected)
            {
                int idx = _viewItems.IndexOf(selected);
                if (idx > 0)
                {
                    _viewItems.Move(idx, idx - 1);
                    _viewsGrid.SelectedIndex = idx - 1;
                }
            }
        }

        private void MoveViewDown()
        {
            if (_viewsGrid.SelectedItem is ViewConfigItem selected)
            {
                int idx = _viewItems.IndexOf(selected);
                if (idx < _viewItems.Count - 1)
                {
                    _viewItems.Move(idx, idx + 1);
                    _viewsGrid.SelectedIndex = idx + 1;
                }
            }
        }

        private bool Validate(out List<string> errors)
        {
            errors = new List<string>();

            // Validate global settings
            if (string.IsNullOrWhiteSpace(_outputFolderBox.Text))
                errors.Add("Output folder is required");

            if (!int.TryParse(_baseCycleBox.Text, out int baseCycle) || baseCycle < 100)
                errors.Add("Base cycle must be >= 100 ms");

            // Validate views
            for (int i = 0; i < _viewItems.Count; i++)
            {
                var v = _viewItems[i];
                string prefix = $"View {i + 1}: ";

                if (string.IsNullOrWhiteSpace(v.InstrumentName))
                    errors.Add(prefix + "Instrument name is required");

                if (v.TimeframePeriod <= 0)
                    errors.Add(prefix + "Timeframe period must be > 0");

                if (v.BarsBack <= 0)
                    errors.Add(prefix + "Bars back must be > 0");

                if (v.ExportIntervalMs < 250)
                    errors.Add(prefix + "Export interval must be >= 250 ms");

                if (v.ChartWidth < 100)
                    errors.Add(prefix + "Chart width must be >= 100");

                if (v.ChartHeight < 100)
                    errors.Add(prefix + "Chart height must be >= 100");

                // Coerce unknown timeframe types
                var validTypes = new[] { "Minute", "Day", "Week", "Tick", "Second" };
                if (!validTypes.Contains(v.TimeframeType))
                {
                    v.TimeframeType = "Minute";
                    errors.Add(prefix + $"Unknown timeframe type, defaulted to Minute");
                }
            }

            return errors.Count == 0;
        }

        private void Save(bool reload)
        {
            if (!Validate(out var errors))
            {
                string message = "Please fix the following issues:\n\n" + string.Join("\n", errors);
                MessageBox.Show(message, "Validation Errors", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Build config object
                var config = new ChartExportConfig
                {
                    OutputFolder = _outputFolderBox.Text,
                    BaseCycleIntervalMs = int.Parse(_baseCycleBox.Text),
                    EnableArchive = _enableArchiveBox.IsChecked == true,
                    ArchiveFolder = _archiveFolderBox.Text,
                    Views = new List<ChartViewConfig>()
                };

                foreach (var item in _viewItems)
                {
                    config.Views.Add(new ChartViewConfig
                    {
                        Enabled = item.Enabled,
                        InstrumentName = item.InstrumentName,
                        TimeframeType = item.TimeframeType,
                        TimeframePeriod = item.TimeframePeriod,
                        BarsBack = item.BarsBack,
                        ExportIntervalMs = item.ExportIntervalMs,
                        ShowVolume = item.ShowVolume,
                        ChartWidth = item.ChartWidth,
                        ChartHeight = item.ChartHeight
                    });
                }

                // Ensure output folder exists
                if (!Directory.Exists(config.OutputFolder))
                {
                    var result = MessageBox.Show(
                        $"Output folder does not exist:\n{config.OutputFolder}\n\nCreate it?",
                        "Create Folder?",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);

                    if (result == MessageBoxResult.Yes)
                        Directory.CreateDirectory(config.OutputFolder);
                    else
                        return;
                }

                // Atomic write
                var dir = Path.GetDirectoryName(_configPath);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                var tempPath = _configPath + ".tmp";
                var json = SimpleJson.Serialize(config);
                File.WriteAllText(tempPath, json);

                if (File.Exists(_configPath))
                    File.Delete(_configPath);
                File.Move(tempPath, _configPath);

                _statusText.Text = $"Saved {config.Views.Count} views";

                if (reload)
                {
                    _onReloadRequested?.Invoke();
                    _statusText.Text = $"Saved and reloaded {config.Views.Count} views";
                }

                MessageBox.Show(
                    reload ? "Configuration saved and reloaded." : "Configuration saved.",
                    "Success",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving config: {ex.Message}", "Save Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    /// <summary>
    /// ViewModel item for DataGrid binding
    /// </summary>
    public class ViewConfigItem : INotifyPropertyChanged
    {
        private bool _enabled;
        private string _instrumentName;
        private string _timeframeType;
        private int _timeframePeriod;
        private int _barsBack;
        private int _exportIntervalMs;
        private bool _showVolume;
        private int _chartWidth;
        private int _chartHeight;

        public bool Enabled
        {
            get => _enabled;
            set { _enabled = value; OnPropertyChanged(nameof(Enabled)); }
        }

        public string InstrumentName
        {
            get => _instrumentName;
            set { _instrumentName = value; OnPropertyChanged(nameof(InstrumentName)); }
        }

        public string TimeframeType
        {
            get => _timeframeType;
            set { _timeframeType = value; OnPropertyChanged(nameof(TimeframeType)); }
        }

        public int TimeframePeriod
        {
            get => _timeframePeriod;
            set { _timeframePeriod = value; OnPropertyChanged(nameof(TimeframePeriod)); }
        }

        public int BarsBack
        {
            get => _barsBack;
            set { _barsBack = value; OnPropertyChanged(nameof(BarsBack)); }
        }

        public int ExportIntervalMs
        {
            get => _exportIntervalMs;
            set { _exportIntervalMs = value; OnPropertyChanged(nameof(ExportIntervalMs)); }
        }

        public bool ShowVolume
        {
            get => _showVolume;
            set { _showVolume = value; OnPropertyChanged(nameof(ShowVolume)); }
        }

        public int ChartWidth
        {
            get => _chartWidth;
            set { _chartWidth = value; OnPropertyChanged(nameof(ChartWidth)); }
        }

        public int ChartHeight
        {
            get => _chartHeight;
            set { _chartHeight = value; OnPropertyChanged(nameof(ChartHeight)); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
