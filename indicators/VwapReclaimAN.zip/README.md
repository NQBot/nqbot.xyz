# VWAP Reclaim — strategy + manual signal indicator (NinjaTrader 8)

Two files. One set of rules.

- **`Indicators/VwapReclaimFollow.cs`** — plots the session VWAP, tracks the
  break/reclaim state, prices the entry, stop and target, alerts you, and places **no
  orders**. This is the one to use on a funded or evaluation account.
- **`Strategies/VWAPReclaimAN.cs`** — the automated version, for simulation, Market
  Replay and your own capital. It does not contain a copy of the entry rules; it calls
  the indicator for them.

That second point is the whole design. There is exactly one copy of the signal logic in
this package, so the chart cannot drift away from what the strategy does.

---

## The setup

1. **Break.** A bar closes clear of the session VWAP by at least **5 points**.
2. **Reclaim.** Within **30 bars**, a bar closes back through VWAP by at least
   **3 points**.
3. **Direction.** The reclaim is the trade. Break below then reclaim above is a long;
   break above then lose it is a short.
4. **Entry.** A limit 25% of the trigger bar's range back inside it, live for one bar.
5. **Bracket.** Stop = 1.5 × ATR(14), clamped to 15–40 points. Target = stop × 2.
6. **Clock.** No new entry from 15:30 ET. Anything open is flat at 15:45 ET.

The VWAP is anchored to the **first bar of the session inside your entry window**, not
to midnight and not to the 18:00 futures open. That is what produced the results below,
so it is reproduced exactly.

### Presets

| Preset | Window (ET) | ATR(14) filter | Break / reclaim |
|---|---|---|---|
| **Asian, no ATR filter** | 20:00–01:30 | none | 5 / 3 pts, 30 bars |
| **US, ATR band** | 09:30–15:30 | 15 ≤ ATR < 30 | 5 / 3 pts, 30 bars |
| Custom | yours | yours | yours |

The Asian preset runs **no ATR gate at all** — deliberately. Asian ATR runs low, and a
floor derived on US data rejected most Asian signals and was a net loser out of sample.
The US preset keeps the band: under 15 the move is too small to pay for the stop, at 30
and above is the instant-stop regime.

---

## The honest record

These strategies ran in a simulated evaluation arena — one NinjaTrader sim account per
strategy, each playing out a $50,000 / +$3,000 target / $2,000 trailing-drawdown
evaluation over and over.

**Asian preset, 23 July – 17 September 2026: 13 attempts, 6 passed, 7 failed. 46.2%.**

The US preset, over the same kind of run: **11 attempts, 5 passed, 45.5%.**

Read that properly:

- **More than half of the attempts failed.** Seven of thirteen ended at the drawdown
  limit. 46.2% was among the best numbers in a field of 32, which tells you more about
  how hard evaluations are than about how good this is.
- **A pass rate is not an edge.** What produces passes here is a modest geometric edge,
  hard discipline rules, and an account guard that stops trading the moment the target
  is banked. Take the discipline away and the number collapses.
- **Thirteen attempts is a small sample.** The gap between this and anything else in the
  roster is well inside the noise. Do not read the ordering as a ranking.
- **Simulated fills, one instrument, one nine-week window.** NQ, 1-minute bars, sim
  account fills, no slippage stress, no audit.
- **The manual indicator did not produce that record** — the automated strategy did.
  Your fills, your reaction time and your nerve are now part of the system.

Past results do not predict future results. This is a tool, not a promise.

---

## What you need

| | |
|---|---|
| Platform | NinjaTrader 8 (8.1.x) |
| Instrument | NQ or MNQ — the stop floor and cap are written in NQ points |
| Chart | **1-minute**, ETH (24-hour) session template |
| Time zone | **US Eastern.** Tools → Options → General → Time zone. |
| Warmup | The strategy trades from bar 1; give ATR(14) a few hundred bars to settle |

The ETH template matters more here than for most systems: the VWAP resets on the first
bar of the session, so a different session template moves the anchor and changes every
signal.

---

## Install

1. NinjaTrader → **Control Center → Tools → Import → NinjaScript Add-On…**
2. Pick `VwapReclaimAN.zip`.
3. Restart NinjaTrader, or **Tools → New NinjaScript → Compile**.
4. The indicator appears under **PhillyFranksTools** in the indicator picker.

If the importer objects to the markdown files in the archive, extract it by hand and
copy the two `.cs` files into:

```
Documents\NinjaTrader 8\bin\Custom\Indicators\VwapReclaimFollow.cs
Documents\NinjaTrader 8\bin\Custom\Strategies\VWAPReclaimAN.cs
```

then compile. **Both files must be present** — the strategy will not compile without
the indicator.

---

## Trading it by hand

Put `VwapReclaimFollow` on a 1-minute NQ chart and leave `Preset` on
`Asian_NoAtrFilter`.

The panel walks you through the state machine, so you are never guessing what it wants:

```
VWAP RECLAIM - MANUAL FOLLOW
Asian, no ATR filter (20:00-01:30 ET)
Clock 21:14   window 20:00-01:30
VWAP 24288.50   regime Quiet trend
------------------------------------------
BROKE BELOW VWAP
Reclaim above 24291.50 for a LONG
Bars left 21
------------------------------------------
Setups filled today 1 / 99    target 1  stop 0
No new entry 15:30 ET  -  flat 15:45 ET
YOU place the orders. Nothing here trades.
```

When the reclaim fires you get an arrow, a sound, and a dashed line at the limit price,
and the panel switches to the numbers you place:

```
WORKING LIMIT - LONG
Valid for THIS BAR ONLY
Limit  24294.25
Stop   24276.00   (18.25 pts)
Target 24330.75   (36.5 pts)
Risk   $365 per contract
```

**The limit is live for one bar only.** Place it with a one-minute life, or cancel it at
the close of the next bar. Roughly a third of setups never come back to the limit and
are simply skipped — that is the design, not a missed trade. The system refuses to chase
the end of the bar that triggered it.

### What the markers mean

| Marker | Meaning |
|---|---|
| Arrow up / down | Reclaim fired on this bar's close |
| Dashed line | The limit price, live for one bar |
| Grey dot | Limit expired unfilled — stand down |
| Solid red / green lines | Stop and target once filled |
| Diamond | Simulated bracket resolved (green target, red stop, gold session flat) |

### Sounds

Four moments can be given a sound, each chosen from the sounds NinjaTrader ships with
(or `Custom`, which plays the file you name in **Custom sound file**). `None` means no
alert is raised for that event at all.

| Event | Default | Why you might want it |
|---|---|---|
| VWAP broken | `None` | Heads-up: a reclaim is now possible, start watching |
| Setup armed | `Alert1` | The limit is live and you have one bar to place it |
| Limit filled | `None` | Price reached the limit — the strategy would now be in |
| Limit expired | `None` | It lapsed unfilled. Cancel the order and stand down |

**Enable alerts** is the master switch. The copy of this indicator that the strategy
runs internally never alerts, so you will not hear anything twice.

### Deliberately pessimistic

The simulated tracking is conservative on purpose:

- On the bar the limit fills, **only the stop is checked**. Crediting a target on the
  fill bar is the single most common way a backtest reports profit it never made.
- After that, a bar that touches both the stop and the target is recorded as a **stop**.
- A gap through your limit is filled at the open, in your favour — that part is real.

Your live result should be at least this good and often slightly better.

---

## Running the strategy

For simulation, Market Replay and accounts that are yours. Most funding companies do not
allow a fully automated strategy on an evaluation or funded account — check your own
contract, and when in doubt use the indicator.

### Account mode

Who enforces the account rules — the strategy, or your funding company. One setting with
three values, because Sim and Eval are mutually exclusive.

| Mode | Daily loss limit | Trailing drawdown | Profit target |
|---|---|---|---|
| **Sim** | strategy | strategy | strategy |
| **Eval** | *your provider* | strategy | strategy |
| **Off** | nobody | nobody | nobody |

**Sim** — nothing else is watching a simulation account, so the strategy enforces
everything: flat for the day at the daily loss limit, dead at the trailing drawdown,
stopped and banked at the profit target.

**Eval** — your provider already stops the account at its own daily loss number, so the
strategy does not duplicate that rule. Duplicating it would only ever stop you *earlier*
than the account requires, on a figure this strategy estimates rather than one your
provider publishes. It still stops at the profit target and still converts the bracket
into a resting limit to bank it.

**Off** — no account limits at all. It trades until you stop it.

### Account guard settings

| Setting | Default | Notes |
|---|---|---|
| Account mode | Sim | Sim / Eval / Off, as above |
| Starting balance ($) | 50000 | Your account's starting balance |
| Profit target ($) | 3000 | Trading stops, terminally, when this is banked |
| Trailing drawdown ($) | 2000 | Threshold = highest end-of-day balance − this |
| Trailing locks at start balance | true | The common "stops trailing once it reaches your start" rule |
| Daily loss limit ($) | 950 | Sim only. **Set it below your provider's hard number**, not equal to it |
| Use target limit exit | true | Resting limit at the exact profit-target price |

The **target limit exit** is worth understanding. A market flatten cannot reliably catch
a profit-target line: the trigger sees a spike tick and the order fills after the
retreat. A measured live attempt triggered at $53,060 and filled at $52,921 — failing by
$79. Once the target is in reach, the strategy converts the bracket target into a
resting limit at the exact price that banks it.

The guard can only act on trades **it** placed. It cannot see or stop anything you do by
hand on the same account, and it reads your account's own P&L — put anything else on
that account and the numbers it works from are not only its own. It is not a substitute
for reading your contract.

---

## Things you should know before relying on it

- **The VWAP accumulates only inside the entry window** and resets on the first bar of
  the session. It is not a 24-hour VWAP and it will not match a standard VWAP indicator.
  That is deliberate. Do not "fix" it.
- **Everything evaluates on bar close.** The indicator forces `Calculate` back to
  `OnBarClose` if you change it, because an intrabar version would show setups that
  vanish as the bar moves.
- **A break that never reclaims is a dead break.** After 30 bars it expires and the
  state machine goes back to watching. The panel counts the bars down for you.
- **The ATR filter suppresses the entry, not the break.** On the US preset, a reclaim
  that fires outside the ATR band consumes the break and no trade is taken. The panel
  says so.
- **The news blackout is empty and manual.** Event dates move every month, so nothing is
  guessed for you and nothing is downloaded.
- **Nothing in this package fails silently.** Anything that goes wrong prints to the
  NinjaScript Output window (Control Center → New → NinjaScript Output).

---

## Files

```
Indicators/VwapReclaimFollow.cs   the signal engine + manual display
Strategies/VWAPReclaimAN.cs       order handling, account guard, clock rules
CLAUDE.md                         working notes for Claude Code
AGENTS.md                         working notes for any coding agent
LICENSE                           MIT
Info.xml                          NinjaTrader import descriptor
```

`CLAUDE.md` and `AGENTS.md` are there for anyone who opens this package in an AI coding
tool. They record the invariants — above all, that the signal rules live in one file and
must never be duplicated into the other.

---

## License and disclaimer

MIT. See `LICENSE`. Use it, change it, ship it.

Futures trading involves substantial risk of loss and is not suitable for everyone. This
software is provided for education and research. It is not financial advice, it is not a
recommendation to trade anything, and its author is not a licensed advisor. Simulated
and past performance does not predict future results. You are responsible for every
order that reaches the market from your machine, and for knowing the rules of whatever
account you are trading.
