#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Text;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// VwapReclaimFollow -- the manual-execution half of the VWAP Reclaim family.
//
// WHY THIS EXISTS
//   Most funding companies let you use tools, but not let a robot trade the account
//   for you. This indicator is the signal engine of the VWAPReclaimAN strategy with
//   the order routing removed: it plots the session VWAP, tracks the break/reclaim
//   state machine, prices the entry, stop and target, and then stands aside. You
//   place the orders.
//
//   It is not a lookalike of the strategy -- it IS the strategy's signal code. The
//   VWAPReclaimAN strategy in this package calls this indicator for its signals
//   rather than keeping a second copy of the rules, so what you are shown and what an
//   automated run would have taken cannot drift apart.
//
// THE SETUP
//   Price closes clear of the session VWAP by MinBreakPoints, then closes back
//   through it by MinReclaimPoints within MaxTimeBars. The reclaim is the trade, in
//   the direction of the reclaim. Entry is a limit placed a quarter of the trigger
//   bar back inside it, live for one bar only.
//
// TIME ZONE
//   Every HHMM here is read from the chart's own clock. The published presets are
//   written in US Eastern, so set NinjaTrader to Eastern (Tools > Options > General >
//   Time zone) or translate the session hours yourself.
//
// MIT licensed. No warranty and no guarantee of profit. See LICENSE and README.md.

// Every global-scope type in a NinjaScript package has to be unique across the whole
// Custom folder -- NinjaTrader compiles every file into one assembly, so two downloads
// that both declared, say, "AccountMode" could not be installed together. Hence the
// VwapReclaim prefix on all four of these.
public enum VwapReclaimPreset
{
    Asian_NoAtrFilter,
    US_AtrBand,
    Custom
}

public enum VwapReclaimCorner
{
    TopLeft,
    TopRight,
    BottomLeft,
    BottomRight
}

// Sounds that ship with NinjaTrader 8, plus None (no alert for that event) and
// Custom (plays the file named in "Custom sound file").
public enum VwapReclaimSound
{
    None,
    Alert1,
    Alert2,
    Alert3,
    Alert4,
    Announcement,
    OrderFilled,
    TargetFilled,
    StopFilled,
    Reversing,
    Custom
}

namespace NinjaTrader.NinjaScript.Indicators.PhillyFranksTools
{
    public class VwapReclaimFollow : Indicator
    {
        // --- Bracket construction, shared with the strategy -----------------------
        //  Consts, not settings, for the same reason they are consts in the strategy:
        //  they are the tested shape of the trade. A saved instance keeps its own
        //  property values forever, so a risk rule written as a property is silently
        //  defeated on every instance that already exists.
        private const double EntryRetracePct  = 0.25;   // give-back into the trigger bar
        private const double AtrStopMult      = 1.5;    // 1.5 x ATR(14) at the signal bar
        private const double StopFloorPoints  = 15.0;   // never tighter than this
        private const double StopCapPoints    = 40.0;   // nor wider, unless configured wider
        private const double MaxRMultiple     = 3.0;    // ceiling on the scaled R:R

        // --- Clock rules ----------------------------------------------------------
        private const int HardNoEntryHHMM = 1530;   // no new setup is priced at/after this
        private const int HardFlatHHMM    = 1545;   // anything still open is out
        private const int HardFlatEndHHMM = 1900;   // sweep ends before the Asian window

        // The strategy runs with BarsRequiredToTrade = 1. Mirrored rather than raised:
        // ATR(14) is still settling that early, but the bracket guards against a
        // non-positive ATR and this is the behaviour that produced the record.
        private const int MinBarsRequired = 1;

        // Effective (preset-resolved) parameters. Everything downstream reads these and
        // never the public properties, so Custom and preset runs take one code path.
        private double effMinBreak;
        private double effMinReclaim;
        private int    effMaxTimeBars;
        private double effMinAtr;
        private double effMaxAtr;
        private double effStopPoints;
        private double effTargetPoints;
        private int    effSessionStart;
        private int    effSessionEnd;
        private string effPresetName = "";

        // Session VWAP. The strategy resets on the first bar of the SESSION (not the
        // calendar date) and accumulates only on bars inside the entry window, so this
        // is anchored to the first in-window bar of the session. Reproduced exactly;
        // changing the anchor changes every signal.
        private double cumPV, cumVol;

        // Break/reclaim state machine. 0 = watching, -1 = broke below (hunting a long
        // reclaim), 1 = broke above (hunting a short).
        private int    vstate;
        private int    breakBarCount;
        private int    lastSide;               // 1 above VWAP, -1 below, 0 unknown
        private double currentVwap;

        // Follow-along state machine. 0 = nothing, 1 = limit working (this bar only),
        // 2 = in the trade.
        private int    followState;
        private int    followDir;              // 1 long, -1 short
        private double limitPx, stopPx, targetPx, entryPx;
        private double stopPts, targetPts;
        private int    signalBar, entryBar;
        private int    tradesThisSession;
        private int    sessionWins, sessionLosses;
        private string lastOutcome = "";
        private int    currentRegime;          // 0 Unknown 1 Breakout 2 QuietTrend 3 Balance 4 Chop
        private int    drawSeq;                // unique tag suffix per setup
        private bool   forcedBarClose;

        [Browsable(false)] [XmlIgnore] public Series<double> Signal         { get; private set; }
        [Browsable(false)] [XmlIgnore] public Series<double> EntryLimit     { get; private set; }
        [Browsable(false)] [XmlIgnore] public Series<double> StopDistance   { get; private set; }
        [Browsable(false)] [XmlIgnore] public Series<double> TargetDistance { get; private set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name                     = "VwapReclaimFollow";
                Description              = "VWAP break-and-reclaim setups priced for manual execution. Plots the session VWAP, shows the break/reclaim state, and places no orders.";
                Calculate                = Calculate.OnBarClose;
                IsOverlay                = true;
                DrawOnPricePanel         = true;
                DisplayInDataBox         = false;
                PaintPriceMarkers        = false;
                IsSuspendedWhileInactive = false;

                Preset      = VwapReclaimPreset.Asian_NoAtrFilter;
                ShowVisuals = true;

                MinBreakPoints      = 5.0;
                MinReclaimPoints    = 3.0;
                MaxTimeBars         = 30;
                MinAtr              = 0;
                MaxAtr              = 0;
                StopPoints          = 15;
                TargetPoints        = 30;
                SessionStartHHMM    = 2000;
                SessionEndHHMM      = 130;
                MaxTradesPerSession = 99;
                AvoidLunchChop      = false;
                NewsBlackoutHHMM    = string.Empty;

                ShowPanel       = true;
                PanelCorner     = VwapReclaimCorner.TopRight;
                PanelFontSize   = 13;
                ShowVwapPlot    = true;
                EnableAlerts    = true;
                BreakSound      = VwapReclaimSound.None;
                SetupSound      = VwapReclaimSound.Alert1;
                FillSound       = VwapReclaimSound.None;
                ExpirySound     = VwapReclaimSound.None;
                CustomSoundFile = string.Empty;
                RiskPerTradeUsd = 0;

                LongBrush   = Brushes.LimeGreen;
                ShortBrush  = Brushes.OrangeRed;
                StopBrush   = Brushes.IndianRed;
                TargetBrush = Brushes.MediumSeaGreen;
                PanelText   = Brushes.Gainsboro;
                PanelArea   = Brushes.Black;

                // The VWAP is a plot, not a drawing object: a Draw call per bar would
                // leave one object per bar on the chart for the life of the session.
                // Bars outside the window go unassigned and the plot gaps, which is
                // honest -- there is no VWAP there, because the strategy is not
                // accumulating one.
                AddPlot(Brushes.DodgerBlue, "Session VWAP");
            }
            else if (State == State.Configure)
            {
                // Bar-close parity is not optional. The strategy evaluates on closed
                // bars; an intrabar evaluation would show setups the strategy never
                // took and retract them as the bar moved.
                if (Calculate != Calculate.OnBarClose)
                {
                    Calculate      = Calculate.OnBarClose;
                    forcedBarClose = true;
                }
                ResolvePreset();
            }
            else if (State == State.DataLoaded)
            {
                Signal         = new Series<double>(this);
                EntryLimit     = new Series<double>(this);
                StopDistance   = new Series<double>(this);
                TargetDistance = new Series<double>(this);

                if (forcedBarClose)
                    Log(Name + ": Calculate was forced back to OnBarClose so the display matches the strategy.", LogLevel.Information);
            }
        }

        // Preset values are lifted verbatim from the strategies that ran the arena.
        // Custom hands control to the properties below, for research -- a tuned Custom
        // run is your configuration, not a published one.
        private void ResolvePreset()
        {
            switch (Preset)
            {
                case VwapReclaimPreset.Asian_NoAtrFilter:
                    // VWAPReclaimAN. No ATR gate at all: Asian ATR runs low, and a
                    // floor derived on US data rejected most Asian signals and was a
                    // net loser out of sample.
                    effMinBreak = 5.0; effMinReclaim = 3.0; effMaxTimeBars = 30;
                    effMinAtr = 0; effMaxAtr = 0;
                    effStopPoints = 15; effTargetPoints = 30;
                    effSessionStart = 2000; effSessionEnd = 130;
                    effPresetName = "Asian, no ATR filter (20:00-01:30 ET)";
                    break;

                case VwapReclaimPreset.US_AtrBand:
                    // VwapReclaim variant C. Entry only while ATR(14) sits inside the
                    // band: below 15 the move is too small to pay for the stop, at or
                    // above 30 is the instant-stop regime.
                    effMinBreak = 5.0; effMinReclaim = 3.0; effMaxTimeBars = 30;
                    effMinAtr = 15.0; effMaxAtr = 30.0;
                    effStopPoints = 15; effTargetPoints = 30;
                    effSessionStart = 930; effSessionEnd = 1530;
                    effPresetName = "US, ATR band 15-30 (09:30-15:30 ET)";
                    break;

                default:
                    effMinBreak = MinBreakPoints; effMinReclaim = MinReclaimPoints;
                    effMaxTimeBars = MaxTimeBars;
                    effMinAtr = MinAtr; effMaxAtr = MaxAtr;
                    effStopPoints = StopPoints; effTargetPoints = TargetPoints;
                    effSessionStart = SessionStartHHMM; effSessionEnd = SessionEndHHMM;
                    effPresetName = "Custom";
                    break;
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < MinBarsRequired)
                return;

            Signal[0]         = 0;
            EntryLimit[0]     = 0;
            StopDistance[0]   = 0;
            TargetDistance[0] = 0;

            if (Bars.IsFirstBarOfSession)
            {
                vstate = 0; breakBarCount = 0; lastSide = 0;
                cumPV = 0; cumVol = 0; tradesThisSession = 0;
                sessionWins = 0; sessionLosses = 0;
            }

            int now = ToTime(Time[0]) / 100;

            // A trade that is already on is managed on every bar, in or out of the
            // entry window -- the strategy's bracket does not care what time it is.
            MaintainOpenTrade(now);

            if (!InEntryWindow(now))
            {
                DrawPanel(now, "OUT OF WINDOW");
                return;
            }

            cumPV  += (High[0] + Low[0] + Close[0]) / 3.0 * Volume[0];
            cumVol += Volume[0];
            if (cumVol <= 0)
            {
                DrawPanel(now, null);
                return;
            }

            currentVwap = cumPV / cumVol;
            if (ShowVwapPlot)
                Values[0][0] = currentVwap;

            ClassifyRegime();

            // The blackout suppresses the signal itself, exactly as it does in the
            // strategy -- and, as in the strategy, it stops the state machine from
            // advancing too, because the strategy returns before reaching it.
            if (InNewsBlackout(now))
            {
                DrawPanel(now, null);
                return;
            }

            double close = Close[0];
            int    side  = close > currentVwap ? 1 : -1;

            if (vstate == 0)
            {
                if (lastSide == 0) { lastSide = side; DrawPanel(now, null); return; }

                if (lastSide == 1 && close < currentVwap - effMinBreak)
                {
                    vstate = -1; breakBarCount = 0; lastSide = -1;
                    RaiseAlert("vrBreak", BreakSound, Priority.Low,
                        "VWAP broken BELOW at " + close.ToString("0.00", CultureInfo.InvariantCulture)
                        + " -- watching for a reclaim (long).", ShortBrush);
                    DrawPanel(now, null);
                    return;
                }
                if (lastSide == -1 && close > currentVwap + effMinBreak)
                {
                    vstate = 1; breakBarCount = 0; lastSide = 1;
                    RaiseAlert("vrBreak", BreakSound, Priority.Low,
                        "VWAP broken ABOVE at " + close.ToString("0.00", CultureInfo.InvariantCulture)
                        + " -- watching for a loss of it (short).", LongBrush);
                    DrawPanel(now, null);
                    return;
                }
                lastSide = side;
            }
            else if (vstate == -1)
            {
                breakBarCount++;
                if (breakBarCount > effMaxTimeBars)
                {
                    vstate = 0; lastSide = side;
                    lastOutcome = "BREAK EXPIRED - no reclaim in time";
                    DrawPanel(now, null);
                    return;
                }
                if (close > currentVwap + effMinReclaim)
                {
                    vstate = 0; lastSide = 1;
                    TryPublish(1);
                }
            }
            else if (vstate == 1)
            {
                breakBarCount++;
                if (breakBarCount > effMaxTimeBars)
                {
                    vstate = 0; lastSide = side;
                    lastOutcome = "BREAK EXPIRED - no reclaim in time";
                    DrawPanel(now, null);
                    return;
                }
                if (close < currentVwap - effMinReclaim)
                {
                    vstate = 0; lastSide = -1;
                    TryPublish(-1);
                }
            }

            DrawPanel(now, null);
        }

        // The reclaim has fired. The ATR band is the last signal-level gate -- in the
        // strategy it sits inside TryEnter, AFTER the state machine has already reset
        // to watching, so a rejected signal still consumes the break. Mirrored exactly.
        private void TryPublish(int dir)
        {
            double atr = 0;
            try { atr = ATR(14)[0]; } catch { }

            if (effMinAtr > 0 && atr < effMinAtr)
            {
                lastOutcome = "RECLAIM SKIPPED - ATR " + atr.ToString("0.0", CultureInfo.InvariantCulture)
                            + " under " + effMinAtr.ToString("0.#", CultureInfo.InvariantCulture);
                return;
            }
            if (effMaxAtr > 0 && atr >= effMaxAtr)
            {
                lastOutcome = "RECLAIM SKIPPED - ATR " + atr.ToString("0.0", CultureInfo.InvariantCulture)
                            + " at or over " + effMaxAtr.ToString("0.#", CultureInfo.InvariantCulture);
                return;
            }

            PublishSetup(dir, atr);
        }

        // Price the order exactly the way the strategy prices it: a limit set
        // EntryRetracePct back inside the trigger bar, with an ATR-scaled bracket whose
        // R multiple comes from the configured stop/target ratio. The numbers are
        // published on the series either way; the follow display only arms when the
        // strategy would actually have been able to take the trade.
        private void PublishSetup(int dir, double atr)
        {
            double rng = High[0] - Low[0];
            double px  = dir == 1 ? Close[0] - EntryRetracePct * rng
                                  : Close[0] + EntryRetracePct * rng;
            if (rng <= 0 || px <= 0) px = Close[0];
            try { px = Instrument.MasterInstrument.RoundToTickSize(px); } catch { }

            // The clamp may only ever WIDEN a configured stop, never tighten it.
            double lo = Math.Max(StopFloorPoints, effStopPoints);
            double hi = Math.Max(StopCapPoints, lo);
            double sp = atr > 0 ? Math.Max(lo, Math.Min(hi, AtrStopMult * atr)) : lo;
            double r  = Math.Min(MaxRMultiple, effStopPoints > 0 ? effTargetPoints / effStopPoints : 1.0);

            double stopDistance, targetDistance;
            if (TickSize > 0)
            {
                stopDistance   = Math.Round(sp / TickSize) * TickSize;
                targetDistance = Math.Round(sp * r / TickSize) * TickSize;
            }
            else
            {
                stopDistance   = sp;
                targetDistance = sp * r;
            }

            Signal[0]         = dir;
            EntryLimit[0]     = px;
            StopDistance[0]   = stopDistance;
            TargetDistance[0] = targetDistance;

            // Already following one, or out of setups for the session: the strategy
            // would decline this, so the chart declines it too and says why.
            if (followState != 0)
            {
                lastOutcome = "SETUP SKIPPED - already in a trade";
                return;
            }
            if (tradesThisSession >= MaxTradesPerSession)
            {
                lastOutcome = "SETUP SKIPPED - session limit reached";
                return;
            }

            stopPts     = stopDistance;
            targetPts   = targetDistance;
            followState = 1;
            followDir   = dir;
            limitPx     = px;
            signalBar   = CurrentBar;
            stopPx      = dir == 1 ? px - stopPts   : px + stopPts;
            targetPx    = dir == 1 ? px + targetPts : px - targetPts;
            drawSeq++;

            if (ShowVisuals && ChartControl != null)
            {
                Brush  b = dir == 1 ? LongBrush : ShortBrush;
                string t = "vr" + drawSeq;
                if (dir == 1) Draw.ArrowUp(this, t + "arw", false, 0, Low[0] - 2 * TickSize, b);
                else          Draw.ArrowDown(this, t + "arw", false, 0, High[0] + 2 * TickSize, b);
                Draw.Text(this, t + "txt", (dir == 1 ? "LONG limit " : "SHORT limit ")
                    + limitPx.ToString("0.00", CultureInfo.InvariantCulture),
                    0, dir == 1 ? Low[0] - 6 * TickSize : High[0] + 6 * TickSize, b);
                DrawFollowLines();
            }

            RaiseAlert("vrSetup", SetupSound, Priority.High,
                (dir == 1 ? "LONG" : "SHORT") + " VWAP reclaim -- limit "
                + limitPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ", stop " + stopPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ", target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ". Valid for one bar.",
                dir == 1 ? LongBrush : ShortBrush);
        }

        // One alert path for every event. A sound of None means no alert is raised for
        // that event at all, which is why everything but the setup ships silent: you
        // opt into them rather than having them appear in your Alerts window uninvited.
        //
        // ShowVisuals gates this as well as EnableAlerts. A strategy hosts this
        // indicator with ShowVisuals = false and inherits every other property from
        // SetDefaults -- including EnableAlerts = true -- so without this the invisible
        // compute-only copy would alert alongside the one on your chart.
        private void RaiseAlert(string id, VwapReclaimSound sound, Priority priority,
            string message, Brush foreground)
        {
            if (!EnableAlerts || !ShowVisuals || sound == VwapReclaimSound.None)
                return;
            try
            {
                Alert(id + drawSeq + "_" + CurrentBar, priority, message, SoundPath(sound),
                    10, Brushes.Black, foreground);
            }
            catch { }
        }

        // NinjaTrader wants a full path; a bare file name is resolved against the
        // install's own sounds folder, so the stock choices work on any machine.
        private string SoundPath(VwapReclaimSound sound)
        {
            string file = sound == VwapReclaimSound.Custom
                ? (CustomSoundFile ?? string.Empty).Trim()
                : sound.ToString() + ".wav";

            if (file.Length == 0)
                return string.Empty;
            if (file.IndexOf('\\') >= 0 || file.IndexOf('/') >= 0)
                return file;
            return NinjaTrader.Core.Globals.InstallDir + @"sounds\" + file;
        }

        // Resolve a working limit, then manage an open trade. Deliberately pessimistic
        // wherever one bar cannot tell you the order of events:
        //   * on the bar the limit fills, only the stop is checked. A backtest that
        //     credits a target on the fill bar reports profit factors it never earned.
        //   * from the next bar on, a bar that touches both is recorded as the stop.
        // Your real fill may be better than this. It should rarely be worse.
        private void MaintainOpenTrade(int now)
        {
            if (followState == 0)
                return;

            if (followState == 1)
            {
                if (CurrentBar <= signalBar)
                    return;

                bool filled = followDir == 1 ? Low[0] <= limitPx : High[0] >= limitPx;
                if (!filled)
                {
                    RaiseAlert("vrExpiry", ExpirySound, Priority.Medium,
                        "VWAP reclaim limit expired unfilled at "
                        + limitPx.ToString("0.00", CultureInfo.InvariantCulture)
                        + " -- cancel the order and stand down.",
                        Brushes.DimGray);
                    CloseFollow("EXPIRED - no fill, stand down", 0, limitPx);
                    return;
                }

                // A gap through the limit fills at the open, in your favour.
                entryPx  = followDir == 1 ? Math.Min(limitPx, Open[0]) : Math.Max(limitPx, Open[0]);
                stopPx   = followDir == 1 ? entryPx - stopPts   : entryPx + stopPts;
                targetPx = followDir == 1 ? entryPx + targetPts : entryPx - targetPts;
                entryBar    = CurrentBar;
                followState = 2;
                tradesThisSession++;
                DrawFollowLines();

                RaiseAlert("vrFill", FillSound, Priority.Medium,
                    (followDir == 1 ? "LONG" : "SHORT") + " VWAP reclaim limit filled at "
                    + entryPx.ToString("0.00", CultureInfo.InvariantCulture)
                    + " -- stop " + stopPx.ToString("0.00", CultureInfo.InvariantCulture)
                    + ", target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture) + ".",
                    followDir == 1 ? LongBrush : ShortBrush);

                // Fill bar: stop only.
                if (followDir == 1 ? Low[0] <= stopPx : High[0] >= stopPx)
                    CloseFollow("STOPPED", -1, stopPx);
                return;
            }

            if (now >= HardFlatHHMM && now < HardFlatEndHHMM)
            {
                double points = (Close[0] - entryPx) * followDir;
                CloseFollow("FLAT 15:45 ET - session rule", points < 0 ? -1 : 0, Close[0]);
                return;
            }

            bool hitStop   = followDir == 1 ? Low[0]  <= stopPx   : High[0] >= stopPx;
            bool hitTarget = followDir == 1 ? High[0] >= targetPx : Low[0]  <= targetPx;

            if (hitStop)        CloseFollow("STOPPED", -1, stopPx);
            else if (hitTarget) CloseFollow("TARGET", 1, targetPx);
            else                DrawFollowLines();
        }

        // result: 1 target, -1 stop, 0 neither (an expiry or a flat on the clock).
        private void CloseFollow(string outcome, int result, double markPx)
        {
            if (ShowVisuals && ChartControl != null)
            {
                DrawFollowLines();   // extend the lines to the bar that ended it
                string t = "vr" + drawSeq;
                if (followState == 1)
                    Draw.Dot(this, t + "exp", false, 0, markPx, Brushes.DimGray);
                else
                    Draw.Diamond(this, t + "exit", false, 0, markPx,
                        result > 0 ? TargetBrush : result < 0 ? StopBrush : Brushes.Goldenrod);
            }

            lastOutcome = outcome;
            if (result > 0) sessionWins++;
            if (result < 0) sessionLosses++;
            followState = 0;
            followDir   = 0;
        }

        // Lines run from the bar that created them to the CURRENT bar and are redrawn
        // each update, rather than being projected into the future: one object per
        // setup, and it tracks the trade instead of floating off the right edge.
        private void DrawFollowLines()
        {
            if (!ShowVisuals || ChartControl == null || followState == 0)
                return;

            string t = "vr" + drawSeq;
            Brush  b = followDir == 1 ? LongBrush : ShortBrush;
            int    signalBars = Math.Max(0, CurrentBar - signalBar);

            if (followState == 1)
            {
                Draw.Line(this, t + "lim", false, signalBars, limitPx, 0, limitPx, b, DashStyleHelper.Dash, 2);
                return;
            }

            int entryBars = Math.Max(0, CurrentBar - entryBar);
            Draw.Line(this, t + "lim", false, signalBars, limitPx,  0, limitPx,  b,           DashStyleHelper.Dash,  1);
            Draw.Line(this, t + "stp", false, entryBars,  stopPx,   0, stopPx,   StopBrush,   DashStyleHelper.Solid, 2);
            Draw.Line(this, t + "tgt", false, entryBars,  targetPx, 0, targetPx, TargetBrush, DashStyleHelper.Solid, 2);
        }

        private bool InEntryWindow(int now)
        {
            if (now >= HardNoEntryHHMM && now < HardFlatEndHHMM) return false;
            // Wrap-aware: the Asian window (20:00-01:30) crosses midnight.
            if (effSessionStart <= effSessionEnd) return now >= effSessionStart && now < effSessionEnd;
            return now >= effSessionStart || now < effSessionEnd;
        }

        private bool InNewsBlackout(int now)
        {
            if (AvoidLunchChop && now >= 1200 && now < 1300) return true;
            if (string.IsNullOrEmpty(NewsBlackoutHHMM)) return false;
            foreach (var range in NewsBlackoutHHMM.Split(';'))
            {
                var parts = range.Split('-');
                if (parts.Length != 2) continue;
                int s, e;
                if (!int.TryParse(parts[0].Trim(), out s)) continue;
                if (!int.TryParse(parts[1].Trim(), out e)) continue;
                if (now >= s && now < e) return true;
            }
            return false;
        }

        // Context only -- the regime never arms or blocks a setup. It is here because
        // "chop with an expanding range" is the state that takes accounts apart, and
        // you are the discretion the strategy does not have.
        private int ClassifyRegime()
        {
            if (CurrentBar < 100) return 0;
            double volRatio = ATR(14)[0] / SMA(ATR(14), 100)[0];
            double adx      = ADX(14)[0];

            bool expanding = (currentRegime == 1 || currentRegime == 4) ? volRatio > 1.00 : volRatio >= 1.20;
            bool trending  = (currentRegime == 1 || currentRegime == 2) ? adx > 18.0      : adx >= 22.0;

            if      ( trending &&  expanding) currentRegime = 1;
            else if ( trending && !expanding) currentRegime = 2;
            else if (!trending && !expanding) currentRegime = 3;
            else                              currentRegime = 4;
            return currentRegime;
        }

        private static string RegimeName(int r)
        {
            switch (r)
            {
                case 1:  return "Breakout (trend + expansion)";
                case 2:  return "Quiet trend";
                case 3:  return "Balance";
                case 4:  return "Chop + expansion";
                default: return "Unknown";
            }
        }

        private void DrawPanel(int now, string windowNote)
        {
            if (!ShowVisuals || !ShowPanel || ChartControl == null)
                return;

            double pointValue = 0;
            try { pointValue = Instrument.MasterInstrument.PointValue; } catch { }

            var sb = new StringBuilder(640);
            sb.Append("VWAP RECLAIM - MANUAL FOLLOW").Append('\n');
            sb.Append(effPresetName).Append('\n');
            sb.Append("Clock ").Append(FormatHHMM(now));
            sb.Append("   window ").Append(FormatHHMM(effSessionStart)).Append('-').Append(FormatHHMM(effSessionEnd));
            if (windowNote != null) sb.Append("  [").Append(windowNote).Append(']');
            sb.Append('\n');
            sb.Append("VWAP ").Append(cumVol > 0 ? currentVwap.ToString("0.00", CultureInfo.InvariantCulture) : "--");
            sb.Append("   regime ").Append(RegimeName(currentRegime)).Append('\n');
            sb.Append("------------------------------------------\n");

            if (followState == 1)
            {
                sb.Append(followDir == 1 ? "WORKING LIMIT - LONG" : "WORKING LIMIT - SHORT").Append('\n');
                sb.Append("Valid for THIS BAR ONLY\n");
                sb.Append("Limit  ").Append(limitPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Stop   ").Append(stopPx.ToString("0.00", CultureInfo.InvariantCulture))
                  .Append("   (").Append(stopPts.ToString("0.##", CultureInfo.InvariantCulture)).Append(" pts)").Append('\n');
                sb.Append("Target ").Append(targetPx.ToString("0.00", CultureInfo.InvariantCulture))
                  .Append("   (").Append(targetPts.ToString("0.##", CultureInfo.InvariantCulture)).Append(" pts)").Append('\n');
            }
            else if (followState == 2)
            {
                sb.Append(followDir == 1 ? "IN TRADE - LONG" : "IN TRADE - SHORT").Append('\n');
                sb.Append("Entry  ").Append(entryPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Stop   ").Append(stopPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Target ").Append(targetPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                double open = (Close[0] - entryPx) * followDir;
                sb.Append("Open   ").Append(open.ToString("+0.00;-0.00;0.00", CultureInfo.InvariantCulture)).Append(" pts")
                  .Append("   bars held ").Append(CurrentBar - entryBar).Append('\n');
            }
            else if (vstate == -1)
            {
                sb.Append("BROKE BELOW VWAP\n");
                sb.Append("Reclaim above ")
                  .Append((currentVwap + effMinReclaim).ToString("0.00", CultureInfo.InvariantCulture))
                  .Append(" for a LONG\n");
                sb.Append("Bars left ").Append(Math.Max(0, effMaxTimeBars - breakBarCount)).Append('\n');
            }
            else if (vstate == 1)
            {
                sb.Append("BROKE ABOVE VWAP\n");
                sb.Append("Lose it below ")
                  .Append((currentVwap - effMinReclaim).ToString("0.00", CultureInfo.InvariantCulture))
                  .Append(" for a SHORT\n");
                sb.Append("Bars left ").Append(Math.Max(0, effMaxTimeBars - breakBarCount)).Append('\n');
            }
            else
            {
                sb.Append("WATCHING - needs a ")
                  .Append(effMinBreak.ToString("0.#", CultureInfo.InvariantCulture))
                  .Append(" pt break of VWAP\n");
                if (!string.IsNullOrEmpty(lastOutcome))
                    sb.Append("Last: ").Append(lastOutcome).Append('\n');
            }

            if (followState != 0 && pointValue > 0)
            {
                double riskPerContract = stopPts * pointValue;
                sb.Append("Risk   $").Append(riskPerContract.ToString("0", CultureInfo.InvariantCulture)).Append(" per contract");
                if (RiskPerTradeUsd > 0 && riskPerContract > 0)
                {
                    int size = (int)Math.Floor(RiskPerTradeUsd / riskPerContract);
                    sb.Append("   -> ").Append(size).Append(size == 1 ? " contract" : " contracts")
                      .Append(" at $").Append(RiskPerTradeUsd.ToString("0", CultureInfo.InvariantCulture));
                }
                sb.Append('\n');
            }

            sb.Append("------------------------------------------\n");
            sb.Append("Setups filled today ").Append(tradesThisSession).Append(" / ").Append(MaxTradesPerSession);
            sb.Append("    target ").Append(sessionWins).Append("  stop ").Append(sessionLosses).Append('\n');
            sb.Append("No new entry 15:30 ET  -  flat 15:45 ET\n");
            sb.Append("YOU place the orders. Nothing here trades.");

            Draw.TextFixed(this, "vrPanel", sb.ToString(), CornerToPosition(PanelCorner),
                PanelText, new SimpleFont("Consolas", PanelFontSize), Brushes.Transparent, PanelArea, 60);
        }

        private static string FormatHHMM(int hhmm)
        {
            int h = hhmm / 100, m = hhmm % 100;
            return h.ToString("00", CultureInfo.InvariantCulture) + ":" + m.ToString("00", CultureInfo.InvariantCulture);
        }

        private static TextPosition CornerToPosition(VwapReclaimCorner corner)
        {
            switch (corner)
            {
                case VwapReclaimCorner.TopLeft:     return TextPosition.TopLeft;
                case VwapReclaimCorner.BottomLeft:  return TextPosition.BottomLeft;
                case VwapReclaimCorner.BottomRight: return TextPosition.BottomRight;
                default:                            return TextPosition.TopRight;
            }
        }

        #region Properties
        // Only Preset and ShowVisuals carry [NinjaScriptProperty]: those two are the
        // generated constructor arguments a strategy passes. Holding the signature at
        // two arguments means adding a display option here never breaks the strategy.
        [NinjaScriptProperty]
        [Display(Name = "Preset", Order = 1, GroupName = "1. Setup", Description = "Published configuration to follow. Custom hands control to the parameters below.")]
        public VwapReclaimPreset Preset { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show visuals", Order = 2, GroupName = "1. Setup", Description = "Off when a strategy hosts this indicator for its signals.")]
        public bool ShowVisuals { get; set; }

        [Range(0.25, 100)]
        [Display(Name = "Min break (points)", Order = 1, GroupName = "2. Custom rules", Description = "How far past VWAP a close must be to count as a break.")]
        public double MinBreakPoints { get; set; }

        [Range(0.25, 100)]
        [Display(Name = "Min reclaim (points)", Order = 2, GroupName = "2. Custom rules", Description = "How far back through VWAP a close must be to count as the reclaim.")]
        public double MinReclaimPoints { get; set; }

        [Range(1, 200)]
        [Display(Name = "Max bars to reclaim", Order = 3, GroupName = "2. Custom rules")]
        public int MaxTimeBars { get; set; }

        [Range(0, 200)]
        [Display(Name = "Min ATR(14) (0 = off)", Order = 4, GroupName = "2. Custom rules")]
        public double MinAtr { get; set; }

        [Range(0, 500)]
        [Display(Name = "Max ATR(14), exclusive (0 = off)", Order = 5, GroupName = "2. Custom rules")]
        public double MaxAtr { get; set; }

        [Range(0.25, 200)]
        [Display(Name = "Stop (points)", Order = 6, GroupName = "2. Custom rules", Description = "Floor for the ATR stop and, with the target, the R multiple.")]
        public double StopPoints { get; set; }

        [Range(0.25, 200)]
        [Display(Name = "Target (points)", Order = 7, GroupName = "2. Custom rules")]
        public double TargetPoints { get; set; }

        [Range(0, 2400)]
        [Display(Name = "Session start (HHMM)", Order = 8, GroupName = "2. Custom rules")]
        public int SessionStartHHMM { get; set; }

        [Range(0, 2400)]
        [Display(Name = "Session end (HHMM)", Order = 9, GroupName = "2. Custom rules")]
        public int SessionEndHHMM { get; set; }

        [Range(1, 999)]
        [Display(Name = "Max setups / session", Order = 1, GroupName = "3. Filters")]
        public int MaxTradesPerSession { get; set; }

        [Display(Name = "Avoid lunch chop (12:00-13:00)", Order = 2, GroupName = "3. Filters")]
        public bool AvoidLunchChop { get; set; }

        [Display(Name = "News blackout (HHMM-HHMM;...)", Order = 3, GroupName = "3. Filters", Description = "Your own event windows, entered by hand. Nothing is downloaded.")]
        public string NewsBlackoutHHMM { get; set; }

        [Display(Name = "Show panel", Order = 1, GroupName = "4. Display")]
        public bool ShowPanel { get; set; }

        [Display(Name = "Panel corner", Order = 2, GroupName = "4. Display")]
        public VwapReclaimCorner PanelCorner { get; set; }

        [Range(8, 30)]
        [Display(Name = "Panel font size", Order = 3, GroupName = "4. Display")]
        public int PanelFontSize { get; set; }

        [Display(Name = "Plot session VWAP", Order = 4, GroupName = "4. Display", Description = "Plots the VWAP the setup is measured against. Style it under Plots.")]
        public bool ShowVwapPlot { get; set; }

        [Range(0, 100000)]
        [Display(Name = "Risk per trade ($, 0 = off)", Order = 5, GroupName = "4. Display", Description = "Shows how many contracts that budget buys at this stop distance. Sizing stays your decision.")]
        public double RiskPerTradeUsd { get; set; }

        [Display(Name = "Enable alerts", Order = 1, GroupName = "5. Alerts", Description = "Master switch. Off means no alert of any kind.")]
        public bool EnableAlerts { get; set; }

        [Display(Name = "VWAP broken sound", Order = 2, GroupName = "5. Alerts", Description = "Plays on the break, the heads-up that a reclaim is now possible. Silent by default.")]
        public VwapReclaimSound BreakSound { get; set; }

        [Display(Name = "Setup armed sound", Order = 3, GroupName = "5. Alerts", Description = "Plays when the reclaim fires and the limit goes live. None raises no alert for this event.")]
        public VwapReclaimSound SetupSound { get; set; }

        [Display(Name = "Limit filled sound", Order = 4, GroupName = "5. Alerts", Description = "Plays when price reaches the limit. Silent by default.")]
        public VwapReclaimSound FillSound { get; set; }

        [Display(Name = "Limit expired sound", Order = 5, GroupName = "5. Alerts", Description = "Plays when the limit lapses unfilled and you should cancel. Silent by default.")]
        public VwapReclaimSound ExpirySound { get; set; }

        [Display(Name = "Custom sound file", Order = 6, GroupName = "5. Alerts", Description = "Used by any event set to Custom. A .wav name resolves against NinjaTrader 8/sounds; a full path is taken as given.")]
        public string CustomSoundFile { get; set; }

        [XmlIgnore] [Display(Name = "Long", Order = 1, GroupName = "6. Colors")]
        public Brush LongBrush { get; set; }
        [Browsable(false)]
        public string LongBrushSerialize { get { return Serialize.BrushToString(LongBrush); } set { LongBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Short", Order = 2, GroupName = "6. Colors")]
        public Brush ShortBrush { get; set; }
        [Browsable(false)]
        public string ShortBrushSerialize { get { return Serialize.BrushToString(ShortBrush); } set { ShortBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Stop", Order = 3, GroupName = "6. Colors")]
        public Brush StopBrush { get; set; }
        [Browsable(false)]
        public string StopBrushSerialize { get { return Serialize.BrushToString(StopBrush); } set { StopBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Target", Order = 4, GroupName = "6. Colors")]
        public Brush TargetBrush { get; set; }
        [Browsable(false)]
        public string TargetBrushSerialize { get { return Serialize.BrushToString(TargetBrush); } set { TargetBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Panel text", Order = 5, GroupName = "6. Colors")]
        public Brush PanelText { get; set; }
        [Browsable(false)]
        public string PanelTextSerialize { get { return Serialize.BrushToString(PanelText); } set { PanelText = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Panel background", Order = 6, GroupName = "6. Colors")]
        public Brush PanelArea { get; set; }
        [Browsable(false)]
        public string PanelAreaSerialize { get { return Serialize.BrushToString(PanelArea); } set { PanelArea = Serialize.StringToBrush(value); } }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PhillyFranksTools.VwapReclaimFollow[] cacheVwapReclaimFollow;
		public PhillyFranksTools.VwapReclaimFollow VwapReclaimFollow(VwapReclaimPreset preset, bool showVisuals)
		{
			return VwapReclaimFollow(Input, preset, showVisuals);
		}

		public PhillyFranksTools.VwapReclaimFollow VwapReclaimFollow(ISeries<double> input, VwapReclaimPreset preset, bool showVisuals)
		{
			if (cacheVwapReclaimFollow != null)
				for (int idx = 0; idx < cacheVwapReclaimFollow.Length; idx++)
					if (cacheVwapReclaimFollow[idx] != null && cacheVwapReclaimFollow[idx].Preset == preset && cacheVwapReclaimFollow[idx].ShowVisuals == showVisuals && cacheVwapReclaimFollow[idx].EqualsInput(input))
						return cacheVwapReclaimFollow[idx];
			return CacheIndicator<PhillyFranksTools.VwapReclaimFollow>(new PhillyFranksTools.VwapReclaimFollow(){ Preset = preset, ShowVisuals = showVisuals }, input, ref cacheVwapReclaimFollow);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PhillyFranksTools.VwapReclaimFollow VwapReclaimFollow(VwapReclaimPreset preset, bool showVisuals)
		{
			return indicator.VwapReclaimFollow(Input, preset, showVisuals);
		}

		public Indicators.PhillyFranksTools.VwapReclaimFollow VwapReclaimFollow(ISeries<double> input , VwapReclaimPreset preset, bool showVisuals)
		{
			return indicator.VwapReclaimFollow(input, preset, showVisuals);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PhillyFranksTools.VwapReclaimFollow VwapReclaimFollow(VwapReclaimPreset preset, bool showVisuals)
		{
			return indicator.VwapReclaimFollow(Input, preset, showVisuals);
		}

		public Indicators.PhillyFranksTools.VwapReclaimFollow VwapReclaimFollow(ISeries<double> input , VwapReclaimPreset preset, bool showVisuals)
		{
			return indicator.VwapReclaimFollow(input, preset, showVisuals);
		}
	}
}

#endregion
