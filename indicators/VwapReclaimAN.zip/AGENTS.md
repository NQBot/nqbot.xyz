# AGENTS.md — VWAP Reclaim

Working notes for a coding agent asked to change anything in this package. Read this
before editing either `.cs` file. `CLAUDE.md` carries the same rules in shorter form.

## What this package is

A NinjaTrader 8 trading system shipped in two halves:

| File | Owns |
|---|---|
| `Indicators/VwapReclaimFollow.cs` | **All** signal logic, the bracket sizing, the display, the alerts |
| `Strategies/VWAPReclaimAN.cs` | Order submission, account guard, clock enforcement, target limit exit |

The strategy hosts the indicator (`signals = VwapReclaimFollow(Preset, false);` in
`State.DataLoaded`) and reads four series from it: `Signal`, `EntryLimit`,
`StopDistance`, `TargetDistance`.

## The one rule that matters

**There is exactly one copy of the signal logic, and it lives in the indicator.**

The package is sold on the claim that what a trader sees on the chart is what the
strategy does. A second copy of any entry condition — even "just for clarity", even
"just so the strategy is standalone" — breaks that claim silently, because the two
copies will be edited at different times by different people.

Corollaries:

- Add a condition? It goes in `VwapReclaimFollow.OnBarUpdate`, never in the strategy.
- Change the bracket maths? `PublishSetup` in the indicator, never `SubmitEntry`.
- The strategy may only ever **decline** a signal (flat check, trade count, account
  guard, news blackout). It must never construct one.

## Parity invariants — do not "fix" these

Each of these looks like a bug and is not. They reproduce the code that produced the
published results; changing one changes the signals and invalidates `README.md`.

1. **The VWAP is window-anchored and session-reset.** `cumPV` / `cumVol` reset on
   `Bars.IsFirstBarOfSession` and accumulate **only** on bars inside the entry window.
   It is not a 24-hour VWAP and will not match a standard VWAP indicator. The trade
   counter resets on the same event — *not* on the calendar date, because the Asian
   window crosses midnight and a date reset would split one session in two.
2. **The ATR band gates the ENTRY, not the break.** In the strategy the check sits
   inside `TryEnter`, after the state machine has already reset to watching, so a
   reclaim rejected on ATR still consumes the break. `TryPublish` mirrors that exactly.
   Moving the check earlier would create trades the strategy never took.
3. **Bar close only.** The indicator forces `Calculate` back to `OnBarClose` in
   `State.Configure`. Intrabar evaluation would surface setups that retract.
4. **Pessimistic simulated fills.** On the fill bar only the stop is checked; after that
   a bar touching both stop and target is recorded as a stop. A fill-bar target credit
   was measured to inflate a profit factor from 1.00 to 1.52 on a related strategy.
5. **One-bar limit life.** `EnterLongLimit(0, false, ...)` with
   `isLiveUntilCancelled = false`. A setup that does not retrace is declined, not chased.
6. **`BarsRequiredToTrade = 1`.** Low on purpose — it is what the original ran. ATR(14)
   is still settling that early; the bracket guards against a non-positive ATR.
7. **Risk constants are `const`, not properties.** `EntryRetracePct`, `AtrStopMult`,
   `StopFloorPoints`, `StopCapPoints`, `MaxRMultiple`, `HardNoEntryHHMM`,
   `HardFlatHHMM`, `HardFlatEndHHMM`. A NinjaTrader strategy instance already configured
   on the Strategies tab keeps its own saved property values, so a risk rule written as
   a property is silently defeated on every instance that already exists. This was
   learned the expensive way. Do not promote any of them to a property.
8. **The stop clamp may only widen a configured stop, never tighten it.**
9. **15:30 / 15:45 ET.** No new entry from 15:30, flat from 15:45, re-checked every bar
   and every tick until 19:00. Never make these conditional on anything.

## NinjaScript constraints

- **Every global-scope type must be unique across the whole Custom folder.** NinjaTrader
  compiles every file in `bin/Custom` into one assembly, so two downloads that both
  declared `AccountMode` or `Sound` could not be installed side by side. That is why
  everything here is prefixed: `VwapReclaimPreset`, `VwapReclaimAccountMode`,
  `VwapReclaimSound`, `VwapReclaimCorner`. Keep the prefix on anything you add.
- The class names are taken too. `VwapReclaimSignal` and `VwapReclaimSignalLab` already
  exist in the author's own install, which is why this indicator is `VwapReclaimFollow`.
- Enums used as `[NinjaScriptProperty]` parameter types sit at **global scope**, outside
  the namespace: the generated wrapper resolves enum parameter types by bare name.
- Only two properties on the indicator carry `[NinjaScriptProperty]`: `Preset` and
  `ShowVisuals`, in that order. NinjaTrader builds the strategy-facing wrapper from
  those in declaration order, so **adding a third breaks the strategy's call**.
- **The `#region NinjaScript generated code` block belongs to NinjaTrader.** It is what
  makes `VwapReclaimFollow(Preset, false)` resolve inside the strategy; with no region
  the compile fails `CS0103`. Never write one by hand — NinjaTrader *appends* its own on
  compile rather than replacing what it finds, so a hand-written copy yields two and
  fails with `CS0111` / `CS0121` / `CS0102`. To change it, delete the whole region and
  let the next compile regenerate it.
- **Line endings decide whether that happens to you.** NinjaTrader writes the region
  with CRLF and finds it again by matching that text. An editor that normalises the file
  to LF leaves the region readable to you and invisible to NinjaTrader, which appends a
  second copy on the next compile. So: the copy in this repo carries **no region at
  all**; install it, let NinjaTrader generate one, and copy the result back **byte for
  byte** as the artifact to ship. Never edit a file that already has a region without
  stripping it first.
- Targets C# 5 / .NET 4.8 as NinjaTrader compiles it. No `$` string interpolation, no
  tuples, no pattern matching.
- Files must stay **pure ASCII**.
- No blocking work, no network calls, no unbounded file IO on the update path. The only
  file the strategy writes is a single four-field line under
  `NinjaTrader.Core.Globals.UserDataDir\VwapReclaim\`.
- **No hardcoded machine-specific paths.**
- Catch blocks either log to `NinjaTrader.Code.Output.Process` / `Log()` or are a
  documented no-op on a cosmetic call. Nothing fails silently.
- Draw objects: one per setup, tagged `vr<seq>...`, redrawn from their origin bar to bar
  0. Never draw one object per bar — that leaks objects for the life of the session.

## Verifying a change

NinjaTrader is the compiler and Market Replay is the test bed.

1. Compile from the NinjaScript editor (F5). Warnings matter — an unused field usually
   means a code path was half-removed.
2. Put `VwapReclaimFollow` on a 1-minute NQ chart, ETH template, NinjaTrader set to US
   Eastern. Check the plotted VWAP only exists inside the entry window, and that the
   panel counts down the bars-to-reclaim.
3. Run `VWAPReclaimAN` on the same chart in Market Replay on a sim account. **Every
   entry the strategy takes must sit on a bar the indicator marked**, at the same limit
   price. If they disagree, the parity claim is broken — fix that first.
4. Watch the NinjaScript Output window for guard lines and failure messages.
5. If you changed a signal rule, the numbers in `README.md` no longer describe this
   code. Re-test over the same window or delete the claim.

## Out of bounds

Do not, without the owner explicitly asking:

- remove or weaken the clock rules or the account guard
- turn the indicator into an order-placing tool — its whole purpose is that it does not
  trade, so that it can be used where automation is not allowed
- add a network call, a licence check, telemetry, or anything that phones home
- reintroduce the per-trade JSONL research logger that was stripped from the strategy
- change `README.md`'s performance numbers to anything other than what the record says
