// ============================================================================
// StrategyManagerAddOn - One-Click Enable/Disable All Strategies
// ============================================================================
// Adds "Enable All Strategies" and "Disable All Strategies" to the NinjaTrader
// 8 Control Center Tools menu. Drives NT8's own internal enable/disable
// pipeline, so strategies genuinely start and stop - not just checkbox
// visuals. Built and tested against NinjaTrader 8.1.5.2.
//
// MIT License - Copyright (c) 2026 PhillyFrank (nqbotlive.com)
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions: The above copyright
// notice and this permission notice shall be included in all copies or
// substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS",
// WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
// TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
// CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
// ============================================================================

#region Using declarations
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Adds "Enable All Strategies" and "Disable All Strategies" to the Tools menu.
    ///
    /// HOW THIS ACTUALLY WORKS (v3 -- the first two approaches failed):
    ///   v1 set StrategiesGridEntry.IsEnabled via reflection. That only updates the
    ///      row view-model, so the checkbox VISUAL toggles but NT8 never starts the
    ///      strategy (the checkmark-but-dead-strategy symptom).
    ///   v2 raised ButtonBase.ClickEvent on the checkboxes. A checkbox executes its
    ///      bound command inside ButtonBase.OnClick(); raising the routed event from
    ///      outside skips OnClick entirely, so the command never fired. No-op.
    ///   v3 (this) calls the SAME internal pipeline the grid's own checkbox command
    ///      handler (OnEnableDisableSingleStrategy) calls:
    ///        StrategiesGrid.StrategyEnable(StrategyBase, Window, StrategiesGridEntry)
    ///        StrategiesGrid.StrategyDisable(StrategyBase)
    ///      Both are private -> invoked via reflection on the live StrategiesGrid
    ///      control. Row objects (StrategiesGridEntry) and their Strategy /
    ///      IsEnabled / IsEnabledForEnabling properties are public, so discovery is
    ///      compile-safe. Verified against NinjaTrader.Gui 8.1.5.2.
    ///   Fallback: if the private methods are missing (future NT8 update), select
    ///      all rows and execute the public routed commands
    ///      StrategyCommands.SelectAllCommand + EnableStrategyCommand /
    ///      DisableStrategyCommand on the grid -- the same code path as the grid's
    ///      right-click menu.
    /// </summary>
    public class StrategyManagerAddOn : AddOnBase
    {
        private Window     _controlCenter;
        private NTMenuItem _enableAllItem;
        private NTMenuItem _disableAllItem;

        private static MethodInfo _miStrategyEnable;
        private static MethodInfo _miStrategyDisable;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "One-click enable/disable all strategies";
                Name        = "StrategyManager";
            }
        }

        // ------------------------- Window lifecycle -------------------------

        protected override void OnWindowCreated(Window window)
        {
            if (window.GetType().FullName?.Contains("ControlCenter") == true)
            {
                _controlCenter = window;
                window.Dispatcher.BeginInvoke(DispatcherPriority.Loaded,
                    new Action(() => InstallMenu(window)));
            }
        }

        protected override void OnWindowDestroyed(Window window)
        {
            if (window == _controlCenter)
            {
                _controlCenter  = null;
                _enableAllItem  = null;
                _disableAllItem = null;
            }
        }

        // ------------------------- Menu setup -------------------------

        private void InstallMenu(Window window)
        {
            try
            {
                MenuItem tools = FindToolsMenu(window, 0);
                if (tools == null)
                {
                    // Retry up to 5 times -- Tools menu loads asynchronously
                    var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
                    int retries = 0;
                    timer.Tick += (s, e) =>
                    {
                        if (++retries > 5) { timer.Stop(); return; }
                        var found = FindToolsMenu(window, 0);
                        if (found != null) { timer.Stop(); AddMenuItems(found); }
                    };
                    timer.Start();
                    return;
                }
                AddMenuItems(tools);
            }
            catch (Exception ex)
            {
                Log("InstallMenu error: " + ex.Message);
            }
        }

        private void AddMenuItems(MenuItem tools)
        {
            // De-dup: remove items left by a prior compile/instance (NT8 re-fires
            // OnWindowCreated for the still-open Control Center on each recompile).
            for (int i = tools.Items.Count - 1; i >= 0; i--)
            {
                var h = (tools.Items[i] as MenuItem)?.Header as string;
                if (h == "Enable All Strategies" || h == "Disable All Strategies")
                    tools.Items.RemoveAt(i);
            }

            // Copy style from existing NTMenuItems for consistent look
            Style existingStyle = null;
            Brush existingFg    = null;
            FontFamily existingFf = null;
            double existingFs   = 12;
            foreach (var item in tools.Items)
            {
                if (item is NTMenuItem existing)
                {
                    existingStyle = existing.Style;
                    existingFg    = existing.Foreground;
                    existingFf    = existing.FontFamily;
                    existingFs    = existing.FontSize;
                    break;
                }
            }
            Action<NTMenuItem> applyStyle = m =>
            {
                if (existingStyle != null) m.Style      = existingStyle;
                if (existingFg    != null) m.Foreground  = existingFg;
                if (existingFf    != null) m.FontFamily  = existingFf;
                m.FontSize  = existingFs;
                m.IsEnabled = true;
            };

            tools.Items.Add(new Separator());

            _enableAllItem = new NTMenuItem { Header = "Enable All Strategies" };
            applyStyle(_enableAllItem);
            _enableAllItem.Click += (s, e) =>
                _controlCenter?.Dispatcher.BeginInvoke(DispatcherPriority.Background,
                    new Action(() => DoToggleAll(true)));
            tools.Items.Add(_enableAllItem);

            _disableAllItem = new NTMenuItem { Header = "Disable All Strategies" };
            applyStyle(_disableAllItem);
            _disableAllItem.Click += (s, e) =>
                _controlCenter?.Dispatcher.BeginInvoke(DispatcherPriority.Background,
                    new Action(() => DoToggleAll(false)));
            tools.Items.Add(_disableAllItem);

            Log("Menu items added to Tools");
        }

        // ------------------------- Core: toggle all strategies -------------------------

        private void DoToggleAll(bool enable)
        {
            try
            {
                if (_controlCenter == null)
                {
                    MessageBox.Show("Control Center not found.", "Strategy Manager");
                    return;
                }

                // 1. Select the Strategies tab so its content is materialized
                TabItem strategiesTab = FindStrategiesTab(_controlCenter);
                if (strategiesTab != null)
                {
                    var tabCtrl = strategiesTab.Parent as TabControl;
                    if (tabCtrl != null && tabCtrl.SelectedItem != strategiesTab)
                    {
                        tabCtrl.SelectedItem = strategiesTab;
                        tabCtrl.UpdateLayout();
                        _controlCenter.Dispatcher.Invoke(DispatcherPriority.Render, new Action(() => { }));
                        _controlCenter.Dispatcher.Invoke(DispatcherPriority.Background, new Action(() => { }));
                    }
                }

                // 2. Find the live StrategiesGrid control (the tab's content)
                var grid = FindFirstDescendant<NinjaTrader.Gui.NinjaScript.StrategiesGrid>(_controlCenter);
                if (grid == null)
                {
                    MessageBox.Show("Could not find the StrategiesGrid control.\nMake sure the Strategies tab is visible.",
                        "Strategy Manager");
                    return;
                }

                // 3. Collect the row entries (public type) from the Infragistics records
                List<NinjaTrader.Gui.NinjaScript.StrategiesGridEntry> entries = CollectEntries(grid);
                Log("Entries found: " + entries.Count);
                if (entries.Count == 0)
                {
                    MessageBox.Show("No strategies found on the Strategies tab.", "Strategy Manager");
                    return;
                }

                // 4. Drive the grid's own enable/disable pipeline per entry
                if (!ResolvePipelineMethods())
                {
                    Log("Private pipeline methods not found -> falling back to routed commands");
                    FallbackViaCommands(grid, enable);
                    return;
                }

                int acted = 0, alreadyThere = 0, blocked = 0, failed = 0;
                Window owner = Window.GetWindow(grid) ?? _controlCenter;

                foreach (var entry in entries)
                {
                    try
                    {
                        StrategyBase strat = entry.Strategy;
                        if (strat == null) { blocked++; continue; }

                        // Source of truth is the ENGINE state, not the checkbox --
                        // a stale checkbox (the v1 bug) must not stop a real enable.
                        bool running = strat.State == State.Active
                                    || strat.State == State.DataLoaded
                                    || strat.State == State.Historical
                                    || strat.State == State.Transition
                                    || strat.State == State.Realtime;

                        if (enable)
                        {
                            if (running) { alreadyThere++; continue; }
                            if (!entry.IsEnabledForEnabling)
                            {
                                blocked++;   // account not connected / not enableable
                                Log("SKIP (not enableable): " + entry.Name + " @ " + entry.AccountName);
                                continue;
                            }
                            Log("Enabling: " + entry.Name + " @ " + entry.AccountName
                                + " (state=" + strat.State + ")");
                            _miStrategyEnable.Invoke(grid, new object[] { strat, owner, entry });
                            acted++;
                        }
                        else
                        {
                            if (!running) { alreadyThere++; continue; }
                            Log("Disabling: " + entry.Name + " @ " + entry.AccountName
                                + " (state=" + strat.State + ")");
                            _miStrategyDisable.Invoke(grid, new object[] { strat });
                            acted++;
                        }
                    }
                    catch (Exception exEntry)
                    {
                        failed++;
                        Log("Entry error (" + entry.Name + "): "
                            + (exEntry.InnerException ?? exEntry).Message);
                    }
                }

                string verb = enable ? "Enabled" : "Disabled";
                string msg = verb + " " + acted + " strategies."
                    + (alreadyThere > 0 ? "\nAlready " + (enable ? "enabled" : "disabled") + ": " + alreadyThere : "")
                    + (blocked > 0 ? "\nSkipped (no strategy object / account not enableable): " + blocked : "")
                    + (failed > 0 ? "\nFailed (see NinjaScript Output): " + failed : "");
                Log(verb + " " + acted + ", already=" + alreadyThere + ", blocked=" + blocked + ", failed=" + failed);
                MessageBox.Show(msg, "Strategy Manager");
            }
            catch (Exception ex)
            {
                Log("ToggleAll error: " + ex.Message);
                MessageBox.Show("Error: " + ex.Message, "Strategy Manager",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Resolve StrategiesGrid.StrategyEnable / StrategyDisable once. They are
        /// private instance methods; signatures verified against NT 8.1.5.2:
        ///   void StrategyEnable(StrategyBase, Window, StrategiesGridEntry)
        ///   void StrategyDisable(StrategyBase)
        /// </summary>
        private bool ResolvePipelineMethods()
        {
            if (_miStrategyEnable != null && _miStrategyDisable != null) return true;
            var t = typeof(NinjaTrader.Gui.NinjaScript.StrategiesGrid);
            _miStrategyEnable = t.GetMethod("StrategyEnable",
                BindingFlags.NonPublic | BindingFlags.Instance, null,
                new[] { typeof(StrategyBase), typeof(Window),
                        typeof(NinjaTrader.Gui.NinjaScript.StrategiesGridEntry) }, null);
            _miStrategyDisable = t.GetMethod("StrategyDisable",
                BindingFlags.NonPublic | BindingFlags.Instance, null,
                new[] { typeof(StrategyBase) }, null);
            return _miStrategyEnable != null && _miStrategyDisable != null;
        }

        /// <summary>
        /// Fallback for future NT8 versions: select every row, then execute the same
        /// public routed commands the grid's right-click menu uses.
        /// </summary>
        private void FallbackViaCommands(FrameworkElement grid, bool enable)
        {
            try
            {
                NinjaTrader.Gui.NinjaScript.StrategyCommands.SelectAllCommand.Execute(null, grid);
                var cmd = enable
                    ? NinjaTrader.Gui.NinjaScript.StrategyCommands.EnableStrategyCommand
                    : NinjaTrader.Gui.NinjaScript.StrategyCommands.DisableStrategyCommand;
                cmd.Execute(null, grid);
                Log("Fallback routed commands executed (SelectAll + " + (enable ? "Enable" : "Disable") + ")");
                MessageBox.Show((enable ? "Enable" : "Disable") + " command sent to all selected strategies.",
                    "Strategy Manager");
            }
            catch (Exception ex)
            {
                Log("Fallback command error: " + ex.Message);
                MessageBox.Show("Fallback failed: " + ex.Message, "Strategy Manager",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Walk the Infragistics RecordListControl items under the grid; each
        /// DataRecord's DataItem is a StrategiesGridEntry (parent rows only --
        /// child rows are StrategiesGridEntryChild and are skipped by the cast).
        /// DataRecord is reflected by name so we need no Infragistics reference.
        /// </summary>
        private List<NinjaTrader.Gui.NinjaScript.StrategiesGridEntry> CollectEntries(DependencyObject grid)
        {
            var result = new List<NinjaTrader.Gui.NinjaScript.StrategiesGridEntry>();
            var seen = new HashSet<NinjaTrader.Gui.NinjaScript.StrategiesGridEntry>();

            var itemsControls = new List<ItemsControl>();
            CollectDescendants(grid, itemsControls);
            foreach (var ic in itemsControls)
            {
                if (!ic.GetType().Name.Contains("RecordListControl")) continue;
                foreach (var item in ic.Items)
                {
                    if (item == null) continue;
                    object dataItem = item;
                    var dataItemProp = item.GetType().GetProperty("DataItem",
                        BindingFlags.Public | BindingFlags.Instance);
                    if (dataItemProp != null)
                        dataItem = dataItemProp.GetValue(item) ?? item;
                    var entry = dataItem as NinjaTrader.Gui.NinjaScript.StrategiesGridEntry;
                    if (entry != null && seen.Add(entry))
                        result.Add(entry);
                }
            }
            return result;
        }

        // ------------------------- Visual tree helpers -------------------------

        /// <summary>Find the Tools menu item by walking the WPF visual tree.</summary>
        private MenuItem FindToolsMenu(DependencyObject parent, int depth)
        {
            if (parent == null || depth > 10) return null;
            try
            {
                if (parent is Menu menu)
                {
                    foreach (var item in menu.Items)
                    {
                        if (item is MenuItem mi)
                        {
                            string h = mi.Header?.ToString()?.Replace("_", "") ?? "";
                            if (h.Equals("Tools", StringComparison.OrdinalIgnoreCase))
                                return mi;
                        }
                    }
                }
                int count = VisualTreeHelper.GetChildrenCount(parent);
                for (int i = 0; i < Math.Min(count, 50); i++)
                {
                    var child = VisualTreeHelper.GetChild(parent, i);
                    var result = FindToolsMenu(child, depth + 1);
                    if (result != null) return result;
                }
            }
            catch { }
            return null;
        }

        /// <summary>Find the "Strategies" TabItem anywhere in the window.</summary>
        private TabItem FindStrategiesTab(Window window)
        {
            var tabs = new List<TabControl>();
            CollectDescendants(window, tabs);

            foreach (var tc in tabs)
            {
                foreach (var item in tc.Items)
                {
                    if (item is TabItem tab)
                    {
                        string header = tab.Header?.ToString() ?? "";
                        if (header.IndexOf("Strateg", StringComparison.OrdinalIgnoreCase) >= 0)
                            return tab;
                    }
                }
            }
            return null;
        }

        /// <summary>BFS to find the first descendant of type T.</summary>
        private T FindFirstDescendant<T>(DependencyObject root) where T : DependencyObject
        {
            if (root == null) return null;
            var queue = new Queue<DependencyObject>();
            queue.Enqueue(root);
            while (queue.Count > 0)
            {
                var current = queue.Dequeue();
                if (current is T match)
                    return match;
                try
                {
                    int count = VisualTreeHelper.GetChildrenCount(current);
                    for (int i = 0; i < count; i++)
                        queue.Enqueue(VisualTreeHelper.GetChild(current, i));
                }
                catch { }
            }
            return null;
        }

        /// <summary>Collect all descendants of type T via BFS.</summary>
        private void CollectDescendants<T>(DependencyObject root, List<T> results)
            where T : DependencyObject
        {
            if (root == null) return;
            var queue = new Queue<DependencyObject>();
            queue.Enqueue(root);
            while (queue.Count > 0)
            {
                var current = queue.Dequeue();
                if (current is T match)
                    results.Add(match);
                try
                {
                    int count = VisualTreeHelper.GetChildrenCount(current);
                    for (int i = 0; i < count; i++)
                        queue.Enqueue(VisualTreeHelper.GetChild(current, i));
                }
                catch { }
            }
        }

        // ------------------------- Logging -------------------------

        private void Log(string msg)
        {
            try
            {
                NinjaTrader.Code.Output.Process(
                    DateTime.Now.ToString("HH:mm:ss") + " [StrategyMgr] " + msg,
                    PrintTo.OutputTab1);
            }
            catch { }
        }
    }
}
