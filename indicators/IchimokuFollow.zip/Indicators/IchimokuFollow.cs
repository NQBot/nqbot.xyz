#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Text;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// IchimokuFollow -- a manual-execution signal indicator for NinjaTrader 8.
//
// WHAT IT IS
//   A Tenkan/Kijun cross that agrees with the (non-displaced) Ichimoku cloud, priced for you to trade by
//   hand. It marks the setup, prices the entry, the stop and the target, sounds an alert and then stands
//   aside. It places NO orders and there is no strategy in this download. You place the orders.
//
// THE RULES (7 / 22 / 44, one-minute NQ)
//   * Tenkan = midpoint of the highest high and lowest low of the last 7 bars, Kijun the same over 22,
//     Senkou A = (Tenkan + Kijun) / 2, Senkou B = the same midpoint over 44. NOT displaced forward: the
//     cloud drawn is the cloud the rule measures against.
//   * Long: Tenkan crosses above Kijun and the bar closes above the top of the cloud. Short: the mirror.
//   * The cross state is tracked on every bar, around the clock; only the entry is limited to the session.
//   * ATR(14) must be at least 5 points. No new setup from 15:30 ET; anything open is closed at 15:45 ET.
//   * Entry is a limit 25% of the trigger bar's range back inside that bar, live for ONE bar only. Stop is
//     1.5 x ATR(14) clamped to 15-40 points, target 2R.
//
// NO EDGE IS CLAIMED. Tested over years of one-minute NQ data, none of the three sessions showed a reliable
// edge after costs. This is a rule set to watch, study and judge for yourself. See README.md.
//
// TIME ZONE
//   Every HHMM here is read from the chart's own clock. The presets are written in US Eastern, so set
//   NinjaTrader to Eastern (Tools > Options > General > Time zone) or translate the session hours yourself.
//
// MIT licensed. No warranty and no guarantee of profit. See LICENSE and README.md.

public enum IchimokuPreset
{
    Asian,
    European,
    US,
    Custom
}

public enum IchimokuCorner
{
    TopLeft,
    TopRight,
    BottomLeft,
    BottomRight
}

// Sounds that ship with NinjaTrader 8, plus None (no alert for that event) and
// Custom (plays the file named in "Custom sound file").
public enum IchimokuSound
{
    None,
    Alert1,
    Alert2,
    Alert3,
    Alert4,
    Announcement,
    OrderFilled,
    TargetFilled,
    StopFilled,
    Reversing,
    Custom
}

namespace NinjaTrader.NinjaScript.Indicators.PhillyFranksTools
{
    public class IchimokuFollow : Indicator
    {
        // --- Bracket construction -------------------------------------------------
        //  Consts, not settings: they are the tested shape of the trade. A saved instance keeps its
        //  own property values forever, so a risk rule written as a property is silently defeated on
        //  every instance that already exists.
        private const double EntryRetracePct  = 0.25;   // give-back into the trigger bar
        private const double AtrStopMult      = 1.5;    // 1.5 x ATR(14) at the signal bar
        private const double StopFloorPoints  = 15.0;   // never tighter than this
        private const double StopCapPoints    = 40.0;   // nor wider, unless configured wider
        private const double MaxRMultiple     = 3.0;    // ceiling on the scaled R:R

        // --- Clock rules ----------------------------------------------------------
        private const int HardNoEntryHHMM = 1530;   // no new setup is priced at/after this
        private const int HardFlatHHMM    = 1545;   // anything still open is out
        private const int HardFlatEndHHMM = 1900;   // sweep ends before the Asian window

        private const float CloudOpacity = 0.22f;

        // Effective (preset-resolved) parameters. Everything downstream reads these and never the
        // public properties, so Custom and preset runs take one code path.
        private int      effTenkan;
        private int      effKijun;
        private int      effSenkouB;
        private bool     effRequireCloudColor;
        private double   effMinAtr;
        private double   effStopPoints;
        private double   effTargetPoints;
        private int      effSessionStart;
        private int      effSessionEnd;
        private bool     effFixedBracket;   // Custom only: stop/target used exactly as typed
        private bool     resolvedAtFirstBar;
        private int      minBarsRequired = 49;
        private string   effPresetName = "";

        // Cooldown after a followed setup closes: no new setup is published for the chosen number of
        // minutes after a win or a loss, measured from the exit bar. Optional (UseCooldown), OFF by
        // default so the published rules are the tested ones. An expiry (no fill) is not a trade.
        private DateTime cooldownUntil = DateTime.MinValue;

        // Ichimoku state, refreshed every bar.
        private bool     haveCrossState;
        private bool     prevTenkanAbove;
        private double   lastTenkan, lastKijun, lastSpanA, lastSpanB, lastAtr;
        private DateTime lastDate = DateTime.MinValue;

        // Follow-along state machine. 0 = nothing, 1 = limit working (this bar only),
        // 2 = in the trade.
        private int    followState;
        private int    followDir;              // 1 long, -1 short
        private double limitPx, stopPx, targetPx, entryPx;
        private double stopPts, targetPts;
        private int    signalBar, entryBar;
        private int    tradesThisSession;
        private int    sessionWins, sessionLosses;
        private string lastOutcomeField = "";
        private string lastOutcome
        {
            get { return lastOutcomeField; }
            set { lastOutcomeField = value; if (!string.IsNullOrEmpty(value)) LogCall("NOTE", value); }
        }
        private int    drawSeq;                // unique tag suffix per setup
        private bool   forcedBarClose;

        // The panel text is kept here and drawn in OnRender (not with Draw.TextFixed) so it can sit
        // at any pixel offset from its corner. Positive X moves right, positive Y moves down.
        private string panelText = string.Empty;
        private bool panelRenderWarned;
        private bool cloudRenderWarned;

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            base.OnRender(chartControl, chartScale);
            if (!ShowVisuals || RenderTarget == null || ChartPanel == null)
                return;

            if (FillCloud)
                DrawCloud(chartControl, chartScale);

            if (!ShowPanel || string.IsNullOrEmpty(panelText))
                return;
            try
            {
                using (SharpDX.DirectWrite.TextFormat format = new SimpleFont("Consolas", PanelFontSize).ToDirectWriteTextFormat())
                using (SharpDX.DirectWrite.TextLayout layout = new SharpDX.DirectWrite.TextLayout(
                    NinjaTrader.Core.Globals.DirectWriteFactory, panelText, format, 4000f, 4000f))
                {
                    float w = layout.Metrics.Width + 14f;
                    float h = layout.Metrics.Height + 10f;
                    float margin = 6f;
                    float left = ChartPanel.X + margin;
                    float top = ChartPanel.Y + margin;
                    if (PanelCorner == IchimokuCorner.TopRight || PanelCorner == IchimokuCorner.BottomRight)
                        left = ChartPanel.X + ChartPanel.W - w - margin;
                    if (PanelCorner == IchimokuCorner.BottomLeft || PanelCorner == IchimokuCorner.BottomRight)
                        top = ChartPanel.Y + ChartPanel.H - h - margin;
                    left += PanelOffsetX;
                    top += PanelOffsetY;
                    using (SharpDX.Direct2D1.Brush back = PanelArea.ToDxBrush(RenderTarget))
                    using (SharpDX.Direct2D1.Brush fore = PanelText.ToDxBrush(RenderTarget))
                    {
                        back.Opacity = 0.6f;
                        RenderTarget.FillRectangle(new SharpDX.RectangleF(left, top, w, h), back);
                        RenderTarget.DrawTextLayout(new SharpDX.Vector2(left + 7f, top + 5f), layout, fore);
                    }
                }
            }
            catch (Exception ex)
            {
                if (!panelRenderWarned)
                {
                    panelRenderWarned = true;
                    Log(Name + ": panel could not be drawn: " + ex.Message, LogLevel.Warning);
                }
            }
        }

        // The cloud between Senkou A and Senkou B, one polygon for the visible bars. Brushes and geometry
        // are created inside OnRender and disposed here, so nothing outlives the render target.
        private void DrawCloud(ChartControl chartControl, ChartScale chartScale)
        {
            if (ChartBars == null || Bars == null)
                return;
            try
            {
                int from = Math.Max(ChartBars.FromIndex, minBarsRequired);
                int to   = Math.Min(ChartBars.ToIndex, Bars.Count - 1);
                // The forming bar has no value yet (the indicator runs on bar close): stop at the last bar that does.
                while (to > from && (!Values[2].IsValidDataPointAt(to) || !Values[3].IsValidDataPointAt(to)))
                    to--;
                if (to - from < 1)
                    return;

                using (SharpDX.Direct2D1.PathGeometry geo = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory))
                {
                    SharpDX.Direct2D1.GeometrySink sink = geo.Open();
                    try
                    {
                        sink.BeginFigure(new SharpDX.Vector2(chartControl.GetXByBarIndex(ChartBars, from),
                            chartScale.GetYByValue(Values[2].GetValueAt(from))), SharpDX.Direct2D1.FigureBegin.Filled);
                        for (int i = from + 1; i <= to; i++)
                            sink.AddLine(new SharpDX.Vector2(chartControl.GetXByBarIndex(ChartBars, i),
                                chartScale.GetYByValue(Values[2].GetValueAt(i))));
                        for (int i = to; i >= from; i--)
                            sink.AddLine(new SharpDX.Vector2(chartControl.GetXByBarIndex(ChartBars, i),
                                chartScale.GetYByValue(Values[3].GetValueAt(i))));
                        sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
                    }
                    finally
                    {
                        sink.Close();
                        sink.Dispose();
                    }
                    using (SharpDX.Direct2D1.Brush fill = CloudBrush.ToDxBrush(RenderTarget))
                    {
                        fill.Opacity = CloudOpacity;
                        RenderTarget.FillGeometry(geo, fill);
                    }
                }
            }
            catch (Exception ex)
            {
                if (!cloudRenderWarned)
                {
                    cloudRenderWarned = true;
                    Log(Name + ": cloud could not be filled (untick Fill cloud to hide this): " + ex.Message, LogLevel.Warning);
                }
            }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name                     = "IchimokuFollow";
                Description              = "Ichimoku (7/22/44) Tenkan/Kijun cross outside the cloud, priced for manual execution. Plots the cloud, draws the entry, stop and target, and places no orders.";
                Calculate                = Calculate.OnBarClose;
                IsOverlay                = true;
                DrawOnPricePanel         = true;
                DisplayInDataBox         = false;
                PaintPriceMarkers        = false;
                IsSuspendedWhileInactive = false;

                Preset      = IchimokuPreset.Asian;
                ShowVisuals = true;

                TenkanPeriod        = 7;
                KijunPeriod         = 22;
                SenkouBPeriod       = 44;
                RequireCloudColor   = false;
                MinAtr              = 5.0;
                StopPoints          = 15;
                TargetPoints        = 30;
                SessionStartHHMM    = 2000;
                SessionEndHHMM      = 130;
                FixedBracket        = false;
                MaxTradesPerSession = 99;
                AvoidLunchChop      = false;
                NewsBlackoutHHMM    = string.Empty;
                UseCooldown         = false;
                CooldownWinMin      = 15;
                CooldownLossMin     = 45;

                ShowPanel       = true;
                ShowManualReminder = true;
                PanelCorner     = IchimokuCorner.TopRight;
                PanelFontSize   = 13;
                PanelOffsetX    = 0;
                PanelOffsetY    = 0;
                HideOutsideSession  = false;
                LabelFontSize   = 12;
                LabelOffsetBars = 6;
                FillCloud       = true;
                EnableAlerts    = true;
                SetupSound      = IchimokuSound.Alert1;
                FillSound       = IchimokuSound.None;
                ExpirySound     = IchimokuSound.None;
                CustomSoundFile = string.Empty;
                RiskPerTradeUsd = 0;

                LongBrush   = Brushes.LimeGreen;
                ShortBrush  = Brushes.OrangeRed;
                StopBrush   = Brushes.IndianRed;
                TargetBrush = Brushes.MediumSeaGreen;
                PanelText   = Brushes.Gainsboro;
                PanelArea   = Brushes.Black;
                CloudBrush  = Brushes.SlateGray;

                // The lines are plots, not drawing objects: a Draw call per bar would leave one object
                // per bar on the chart for the life of the session.
                AddPlot(new Stroke(Brushes.DodgerBlue, 1),      PlotStyle.Line, "Tenkan");
                AddPlot(new Stroke(Brushes.Orange, 1),          PlotStyle.Line, "Kijun");
                AddPlot(new Stroke(Brushes.MediumSeaGreen, 1),  PlotStyle.Line, "Cloud span A");
                AddPlot(new Stroke(Brushes.IndianRed, 1),       PlotStyle.Line, "Cloud span B");
                // Setup levels as real plots, so Entry / Stop / Target can be picked as an
                // input series (Data Box, other indicators, alerts). Appended after the
                // existing plots so their indexes do not move. Unassigned outside a setup.
                AddPlot(new Stroke(Brushes.Gold,           DashStyleHelper.Dot, 1), PlotStyle.Line, "Entry");
                AddPlot(new Stroke(Brushes.IndianRed,      DashStyleHelper.Dot, 1), PlotStyle.Line, "Stop");
                AddPlot(new Stroke(Brushes.MediumSeaGreen, DashStyleHelper.Dot, 1), PlotStyle.Line, "Target");
            }
            else if (State == State.Configure)
            {
                // Bar-close evaluation is not optional: an intrabar evaluation would show setups that
                // the closed bar never produced and retract them as the bar moved.
                if (Calculate != Calculate.OnBarClose)
                {
                    Calculate      = Calculate.OnBarClose;
                    forcedBarClose = true;
                }
                ResolvePreset();
            }
            else if (State == State.DataLoaded)
            {
                if (forcedBarClose)
                    Log(Name + ": Calculate was forced back to OnBarClose so the display matches the tested rules.", LogLevel.Information);
            }
        }

        // The three presets differ only in the session window. Custom hands control to the properties
        // below, for research -- a tuned Custom run is your configuration, not a published one.
        private void ResolvePreset()
        {
            effFixedBracket      = false;
            effRequireCloudColor = false;
            effTenkan = 7; effKijun = 22; effSenkouB = 44;
            effMinAtr = 5.0;
            effStopPoints = 15; effTargetPoints = 30;
            switch (Preset)
            {
                case IchimokuPreset.Asian:
                    effSessionStart = 2000; effSessionEnd = 130;
                    effPresetName   = "Asian (20:00-01:30 ET)";
                    break;

                case IchimokuPreset.European:
                    effSessionStart = 300; effSessionEnd = 800;
                    effPresetName   = "European (03:00-08:00 ET)";
                    break;

                case IchimokuPreset.US:
                    effSessionStart = 930; effSessionEnd = 1530;
                    effPresetName   = "US (09:30-15:30 ET)";
                    break;

                default:
                    effTenkan = Math.Max(1, TenkanPeriod); effKijun = Math.Max(1, KijunPeriod); effSenkouB = Math.Max(1, SenkouBPeriod);
                    effRequireCloudColor = RequireCloudColor;
                    effMinAtr = MinAtr;
                    effStopPoints = StopPoints; effTargetPoints = TargetPoints;
                    effSessionStart = SessionStartHHMM; effSessionEnd = SessionEndHHMM;
                    effFixedBracket = FixedBracket;
                    effPresetName = "Custom";
                    break;
            }
            minBarsRequired = Math.Max(effSenkouB, Math.Max(effTenkan, effKijun)) + 5;
        }

        // Highest high / lowest low of the last `period` bars including the current one.
        private double HighestHigh(int period)
        {
            double v = High[0];
            int n = Math.Min(period, CurrentBar + 1);
            for (int i = 1; i < n; i++)
                if (High[i] > v) v = High[i];
            return v;
        }

        private double LowestLow(int period)
        {
            double v = Low[0];
            int n = Math.Min(period, CurrentBar + 1);
            for (int i = 1; i < n; i++)
                if (Low[i] < v) v = Low[i];
            return v;
        }

        // Index of the "Entry" plot; "Stop" and "Target" follow it.
        private const int LevelPlotBase = 4;

        protected override void OnBarUpdate()
        {
            OnBarUpdateCore();
            PublishLevelPlots();
        }

        // While a setup is pending or open the three levels are published every bar;
        // otherwise the plots are left unassigned so they gap instead of drawing to zero.
        // Pending: Entry is the limit price. Open: Entry is the fill price.
        private void PublishLevelPlots()
        {
            if (followState == 0)
            {
                Values[LevelPlotBase].Reset();
                Values[LevelPlotBase + 1].Reset();
                Values[LevelPlotBase + 2].Reset();
                return;
            }
            Values[LevelPlotBase][0]     = followState == 1 ? limitPx : entryPx;
            Values[LevelPlotBase + 1][0] = stopPx;
            Values[LevelPlotBase + 2][0] = targetPx;
        }

        private void OnBarUpdateCore()
        {
            if (!resolvedAtFirstBar)
            {
                ResolvePreset();
                resolvedAtFirstBar = true;
            }

            if (CurrentBar < minBarsRequired)
                return;

            if (Time[0].Date != lastDate)
            {
                tradesThisSession = 0;
                sessionWins = 0; sessionLosses = 0;
                lastDate = Time[0].Date;
            }

            int now = ToTime(Time[0]) / 100;

            // A trade that is already on is managed on every bar, in or out of the entry window.
            MaintainOpenTrade(now);

            double tenkan = (HighestHigh(effTenkan) + LowestLow(effTenkan)) / 2.0;
            double kijun  = (HighestHigh(effKijun)  + LowestLow(effKijun))  / 2.0;
            double spanA  = (tenkan + kijun) / 2.0;
            double spanB  = (HighestHigh(effSenkouB) + LowestLow(effSenkouB)) / 2.0;
            double cloudTop    = Math.Max(spanA, spanB);
            double cloudBottom = Math.Min(spanA, spanB);
            double atr = ATR(14)[0];

            Values[0][0] = tenkan;
            Values[1][0] = kijun;
            Values[2][0] = spanA;
            Values[3][0] = spanB;
            lastTenkan = tenkan; lastKijun = kijun; lastSpanA = spanA; lastSpanB = spanB; lastAtr = atr;

            // The TK state is tracked on every bar, around the clock, exactly as the tested rules do;
            // only the ENTRY is limited to the session window.
            bool tenkanAbove = tenkan > kijun;
            if (!haveCrossState)
            {
                prevTenkanAbove = tenkanAbove;
                haveCrossState  = true;
                DrawPanel(now, InEntryWindow(now) ? null : "OUT OF WINDOW");
                return;
            }
            bool bullishCross = tenkanAbove && !prevTenkanAbove;
            bool bearishCross = !tenkanAbove && prevTenkanAbove;
            prevTenkanAbove = tenkanAbove;

            if (!InEntryWindow(now))
            {
                DrawPanel(now, "OUT OF WINDOW");
                return;
            }
            if (!bullishCross && !bearishCross)
            {
                DrawPanel(now, null);
                return;
            }
            if (InNewsBlackout(now))
            {
                DrawPanel(now, null);
                return;
            }
            if (effMinAtr > 0 && atr < effMinAtr)
            {
                lastOutcome = "TK CROSS SKIPPED - ATR(14) " + atr.ToString("0.00", CultureInfo.InvariantCulture)
                    + " is below the " + effMinAtr.ToString("0.##", CultureInfo.InvariantCulture) + " gate";
                DrawPanel(now, null);
                return;
            }

            double price = Close[0];
            int signal = 0;
            if (bullishCross && price > cloudTop)
            {
                if (!effRequireCloudColor || spanA > spanB) signal = 1;
            }
            else if (bearishCross && price < cloudBottom)
            {
                if (!effRequireCloudColor || spanA < spanB) signal = -1;
            }

            if (signal == 0)
            {
                lastOutcome = "TK CROSS SKIPPED - price not outside the cloud";
                DrawPanel(now, null);
                return;
            }

            if (UseCooldown && Time[0] < cooldownUntil)
            {
                DrawPanel(now, "COOLDOWN until " + cooldownUntil.ToString("HH:mm", CultureInfo.InvariantCulture));
                return;
            }

            PublishSetup(signal, atr);
            DrawPanel(now, null);
        }

        // Price the order: a limit EntryRetracePct back inside the trigger bar, with an ATR-scaled
        // bracket whose R multiple comes from the configured stop/target ratio. The follow display only
        // arms when no other setup is already being followed.
        private void PublishSetup(int dir, double atr)
        {
            double rng = High[0] - Low[0];
            double px  = dir == 1 ? Close[0] - EntryRetracePct * rng
                                  : Close[0] + EntryRetracePct * rng;
            if (rng <= 0 || px <= 0) px = Close[0];
            try { px = Instrument.MasterInstrument.RoundToTickSize(px); } catch { }

            // The clamp may only ever WIDEN a configured stop, never tighten it.
            double sp, r;
            if (effFixedBracket && effStopPoints > 0 && effTargetPoints > 0)
            {
                // Custom + Fixed bracket: exactly the stop and target that were typed in.
                sp = effStopPoints;
                r  = effTargetPoints / effStopPoints;
            }
            else
            {
                double lo = Math.Max(StopFloorPoints, effStopPoints);
                double hi = Math.Max(StopCapPoints, lo);
                sp = atr > 0 ? Math.Max(lo, Math.Min(hi, AtrStopMult * atr)) : lo;
                r  = Math.Min(MaxRMultiple, effStopPoints > 0 ? effTargetPoints / effStopPoints : 1.0);
            }

            double stopDistance, targetDistance;
            if (TickSize > 0)
            {
                stopDistance   = Math.Round(sp / TickSize) * TickSize;
                targetDistance = Math.Round(sp * r / TickSize) * TickSize;
            }
            else
            {
                stopDistance   = sp;
                targetDistance = sp * r;
            }


            // Already following one, or out of setups for the session: the strategy
            // would decline this, so the chart declines it too and says why.
            if (followState != 0)
            {
                lastOutcome = "SETUP SKIPPED - already in a trade";
                return;
            }
            if (tradesThisSession >= MaxTradesPerSession)
            {
                lastOutcome = "SETUP SKIPPED - session limit reached";
                return;
            }

            stopPts     = stopDistance;
            targetPts   = targetDistance;
            followState = 1;
            followDir   = dir;
            limitPx     = px;
            signalBar   = CurrentBar;
            stopPx      = dir == 1 ? px - stopPts   : px + stopPts;
            targetPx    = dir == 1 ? px + targetPts : px - targetPts;
            drawSeq++;
            LogCall("SETUP", (dir == 1 ? "LONG" : "SHORT") + " | limit " + limitPx.ToString("0.00", CultureInfo.InvariantCulture)
                + " | stop " + stopPx.ToString("0.00", CultureInfo.InvariantCulture) + " (" + stopPts.ToString("0.##", CultureInfo.InvariantCulture) + " pts)"
                + " | target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture) + " (" + targetPts.ToString("0.##", CultureInfo.InvariantCulture) + " pts)");

            if (ShowVisuals && ChartControl != null)
            {
                Brush  b = dir == 1 ? LongBrush : ShortBrush;
                string t = "ic" + drawSeq;
                if (dir == 1) Draw.ArrowUp(this, t + "arw", false, 0, Low[0] - 2 * TickSize, b);
                else          Draw.ArrowDown(this, t + "arw", false, 0, High[0] + 2 * TickSize, b);
                DrawFollowLines();
            }

            RaiseAlert("icSetup", SetupSound, Priority.High,
                (dir == 1 ? "LONG" : "SHORT") + " Ichimoku setup -- limit "
                + limitPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ", stop " + stopPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ", target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ". Valid for one bar.",
                dir == 1 ? LongBrush : ShortBrush);
        }

        // --- Persistent daily call log (added 2026-10-28) ------------------------------------------
        //  The panel and the chart drawings die with the workspace, so the calls were lost whenever the
        //  indicator reloaded. Every call is appended to disk as it happens: one JSON line per call, one
        //  file per trading day (18:00 ET roll). Realtime only, so a reload never replays history into it.
        //  Independent of any strategy or account state: it keeps recording after an account has passed
        //  or failed for the day.
        private static readonly object callLogLock = new object();
        // Opt-in: logging is OFF unless NQBotFollowerCallLog.txt exists in the NinjaTrader user data folder
        // (Documents\NinjaTrader 8) and its first line is a folder path. No file, nothing is written.
        private const string CallLogConfigFile = "NQBotFollowerCallLog.txt";
        private static string callLogDirCached;
        private static DateTime callLogDirChecked = DateTime.MinValue;

        private static string CallLogDir()
        {
            lock (callLogLock)
            {
                DateTime now = DateTime.UtcNow;
                if ((now - callLogDirChecked).TotalSeconds < 60) return callLogDirCached;
                callLogDirChecked = now;
                callLogDirCached = null;
                try
                {
                    // the NinjaTrader user data folder, then Documents\NinjaTrader 8 as a second place to look
                    string[] baseDirs = new string[] {
                        NinjaTrader.Core.Globals.UserDataDir,
                        System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments), "NinjaTrader 8") };
                    foreach (string baseDir in baseDirs)
                    {
                        if (string.IsNullOrEmpty(baseDir)) continue;
                        string cfg = System.IO.Path.Combine(baseDir, CallLogConfigFile);
                        if (!System.IO.File.Exists(cfg)) continue;
                        string[] cfgLines = System.IO.File.ReadAllLines(cfg);
                        if (cfgLines.Length == 0) continue;
                        string d = cfgLines[0].Trim();
                        if (d.Length > 0 && System.IO.Path.IsPathRooted(d)) { callLogDirCached = d; break; }
                    }
                }
                catch { callLogDirCached = null; }
                return callLogDirCached;
            }
        }

        private static string JsonEsc(string s)
        {
            if (s == null) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", " ").Replace("\n", " ");
        }

        private void LogCall(string kind, string detail)
        {
            try
            {
                if (State != State.Realtime) return;
                string logDir = CallLogDir();
                if (logDir == null) return;
                DateTime now = DateTime.Now;
                string bar = "";
                try { bar = Time[0].ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture); } catch { }
                string line = "{\"at\":\"" + now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "\""
                    + ",\"bar\":\"" + bar + "\""
                    + ",\"indicator\":\"" + Name + "\""
                    + ",\"instrument\":\"" + JsonEsc(Instrument != null ? Instrument.FullName : "") + "\""
                    + ",\"kind\":\"" + kind + "\""
                    + ",\"detail\":\"" + JsonEsc(detail) + "\""
                    + ",\"setupsToday\":" + tradesThisSession.ToString(CultureInfo.InvariantCulture)
                    + ",\"wins\":" + sessionWins.ToString(CultureInfo.InvariantCulture)
                    + ",\"losses\":" + sessionLosses.ToString(CultureInfo.InvariantCulture) + "}";
                string day = now.AddHours(6).ToString("yyyyMMdd", CultureInfo.InvariantCulture);
                lock (callLogLock)
                {
                    System.IO.Directory.CreateDirectory(logDir);
                    System.IO.File.AppendAllText(System.IO.Path.Combine(logDir, Name + "_calls_" + day + ".jsonl"),
                        line + "\r\n");
                }
            }
            catch { }
        }

        private void RaiseAlert(string id, IchimokuSound sound, Priority priority,
            string message, Brush foreground)
        {
            LogCall("ALERT", id + " | " + message);
            if (!EnableAlerts || !ShowVisuals || sound == IchimokuSound.None)
                return;
            try
            {
                Alert(id + drawSeq, priority, message, SoundPath(sound),
                    10, Brushes.Black, foreground);
            }
            catch { }
        }

        // NinjaTrader wants a full path; a bare file name is resolved against the
        // install's own sounds folder, so the stock choices work on any machine.
        private string SoundPath(IchimokuSound sound)
        {
            string file = sound == IchimokuSound.Custom
                ? (CustomSoundFile ?? string.Empty).Trim()
                : sound.ToString() + ".wav";

            if (file.Length == 0)
                return string.Empty;
            if (file.IndexOf('\\') >= 0 || file.IndexOf('/') >= 0)
                return file;
            return NinjaTrader.Core.Globals.InstallDir + @"sounds\" + file;
        }

        // Resolve a working limit, then manage an open trade. Deliberately pessimistic
        // wherever one bar cannot tell you the order of events:
        //   * on the bar the limit fills, only the stop is checked. A backtest that
        //     credits a target on the fill bar reports profit factors it never earned.
        //   * from the next bar on, a bar that touches both is recorded as the stop.
        // Your real fill may be better than this. It should rarely be worse.
        private void MaintainOpenTrade(int now)
        {
            if (followState == 0)
                return;

            if (followState == 1)
            {
                if (CurrentBar <= signalBar)
                    return;

                bool filled = followDir == 1 ? Low[0] <= limitPx : High[0] >= limitPx;
                if (!filled)
                {
                    RaiseAlert("icExpiry", ExpirySound, Priority.Medium,
                        "Ichimoku limit expired unfilled at "
                        + limitPx.ToString("0.00", CultureInfo.InvariantCulture)
                        + " -- cancel the order and stand down.",
                        Brushes.DimGray);
                    CloseFollow("EXPIRED - no fill, stand down", 0, limitPx);
                    return;
                }

                // A gap through the limit fills at the open, in your favour.
                entryPx  = followDir == 1 ? Math.Min(limitPx, Open[0]) : Math.Max(limitPx, Open[0]);
                stopPx   = followDir == 1 ? entryPx - stopPts   : entryPx + stopPts;
                targetPx = followDir == 1 ? entryPx + targetPts : entryPx - targetPts;
                entryBar    = CurrentBar;
                followState = 2;
                tradesThisSession++;
                LogCall("FILL", (followDir == 1 ? "LONG" : "SHORT") + " | entry " + entryPx.ToString("0.00", CultureInfo.InvariantCulture)
                    + " | stop " + stopPx.ToString("0.00", CultureInfo.InvariantCulture)
                    + " | target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture));
                DrawFollowLines();

                RaiseAlert("icFill", FillSound, Priority.Medium,
                    (followDir == 1 ? "LONG" : "SHORT") + " Ichimoku limit filled at "
                    + entryPx.ToString("0.00", CultureInfo.InvariantCulture)
                    + " -- stop " + stopPx.ToString("0.00", CultureInfo.InvariantCulture)
                    + ", target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture) + ".",
                    followDir == 1 ? LongBrush : ShortBrush);

                // Fill bar: stop only.
                if (followDir == 1 ? Low[0] <= stopPx : High[0] >= stopPx)
                    CloseFollow("STOPPED", -1, stopPx);
                return;
            }

            if (now >= HardFlatHHMM && now < HardFlatEndHHMM)
            {
                double points = (Close[0] - entryPx) * followDir;
                CloseFollow("FLAT 15:45 ET - session rule", points < 0 ? -1 : 0, Close[0]);
                return;
            }

            bool hitStop   = followDir == 1 ? Low[0]  <= stopPx   : High[0] >= stopPx;
            bool hitTarget = followDir == 1 ? High[0] >= targetPx : Low[0]  <= targetPx;

            if (hitStop)        CloseFollow("STOPPED", -1, stopPx);
            else if (hitTarget) CloseFollow("TARGET", 1, targetPx);
            else                DrawFollowLines();
        }

        // result: 1 target, -1 stop, 0 neither (an expiry or a flat on the clock).
        private void CloseFollow(string outcome, int result, double markPx)
        {
            // The setup is over, so everything it drew comes off the chart and the next
            // setup starts on a clean one. The outcome stays in the panel ("Last: ...").
            if (ShowVisuals && ChartControl != null)
            {
                string t = "ic" + drawSeq;
                string[] tags = { "arw", "txt", "lim", "stp", "tgt", "stpTxt", "tgtTxt", "exp", "exit" };
                foreach (string tag in tags)
                    RemoveDrawObject(t + tag);
            }

            lastOutcomeField = outcome;
            LogCall("EXIT", outcome + " | result " + result + " | mark " + markPx.ToString("0.00", CultureInfo.InvariantCulture)
                + " | dir " + followDir + " | entry " + entryPx.ToString("0.00", CultureInfo.InvariantCulture)
                + " | stop " + stopPx.ToString("0.00", CultureInfo.InvariantCulture)
                + " | target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture));
            if (result > 0) sessionWins++;
            if (result < 0) sessionLosses++;
            if (UseCooldown && result != 0)
                cooldownUntil = Time[0].AddMinutes(result > 0 ? CooldownWinMin : CooldownLossMin);
            followState = 0;
            followDir   = 0;
        }

        // Lines run from the bar that created them to the CURRENT bar and are redrawn
        // each update, rather than being projected into the future: one object per
        // setup, and it tracks the trade instead of floating off the right edge.
        private void DrawFollowLines()
        {
            if (!ShowVisuals || ChartControl == null || followState == 0)
                return;

            string t = "ic" + drawSeq;
            Brush  b = followDir == 1 ? LongBrush : ShortBrush;
            int    signalBars = Math.Max(0, CurrentBar - signalBar);

            // Every label is anchored to the latest bar and printed to the RIGHT of its
            // line, so it never sits on top of the candles. Re-drawing under the same
            // tag each bar moves it along with the line.
            SimpleFont labelFont = new SimpleFont("Arial", LabelFontSize);
            string pad = "  ";
            Draw.Text(this, t + "txt", false, pad + (followDir == 1 ? "LONG limit " : "SHORT limit ")
                + limitPx.ToString("0.00", CultureInfo.InvariantCulture),
                -LabelOffsetBars, limitPx, 0, b, labelFont, System.Windows.TextAlignment.Left,
                Brushes.Transparent, Brushes.Transparent, 0);

            if (followState == 1)
            {
                Draw.Line(this, t + "lim", false, signalBars, limitPx, 0, limitPx, b, DashStyleHelper.Dash, 2);
                return;
            }

            int entryBars = Math.Max(0, CurrentBar - entryBar);
            Draw.Line(this, t + "lim", false, signalBars, limitPx,  0, limitPx,  b,           DashStyleHelper.Dash,  1);
            Draw.Line(this, t + "stp", false, entryBars,  stopPx,   0, stopPx,   StopBrush,   DashStyleHelper.Solid, 2);
            Draw.Line(this, t + "tgt", false, entryBars,  targetPx, 0, targetPx, TargetBrush, DashStyleHelper.Solid, 2);

            Draw.Text(this, t + "stpTxt", false, pad + "stop loss " + stopPx.ToString("0.00", CultureInfo.InvariantCulture),
                -LabelOffsetBars, stopPx, 0, StopBrush, labelFont, System.Windows.TextAlignment.Left,
                Brushes.Transparent, Brushes.Transparent, 0);
            Draw.Text(this, t + "tgtTxt", false, pad + "target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture),
                -LabelOffsetBars, targetPx, 0, TargetBrush, labelFont, System.Windows.TextAlignment.Left,
                Brushes.Transparent, Brushes.Transparent, 0);
        }

        private bool InEntryWindow(int now)
        {
            if (now >= HardNoEntryHHMM && now < HardFlatEndHHMM) return false;
            if (effSessionStart <= effSessionEnd) return now >= effSessionStart && now < effSessionEnd;
            return now >= effSessionStart || now < effSessionEnd;
        }

        private bool InNewsBlackout(int now)
        {
            if (AvoidLunchChop && now >= 1200 && now < 1300) return true;
            if (string.IsNullOrEmpty(NewsBlackoutHHMM)) return false;
            foreach (var range in NewsBlackoutHHMM.Split(';'))
            {
                var parts = range.Split('-');
                if (parts.Length != 2) continue;
                int s, e;
                if (!int.TryParse(parts[0].Trim(), out s)) continue;
                if (!int.TryParse(parts[1].Trim(), out e)) continue;
                if (now >= s && now < e) return true;
            }
            return false;
        }

        private void DrawPanel(int now, string windowNote)
        {
            if (!ShowVisuals || !ShowPanel || ChartControl == null)
            {
                panelText = string.Empty;
                return;
            }

            // Out of session with nothing being followed: show nothing, so a shared corner only ever
            // holds the panel of the indicator that is in session.
            if (HideOutsideSession && followState == 0 && windowNote == "OUT OF WINDOW")
            {
                panelText = string.Empty;
                ForceRefresh();
                return;
            }

            double pointValue = 0;
            try { pointValue = Instrument.MasterInstrument.PointValue; } catch { }

            double price = Close[0];
            double cloudTop    = Math.Max(lastSpanA, lastSpanB);
            double cloudBottom = Math.Min(lastSpanA, lastSpanB);
            string placement = price > cloudTop ? "ABOVE" : (price < cloudBottom ? "BELOW" : "INSIDE");

            var sb = new StringBuilder(640);
            sb.Append("ICHIMOKU - MANUAL FOLLOW").Append('\n');
            sb.Append(effPresetName).Append('\n');
            sb.Append("Clock ").Append(FormatHHMM(now));
            sb.Append("   window ").Append(FormatHHMM(effSessionStart)).Append('-').Append(FormatHHMM(effSessionEnd));
            if (windowNote != null) sb.Append("  [").Append(windowNote).Append(']');
            sb.Append('\n');
            sb.Append("Tenkan ").Append(lastTenkan.ToString("0.00", CultureInfo.InvariantCulture))
              .Append("   Kijun ").Append(lastKijun.ToString("0.00", CultureInfo.InvariantCulture))
              .Append("   TK ").Append(lastTenkan > lastKijun ? "bullish" : "bearish").Append('\n');
            sb.Append("Cloud ").Append(cloudBottom.ToString("0.00", CultureInfo.InvariantCulture))
              .Append(" - ").Append(cloudTop.ToString("0.00", CultureInfo.InvariantCulture))
              .Append("   price ").Append(placement).Append('\n');
            sb.Append("ATR(14) ").Append(lastAtr.ToString("0.00", CultureInfo.InvariantCulture))
              .Append("   gate ").Append(effMinAtr.ToString("0.##", CultureInfo.InvariantCulture)).Append('\n');
            sb.Append("------------------------------------------\n");

            if (followState == 1)
            {
                sb.Append(followDir == 1 ? "WORKING LIMIT - LONG" : "WORKING LIMIT - SHORT").Append('\n');
                sb.Append("Valid for THIS BAR ONLY\n");
                sb.Append("Limit     ").Append(limitPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Stop loss ").Append(stopPx.ToString("0.00", CultureInfo.InvariantCulture))
                  .Append("   (").Append(stopPts.ToString("0.##", CultureInfo.InvariantCulture)).Append(" pts)").Append('\n');
                sb.Append("Target    ").Append(targetPx.ToString("0.00", CultureInfo.InvariantCulture))
                  .Append("   (").Append(targetPts.ToString("0.##", CultureInfo.InvariantCulture)).Append(" pts)").Append('\n');
            }
            else if (followState == 2)
            {
                sb.Append(followDir == 1 ? "IN TRADE - LONG" : "IN TRADE - SHORT").Append('\n');
                sb.Append("Entry     ").Append(entryPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Stop loss ").Append(stopPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Target    ").Append(targetPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                double open = (Close[0] - entryPx) * followDir;
                sb.Append("Open      ").Append(open.ToString("+0.00;-0.00;0.00", CultureInfo.InvariantCulture)).Append(" pts")
                  .Append("   bars held ").Append(CurrentBar - entryBar).Append('\n');
            }
            else
            {
                sb.Append("WATCHING - needs a TK cross with price outside the cloud\n");
                if (!string.IsNullOrEmpty(lastOutcome))
                    sb.Append("Last: ").Append(lastOutcome).Append('\n');
            }

            if (followState != 0 && pointValue > 0)
            {
                double riskPerContract = stopPts * pointValue;
                sb.Append("Risk      $").Append(riskPerContract.ToString("0", CultureInfo.InvariantCulture)).Append(" per contract");
                if (RiskPerTradeUsd > 0 && riskPerContract > 0)
                {
                    int size = (int)Math.Floor(RiskPerTradeUsd / riskPerContract);
                    sb.Append("   -> ").Append(size).Append(size == 1 ? " contract" : " contracts")
                      .Append(" at $").Append(RiskPerTradeUsd.ToString("0", CultureInfo.InvariantCulture));
                }
                sb.Append('\n');
            }

            sb.Append("------------------------------------------\n");
            sb.Append("Setups filled today ").Append(tradesThisSession).Append(" / ").Append(MaxTradesPerSession);
            sb.Append("    target ").Append(sessionWins).Append("  stop loss ").Append(sessionLosses);
            if (ShowManualReminder)
                sb.Append("\nYOU place the orders. Nothing here trades.");

            panelText = sb.ToString();
            ForceRefresh();
        }

        private static string FormatHHMM(int hhmm)
        {
            int h = hhmm / 100, m = hhmm % 100;
            return h.ToString("00", CultureInfo.InvariantCulture) + ":" + m.ToString("00", CultureInfo.InvariantCulture);
        }

        #region Properties
        // Only Preset and ShowVisuals carry [NinjaScriptProperty], like the other follow indicators.
        // Everything else is a plain [Display] property.
        [NinjaScriptProperty]
        [Display(Name = "Preset", Order = 1, GroupName = "1. Setup", Description = "Session to follow. The three presets differ only in their window. Custom hands control to the parameters below.")]
        public IchimokuPreset Preset { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show visuals", Order = 2, GroupName = "1. Setup", Description = "Off hides the cloud fill, arrows, lines and panel.")]
        public bool ShowVisuals { get; set; }

        [Range(1, 60)]
        [Display(Name = "Tenkan period", Order = 1, GroupName = "2. Custom rules")]
        public int TenkanPeriod { get; set; }

        [Range(1, 120)]
        [Display(Name = "Kijun period", Order = 2, GroupName = "2. Custom rules")]
        public int KijunPeriod { get; set; }

        [Range(1, 240)]
        [Display(Name = "Senkou B period", Order = 3, GroupName = "2. Custom rules")]
        public int SenkouBPeriod { get; set; }

        [Display(Name = "Require cloud colour to agree", Order = 4, GroupName = "2. Custom rules", Description = "Long only when Senkou A is above Senkou B, short only when it is below.")]
        public bool RequireCloudColor { get; set; }

        [Range(0, 200)]
        [Display(Name = "Min ATR(14) (0 = off)", Order = 5, GroupName = "2. Custom rules", Description = "A cross is skipped when ATR(14) is below this many points.")]
        public double MinAtr { get; set; }

        [Range(0.25, 200)]
        [Display(Name = "Stop (points)", Order = 6, GroupName = "2. Custom rules", Description = "Floor for the ATR stop and, with the target, the R multiple.")]
        public double StopPoints { get; set; }

        [Range(0.25, 200)]
        [Display(Name = "Target (points)", Order = 7, GroupName = "2. Custom rules")]
        public double TargetPoints { get; set; }

        [Range(0, 2400)]
        [Display(Name = "Session start (HHMM)", Order = 8, GroupName = "2. Custom rules")]
        public int SessionStartHHMM { get; set; }

        [Range(0, 2400)]
        [Display(Name = "Session end (HHMM)", Order = 9, GroupName = "2. Custom rules")]
        public int SessionEndHHMM { get; set; }

        [Display(Name = "Fixed bracket", Order = 10, GroupName = "2. Custom rules", Description = "Off: the stop is 1.5 x ATR, never tighter than the stop above and never wider than 40 (or the stop above if wider), and the target scales to it. On: the stop and target above are used exactly as typed.")]
        public bool FixedBracket { get; set; }

        [Range(1, 999)]
        [Display(Name = "Max setups / session", Order = 1, GroupName = "3. Filters")]
        public int MaxTradesPerSession { get; set; }

        [Display(Name = "Avoid lunch chop (12:00-13:00)", Order = 2, GroupName = "3. Filters")]
        public bool AvoidLunchChop { get; set; }

        [Display(Name = "News blackout (HHMM-HHMM;...)", Order = 3, GroupName = "3. Filters", Description = "Your own event windows, entered by hand. Nothing is downloaded.")]
        public string NewsBlackoutHHMM { get; set; }

        [Display(Name = "Use cooldown", Order = 4, GroupName = "3. Filters", Description = "On: after a followed setup closes, no new setup is published until the cooldown below has passed. Off (the default, and the tested rules): setups are published as soon as they form.")]
        public bool UseCooldown { get; set; }

        [Range(0, 600)]
        [Display(Name = "Cooldown after a win (min)", Order = 5, GroupName = "3. Filters", Description = "Minutes to wait after a setup closes at its target. Default 15.")]
        public int CooldownWinMin { get; set; }

        [Range(0, 600)]
        [Display(Name = "Cooldown after a loss (min)", Order = 6, GroupName = "3. Filters", Description = "Minutes to wait after a setup closes at its stop. Default 45.")]
        public int CooldownLossMin { get; set; }

        [Display(Name = "Show panel", Order = 1, GroupName = "4. Display")]
        public bool ShowPanel { get; set; }

        [Display(Name = "Show 'you place the orders' line", Order = 20, GroupName = "4. Display", Description = "Adds a last line to the panel saying that you place the orders and this indicator trades nothing.")]
        public bool ShowManualReminder { get; set; }

        [Display(Name = "Panel corner", Order = 2, GroupName = "4. Display")]
        public IchimokuCorner PanelCorner { get; set; }

        [Range(8, 30)]
        [Display(Name = "Panel font size", Order = 3, GroupName = "4. Display")]
        public int PanelFontSize { get; set; }

        [Range(-3000, 3000)]
        [Display(Name = "Panel offset X (pixels)", Order = 5, GroupName = "4. Display", Description = "Moves the panel right (positive) or left (negative) from its corner.")]
        public int PanelOffsetX { get; set; }

        [Range(-3000, 3000)]
        [Display(Name = "Panel offset Y (pixels)", Order = 6, GroupName = "4. Display", Description = "Moves the panel down (positive) or up (negative) from its corner.")]
        public int PanelOffsetY { get; set; }

        [Display(Name = "Hide panel outside session", Order = 7, GroupName = "4. Display", Description = "Hides the panel while the clock is outside this preset's window and no setup or trade is being followed. Handy when several follow panels share one corner: only the one in session shows.")]
        public bool HideOutsideSession { get; set; }

        [Range(6, 40)]
        [Display(Name = "Setup label font size", Order = 3, GroupName = "4. Display", Description = "Size of the on-chart text: the LONG / SHORT limit label and the target and stop loss labels. Applies to new setups.")]
        public int LabelFontSize { get; set; }

        [Range(0, 200)]
        [Display(Name = "Label offset (bars)", Order = 8, GroupName = "4. Display", Description = "Moves the LONG / SHORT limit, target and stop loss labels this many bars to the right of the latest bar. 0 keeps them at the latest bar. The right margin of the chart must be wide enough to show them.")]
        public int LabelOffsetBars { get; set; }

        [Display(Name = "Fill cloud", Order = 4, GroupName = "4. Display", Description = "Shades the area between Senkou A and Senkou B. The two edge lines are plots you can style under Plots.")]
        public bool FillCloud { get; set; }

        [Range(0, 100000)]
        [Display(Name = "Risk per trade ($, 0 = off)", Order = 5, GroupName = "4. Display", Description = "Shows how many contracts that budget buys at this stop distance. Sizing stays your decision.")]
        public double RiskPerTradeUsd { get; set; }

        [Display(Name = "Enable alerts", Order = 1, GroupName = "5. Alerts", Description = "Master switch. Off means no alert of any kind.")]
        public bool EnableAlerts { get; set; }

        [Display(Name = "Setup armed sound", Order = 2, GroupName = "5. Alerts", Description = "Plays when a setup fires and the limit goes live. None raises no alert for this event.")]
        public IchimokuSound SetupSound { get; set; }

        [Display(Name = "Limit filled sound", Order = 3, GroupName = "5. Alerts", Description = "Plays when price reaches the limit. Silent by default.")]
        public IchimokuSound FillSound { get; set; }

        [Display(Name = "Limit expired sound", Order = 4, GroupName = "5. Alerts", Description = "Plays when the limit lapses unfilled and you should cancel. Silent by default.")]
        public IchimokuSound ExpirySound { get; set; }

        [Display(Name = "Custom sound file", Order = 5, GroupName = "5. Alerts", Description = "Used by any event set to Custom. A .wav name resolves against NinjaTrader 8/sounds; a full path is taken as given.")]
        public string CustomSoundFile { get; set; }

        [XmlIgnore] [Display(Name = "Long", Order = 1, GroupName = "6. Colors")]
        public Brush LongBrush { get; set; }
        [Browsable(false)]
        public string LongBrushSerialize { get { return Serialize.BrushToString(LongBrush); } set { LongBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Short", Order = 2, GroupName = "6. Colors")]
        public Brush ShortBrush { get; set; }
        [Browsable(false)]
        public string ShortBrushSerialize { get { return Serialize.BrushToString(ShortBrush); } set { ShortBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Stop", Order = 3, GroupName = "6. Colors")]
        public Brush StopBrush { get; set; }
        [Browsable(false)]
        public string StopBrushSerialize { get { return Serialize.BrushToString(StopBrush); } set { StopBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Target", Order = 4, GroupName = "6. Colors")]
        public Brush TargetBrush { get; set; }
        [Browsable(false)]
        public string TargetBrushSerialize { get { return Serialize.BrushToString(TargetBrush); } set { TargetBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Cloud fill", Order = 5, GroupName = "6. Colors")]
        public Brush CloudBrush { get; set; }
        [Browsable(false)]
        public string CloudBrushSerialize { get { return Serialize.BrushToString(CloudBrush); } set { CloudBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Panel text", Order = 6, GroupName = "6. Colors")]
        public Brush PanelText { get; set; }
        [Browsable(false)]
        public string PanelTextSerialize { get { return Serialize.BrushToString(PanelText); } set { PanelText = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Panel background", Order = 7, GroupName = "6. Colors")]
        public Brush PanelArea { get; set; }
        [Browsable(false)]
        public string PanelAreaSerialize { get { return Serialize.BrushToString(PanelArea); } set { PanelArea = Serialize.StringToBrush(value); } }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PhillyFranksTools.IchimokuFollow[] cacheIchimokuFollow;
		public PhillyFranksTools.IchimokuFollow IchimokuFollow(IchimokuPreset preset, bool showVisuals)
		{
			return IchimokuFollow(Input, preset, showVisuals);
		}

		public PhillyFranksTools.IchimokuFollow IchimokuFollow(ISeries<double> input, IchimokuPreset preset, bool showVisuals)
		{
			if (cacheIchimokuFollow != null)
				for (int idx = 0; idx < cacheIchimokuFollow.Length; idx++)
					if (cacheIchimokuFollow[idx] != null && cacheIchimokuFollow[idx].Preset == preset && cacheIchimokuFollow[idx].ShowVisuals == showVisuals && cacheIchimokuFollow[idx].EqualsInput(input))
						return cacheIchimokuFollow[idx];
			return CacheIndicator<PhillyFranksTools.IchimokuFollow>(new PhillyFranksTools.IchimokuFollow(){ Preset = preset, ShowVisuals = showVisuals }, input, ref cacheIchimokuFollow);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PhillyFranksTools.IchimokuFollow IchimokuFollow(IchimokuPreset preset, bool showVisuals)
		{
			return indicator.IchimokuFollow(Input, preset, showVisuals);
		}

		public Indicators.PhillyFranksTools.IchimokuFollow IchimokuFollow(ISeries<double> input , IchimokuPreset preset, bool showVisuals)
		{
			return indicator.IchimokuFollow(input, preset, showVisuals);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PhillyFranksTools.IchimokuFollow IchimokuFollow(IchimokuPreset preset, bool showVisuals)
		{
			return indicator.IchimokuFollow(Input, preset, showVisuals);
		}

		public Indicators.PhillyFranksTools.IchimokuFollow IchimokuFollow(ISeries<double> input , IchimokuPreset preset, bool showVisuals)
		{
			return indicator.IchimokuFollow(input, preset, showVisuals);
		}
	}
}

#endregion
