# Ichimoku Follow - manual signal indicator (NinjaTrader 8)

One file. It plots a 7/22/44 Ichimoku cloud, marks a Tenkan/Kijun cross that happens outside the
cloud, prices the entry, the stop and the target, and sounds an alert. **It places no orders. You do.**

There is no strategy in this download and nothing in it trades for you. That is on
purpose: most funding companies do not allow automated trading on an evaluation or funded
account, and an indicator you act on by hand is a different thing from a robot. Read your
own contract; the rule is theirs to change.

---

## Read this first

- **No edge was found.** We tested these exact rules over years of 1-minute NQ data, in all three
  sessions, on a long history and on a later period we kept back until the end. After costs the average
  trade was slightly negative in every session, and nothing came close to a reliable edge. This is a
  defined rule set you can watch work and judge for yourself, not a system that makes money.
- **No session is better than another.** The three sessions differ only in their hours, and the
  differences between them are inside the noise. Do not read the order they are listed in as a ranking.
- **It produces a lot of setups.** Roughly 2 to 6 per trading day depending on the session, so costs
  and the orders you miss matter a great deal.
- **The ATR gate is in absolute points.** The rule needs ATR(14) of at least 5 points. On older,
  lower-priced NQ data that was rarely true, so the evidence behind the statements above is mostly
  2019 onward.
- **Its history is simulated.** An automated version of these rules ran on a simulated account in the
  Eval Arena, which is now closed; the simulated results are on the website, they are not a track record,
  and that strategy is not distributed.
- **The simulated outcomes the indicator draws** (the diamonds, the open points) are a model of what the
  rules would have done, not a record of any trade anyone took. They count a touch of your limit as a fill;
  a broker may need price to trade through it, and in our tests that stricter rule was slightly worse.
- **You are responsible for every order you place**, and for the rules of the account you place it on.

---

## The setup, in plain English

1. **The cloud.** Tenkan is the midpoint of the highest high and lowest low of the last **7** bars,
   Kijun the same over **22**. Senkou A is their average and Senkou B is the same midpoint over **44**.
   Nothing is shifted forward: the cloud on your chart is the cloud the rule measures against.
2. **The cross.** Tenkan crosses above Kijun (long) or below it (short). The cross is tracked on every
   bar, around the clock; only the entry is limited to the session you choose.
3. **The cloud filter.** A long needs the bar to close **above** the top of the cloud, a short needs it
   **below** the bottom. A cross with price inside the cloud, or on the wrong side, is skipped, and the
   panel says so.
4. **The ATR gate.** ATR(14) must be at least 5 points.
5. **Entry.** A limit 25% of the trigger bar's range back inside that bar. **It is live for one bar only.**
6. **Bracket.** Stop = 1.5 x ATR(14), never tighter than 15 points and never wider than 40. Target = 2R.
7. **Clock.** Nothing new is priced from 15:30 ET, and a followed trade still open at 15:45 ET is closed
   in the simulation.

### Presets

| Preset | Window (ET) |
|---|---|
| Asian (default) | 20:00-01:30 |
| European | 03:00-08:00 |
| US | 09:30-15:30 |
| Custom | yours, with your own periods, ATR gate and bracket |

The three presets share every rule except the hours. A window is not a cosmetic setting: the same rules
on different hours are a different test. A tuned Custom setup is your configuration, not a published one.

---

## What you need

| | |
|---|---|
| Platform | NinjaTrader 8 (8.1.x) |
| Instrument | NQ or MNQ. The stop floor and cap are written in NQ points |
| Chart | **1-minute**, ETH (24-hour) session template |
| Time zone | **US Eastern**: Tools > Options > General > Time zone. Every session hour here is Eastern |
| Warmup | 50 bars before the first signal |

On another instrument the 15-40 point stop clamp and the 5 point ATR gate are meaningless and you must
re-derive them.

---

## Install

1. Control Center > **Tools > Import > NinjaScript Add-On...** and pick `IchimokuFollow.zip`.
2. Restart NinjaTrader, or **Tools > New NinjaScript > Compile**.
3. Add **IchimokuFollow** to a 1-minute NQ chart (it is listed under PhillyFranksTools).

If the importer objects to the extra files in the archive, extract the zip by hand and
copy `Indicators\IchimokuFollow.cs` into `Documents\NinjaTrader 8\bin\Custom\Indicators\`, then compile.

---

## Trading it by hand

The cloud edges, Tenkan and Kijun are plotted, the cloud is shaded, and the panel tells you the state:

```
ICHIMOKU - MANUAL FOLLOW
Asian (20:00-01:30 ET)
Clock 21:14   window 20:00-01:30
Tenkan 24288.50   Kijun 24291.25   TK bearish
Cloud 24270.00 - 24299.50   price INSIDE
ATR(14) 6.25   gate 5
------------------------------------------
WATCHING - needs a TK cross with price outside the cloud
Last: TK CROSS SKIPPED - price not outside the cloud
------------------------------------------
Setups filled today 0 / 99    target 0  stop loss 0
YOU place the orders. Nothing here trades.
```

When a setup fires you get an arrow, a sound and a dashed line at the limit price, and the panel
switches to the numbers you place:

```
WORKING LIMIT - LONG
Valid for THIS BAR ONLY
Limit     24310.25
Stop loss 24292.00   (18.25 pts)
Target    24346.75   (36.5 pts)
Risk      $365 per contract
```

**The limit is live for one bar.** Place it as a limit order with a one-minute life, or cancel it at the
close of the next bar. Often a third or more of setups never come back to the limit and are simply
skipped. Not chasing the bar that triggered it is the design, not a missed trade.

| Marker | Meaning |
|---|---|
| Arrow up / down | Setup fired on this bar's close |
| Dashed line | The limit price, live for one bar |
| Grey dot | Limit expired unfilled: stand down |
| Solid red / green lines | Stop and target once filled |
| Diamond | Simulated bracket resolved (green target, red stop, gold session flat) |

### Sounds

Three moments can have a sound, picked from the sounds NinjaTrader ships with (or `Custom`, which plays
the file named in **Custom sound file**). `None` raises no alert for that event at all.
**Enable alerts** is the master switch.

| Event | Default |
|---|---|
| Setup armed | `Alert1` |
| Limit filled | `None` |
| Limit expired | `None` |

### Deliberately pessimistic tracking

- On the bar the limit fills, **only the stop is checked**.
- After that, a bar that touches both stop and target is recorded as a **stop**.
- A gap through your limit fills at the open, in your favour.

---

## Settings

| Group | What is in it |
|---|---|
| 1. Setup | Preset, Show visuals |
| 2. Custom rules | Used only with the Custom preset: the three periods, require the cloud colour to agree, ATR gate, stop and target points, session start and end, Fixed bracket |
| 3. Filters | Max setups per session (default 99), avoid lunch chop (12:00-13:00), your own news blackout windows, and the optional cooldown (**off** by default, so the rules are the tested ones) |
| 4. Display | Panel on/off, corner, size and offsets, label size, fill cloud, risk per trade (shows how many contracts that budget buys; sizing stays your decision), hide the panel outside the session, and "Show 'you place the orders' line" |
| 5. Alerts | Master switch, the three sounds, custom sound file |
| 6. Colors | Long, short, stop, target, cloud fill, panel text and background. The Tenkan, Kijun and cloud-edge lines are plots you can style under Plots |

---

## Things you should know

- **Everything evaluates on bar close.** If you change `Calculate`, the indicator forces it back to
  `OnBarClose`, because an intrabar version would show setups that vanish.
- **The news blackout is empty and manual.** Nothing is downloaded or guessed.
- **If the cloud shading misbehaves,** untick **Fill cloud**; the edge lines stay.
- **Entry, Stop and Target are also plots.** While a setup is pending or open they carry the limit (then
  the fill) price, the stop and the target, so you can read them in the Data Box or pick them as an input
  series for another indicator or an alert. Between setups they are empty. Style them under Plots.
- **Label offset (bars)** under 4. Display moves the limit, target and stop loss labels to the right of the
  latest bar so they do not sit on the candles (default 6, 0 keeps them at the latest bar). The right margin
  of the chart has to be wide enough to show them.
- **Failures print to the NinjaScript Output window** (Control Center > New > NinjaScript Output).
  Look there first.

### Optional call log (off by default)

If you create a text file named `NQBotFollowerCallLog.txt` in `Documents\NinjaTrader 8` and put a folder
path on its first line, the indicator appends one JSON line per call (setup, fill, exit, alert) to
`IchimokuFollow_calls_<day>.jsonl` in that folder, in realtime only. Without the file nothing is
written. The indicator makes no network calls.

---

## Files

```
Indicators/IchimokuFollow.cs   the signal engine and the manual display
LICENSE                        MIT
Info.xml                       NinjaTrader import descriptor
```

---

## Risk, licence, and what this is not

MIT licence. See `LICENSE`. Use it, change it, share it. If you modify it to place orders
automatically, that is your choice and your risk, and it may breach your funding agreement.

**These are trade signals.** The indicator tells you a direction, an entry price, a stop and a target.
Treat that with the seriousness it deserves, even though it sends no order.

**Nothing here is financial advice.** The author is not a registered investment adviser, commodity
trading advisor or broker, and nothing in this package is a recommendation to buy or sell anything or a
solicitation to trade. It is published for education and research. Trading futures carries a substantial
risk of loss, is not suitable for every investor, and you can lose more than you deposit. Simulated
performance especially does not indicate future results.

**Test it in simulation first, for long enough to watch it lose**, and never trade money you cannot
afford to lose.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND. See `LICENSE`.
