#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
using System.IO;
using System.IO.Compression;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.PhillyFranksTools
{
    /// <summary>
    /// WorldClock - Advanced World Trading Sessions Indicator
    ///
    /// CALENDAR DATA DOCUMENTATION:
    /// ============================
    /// This indicator uses an internal market calendar engine with embedded schedule data
    /// covering 2026-2030 for all supported exchanges.
    ///
    /// DATA STORAGE:
    /// - All schedule data is embedded in the MarketCalendarEngine class
    /// - Holiday definitions are stored in the InitializeHolidayData() method
    /// - Each market has its own holiday schedule stored in the marketHolidays dictionary
    ///
    /// HOW TO UPDATE ANNUALLY:
    /// 1. Add new year's holidays to InitializeHolidayData() in MarketCalendarEngine
    /// 2. Update DATA_END_DATE constant to reflect the new coverage
    /// 3. Recompile in NinjaTrader
    ///
    /// Key markets require special attention:
    /// - NYSE/CME: Update usMarketHolidays and cmeSpecialSessions dictionaries
    /// - International: Update respective market holiday lists
    ///
    /// HOW TO RUN THE TEST HARNESS:
    /// 1. Set EnableDebugOutput = true in the code
    /// 2. Set RunTestsOnStartup = true in the code
    /// 3. Add the indicator to a chart
    /// 4. Check the NinjaTrader Output window (Ctrl+O) for test results
    ///
    /// TEST VECTORS:
    /// The test harness includes 25+ named test cases covering:
    /// - New Year's Day and Eve behavior (CME evening reopen pattern)
    /// - Good Friday (multiple years)
    /// - Day after Thanksgiving early closes
    /// - Christmas Eve early closes
    /// - DST boundary weeks (US and non-US)
    /// - Non-US exchange validations
    /// </summary>
    public class WorldClock : Indicator
    {
        #region Calendar Engine Constants
        private static readonly DateTime DATA_START_DATE = new DateTime(2026, 1, 1);
        private static readonly DateTime DATA_END_DATE = new DateTime(2030, 12, 31);

        // Set these to true to enable debugging/testing
        private static readonly bool EnableDebugOutput = false;
        private static readonly bool RunTestsOnStartup = false;
        #endregion

        private DateTime lastUpdate = DateTime.MinValue;
        private readonly TimeSpan updateInterval = TimeSpan.FromSeconds(1);
        private SharpDX.DirectWrite.TextFormat textFormat;
        private SharpDX.DirectWrite.TextFormat headerFormat;
        private SharpDX.Direct2D1.SolidColorBrush textBrush;
        private SharpDX.Direct2D1.SolidColorBrush liveBrush;
        private SharpDX.Direct2D1.SolidColorBrush closedBrush;
        private SharpDX.Direct2D1.SolidColorBrush backgroundBrush;
        private SharpDX.Direct2D1.SolidColorBrush borderBrush;
        private SharpDX.Direct2D1.SolidColorBrush alertBrush;
        private SharpDX.Direct2D1.SolidColorBrush openingSoonBrush;

        private MarketCalendarEngine calendarEngine;

        private readonly Dictionary<string, TradingCenter> tradingCenters = new Dictionary<string, TradingCenter>
        {
            {"Local", new TradingCenter("Local", TimeZoneInfo.Local, MarketId.Local)},
            {"New York", new TradingCenter("New York", TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"), MarketId.NYSE)},
            {"CME Globex", new TradingCenter("CME Globex", TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time"), MarketId.CME)},
            {"Toronto", new TradingCenter("Toronto", TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"), MarketId.TSX)},
            {"London", new TradingCenter("London", TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time"), MarketId.LSE)},
            {"Frankfurt", new TradingCenter("Frankfurt", TimeZoneInfo.FindSystemTimeZoneById("W. Europe Standard Time"), MarketId.Xetra)},
            {"Paris", new TradingCenter("Paris", TimeZoneInfo.FindSystemTimeZoneById("W. Europe Standard Time"), MarketId.Euronext)},
            {"Zurich", new TradingCenter("Zurich", TimeZoneInfo.FindSystemTimeZoneById("W. Europe Standard Time"), MarketId.SIX)},
            {"Moscow", new TradingCenter("Moscow", TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time"), MarketId.MOEX)},
            {"Dubai", new TradingCenter("Dubai", TimeZoneInfo.FindSystemTimeZoneById("Arabian Standard Time"), MarketId.DFM)},
            {"Mumbai", new TradingCenter("Mumbai", TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"), MarketId.NSE)},
            {"Shanghai", new TradingCenter("Shanghai", TimeZoneInfo.FindSystemTimeZoneById("China Standard Time"), MarketId.SSE)},
            {"Tokyo", new TradingCenter("Tokyo", TimeZoneInfo.FindSystemTimeZoneById("Tokyo Standard Time"), MarketId.JPX)},
            {"Hong Kong", new TradingCenter("Hong Kong", TimeZoneInfo.FindSystemTimeZoneById("China Standard Time"), MarketId.HKEX)},
            {"Singapore", new TradingCenter("Singapore", TimeZoneInfo.FindSystemTimeZoneById("Singapore Standard Time"), MarketId.SGX)},
            {"Sydney", new TradingCenter("Sydney", TimeZoneInfo.FindSystemTimeZoneById("AUS Eastern Standard Time"), MarketId.ASX)},
            {"Wellington", new TradingCenter("Wellington", TimeZoneInfo.FindSystemTimeZoneById("New Zealand Standard Time"), MarketId.NZX)},
            {"Riyadh", new TradingCenter("Riyadh", TimeZoneInfo.FindSystemTimeZoneById("Arab Standard Time"), MarketId.Tadawul)},
            {"Johannesburg", new TradingCenter("Johannesburg", TimeZoneInfo.FindSystemTimeZoneById("South Africa Standard Time"), MarketId.JSE)},
            {"Sao Paulo", new TradingCenter("Sao Paulo", TimeZoneInfo.FindSystemTimeZoneById("E. South America Standard Time"), MarketId.B3)}
        };

        private readonly Dictionary<string, string> tradingHours = new Dictionary<string, string>
        {
            {"ES (S&P)", "17:00-16:00 (Sun-Fri)"},
            {"NQ (Nasdaq)", "17:00-16:00 (Sun-Fri)"},
            {"YM (Dow)", "17:00-16:00 (Sun-Fri)"},
            {"RTY (Russell)", "17:00-16:00 (Sun-Fri)"},
            {"GC (Gold)", "17:00-16:00 (Sun-Fri)"},
            {"CL (Crude)", "17:00-16:00 (Sun-Fri)"}
        };

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Advanced World Clock with Live Trading Sessions";
                Name = "World Clock";
                Calculate = Calculate.OnEachTick;
                IsOverlay = true;
                DisplayInDataBox = false;
                DrawOnPricePanel = false;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = false;
                ScaleJustification = ScaleJustification.Right;
                IsSuspendedWhileInactive = false;
                ZOrder = int.MaxValue;

                ShowLocal = false;
                ShowNewYork = true;
                ShowCMEGlobex = true;
                ShowToronto = false;
                ShowLondon = true;
                ShowFrankfurt = true;
                ShowParis = false;
                ShowZurich = false;
                ShowMoscow = false;
                ShowDubai = false;
                ShowMumbai = false;
                ShowShanghai = false;
                ShowTokyo = true;
                ShowHongKong = true;
                ShowSingapore = false;
                ShowSydney = true;
                ShowWellington = false;
                ShowRiyadh = false;
                ShowJohannesburg = false;
                ShowSaoPaulo = false;

                ShowTradingHours = false;
                ShowHolidayChecker = true;
                FontSize = 11;
                TextColor = Brushes.White;
                LiveColor = Brushes.LimeGreen;
                ClosedColor = Brushes.Orange;
                AlertColor = Brushes.Red;
                OpeningSoonColor = Brushes.Yellow;
                BackgroundColor = Brushes.DarkBlue;
                BackgroundOpacity = 100;
                HorizontalOffset = 10;
                VerticalOffset = 10;
            }
            else if (State == State.Configure)
            {
                calendarEngine = new MarketCalendarEngine(EnableDebugOutput ? Print : (Action<string>)null);
            }
            else if (State == State.Active)
            {
                lastUpdate = DateTime.MinValue;

                if (RunTestsOnStartup && calendarEngine != null)
                {
                    RunTestHarness();
                }
            }
            else if (State == State.Terminated)
            {
                DisposeResources();
            }
        }

        private void DisposeResources()
        {
            if (textFormat != null) { textFormat.Dispose(); textFormat = null; }
            if (headerFormat != null) { headerFormat.Dispose(); headerFormat = null; }
            if (textBrush != null) { textBrush.Dispose(); textBrush = null; }
            if (liveBrush != null) { liveBrush.Dispose(); liveBrush = null; }
            if (closedBrush != null) { closedBrush.Dispose(); closedBrush = null; }
            if (backgroundBrush != null) { backgroundBrush.Dispose(); backgroundBrush = null; }
            if (borderBrush != null) { borderBrush.Dispose(); borderBrush = null; }
            if (alertBrush != null) { alertBrush.Dispose(); alertBrush = null; }
            if (openingSoonBrush != null) { openingSoonBrush.Dispose(); openingSoonBrush = null; }
        }

        protected override void OnBarUpdate()
        {
            if (DateTime.Now - lastUpdate < updateInterval) return;
            lastUpdate = DateTime.Now;
            ForceRefresh();
        }

        public override void OnRenderTargetChanged()
        {
            DisposeResources();

            if (RenderTarget != null)
            {
                try
                {
                    textFormat = new SharpDX.DirectWrite.TextFormat(Core.Globals.DirectWriteFactory, "Consolas", FontSize);
                    headerFormat = new SharpDX.DirectWrite.TextFormat(Core.Globals.DirectWriteFactory, "Consolas", FontSize + 1);

                    var textColor = ((System.Windows.Media.SolidColorBrush)TextColor).Color;
                    var liveColor = ((System.Windows.Media.SolidColorBrush)LiveColor).Color;
                    var closedColor = ((System.Windows.Media.SolidColorBrush)ClosedColor).Color;
                    var alertColor = ((System.Windows.Media.SolidColorBrush)AlertColor).Color;
                    var openingSoonColor = ((System.Windows.Media.SolidColorBrush)OpeningSoonColor).Color;
                    var bgColor = ((System.Windows.Media.SolidColorBrush)BackgroundColor).Color;

                    textBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget,
                        new SharpDX.Color4(textColor.R / 255f, textColor.G / 255f, textColor.B / 255f, 1f));
                    liveBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget,
                        new SharpDX.Color4(liveColor.R / 255f, liveColor.G / 255f, liveColor.B / 255f, 1f));
                    closedBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget,
                        new SharpDX.Color4(closedColor.R / 255f, closedColor.G / 255f, closedColor.B / 255f, 1f));
                    alertBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget,
                        new SharpDX.Color4(alertColor.R / 255f, alertColor.G / 255f, alertColor.B / 255f, 1f));
                    openingSoonBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget,
                        new SharpDX.Color4(openingSoonColor.R / 255f, openingSoonColor.G / 255f, openingSoonColor.B / 255f, 1f));
                    backgroundBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget,
                        new SharpDX.Color4(bgColor.R / 255f, bgColor.G / 255f, bgColor.B / 255f, BackgroundOpacity / 100f));
                    borderBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget,
                        new SharpDX.Color4(textColor.R / 255f, textColor.G / 255f, textColor.B / 255f, 1f));
                }
                catch (Exception ex)
                {
                    Print("Error creating render resources: " + ex.Message);
                }
            }
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            if (Bars == null || ChartPanel == null || RenderTarget == null) return;
            if (textFormat == null || textBrush == null || backgroundBrush == null) OnRenderTargetChanged();
            if (textFormat == null || textBrush == null || backgroundBrush == null) return;

            float x = HorizontalOffset;
            float y = VerticalOffset;
            float lineHeight = FontSize + 3;

            DateTime now = DateTime.UtcNow;
            List<DisplayLine> lines = new List<DisplayLine>();

            lines.Add(new DisplayLine("GLOBAL TRADING SESSIONS", textBrush, true));
            lines.Add(new DisplayLine("by PhillyFrank", openingSoonBrush, false));
            lines.Add(new DisplayLine("", textBrush, false));

            var visibleCities = GetVisibleCities();

            foreach (var cityName in visibleCities)
            {
                if (tradingCenters.TryGetValue(cityName, out TradingCenter center))
                {
                    var status = GetTradingStatus(center, now);
                    var brush = GetStatusBrush(status);
                    var displayText = FormatCityLine(center, status, now);
                    lines.Add(new DisplayLine(displayText, brush, false));
                }
            }

            if (ShowTradingHours)
            {
                lines.Add(new DisplayLine("", textBrush, false));
                lines.Add(new DisplayLine("CME FUTURES (Chicago Time)", textBrush, true));
                foreach (var session in tradingHours)
                {
                    lines.Add(new DisplayLine($"{session.Key,-12} {session.Value}", textBrush, false));
                }
            }

            if (ShowHolidayChecker)
            {
                var holidayInfo = GetUpcomingHolidayInfo(now);
                if (!string.IsNullOrEmpty(holidayInfo))
                {
                    lines.Add(new DisplayLine("", textBrush, false));
                    lines.Add(new DisplayLine(holidayInfo, textBrush, false));
                }
            }

            float maxWidth = CalculateMaxWidth(lines);
            float bgWidth = maxWidth + 20;
            float bgHeight = lines.Count * lineHeight + 10;

            RenderTarget.FillRectangle(new SharpDX.RectangleF(x - 5, y - 5, bgWidth, bgHeight), backgroundBrush);
            RenderTarget.DrawRectangle(new SharpDX.RectangleF(x - 5, y - 5, bgWidth, bgHeight), borderBrush, 1);

            for (int i = 0; i < lines.Count; i++)
            {
                var format = lines[i].IsHeader ? headerFormat : textFormat;
                RenderTarget.DrawText(lines[i].Text, format,
                    new SharpDX.RectangleF(x, y + i * lineHeight, bgWidth, lineHeight),
                    lines[i].Brush);
            }
        }

        private List<string> GetVisibleCities()
        {
            var cities = new List<string>();
            if (ShowLocal) cities.Add("Local");
            if (ShowCMEGlobex) cities.Add("CME Globex");

            if (ShowWellington) cities.Add("Wellington");
            if (ShowSydney) cities.Add("Sydney");
            if (ShowTokyo) cities.Add("Tokyo");
            if (ShowSingapore) cities.Add("Singapore");
            if (ShowShanghai) cities.Add("Shanghai");
            if (ShowHongKong) cities.Add("Hong Kong");
            if (ShowMumbai) cities.Add("Mumbai");
            if (ShowDubai) cities.Add("Dubai");
            if (ShowRiyadh) cities.Add("Riyadh");
            if (ShowJohannesburg) cities.Add("Johannesburg");
            if (ShowMoscow) cities.Add("Moscow");
            if (ShowLondon) cities.Add("London");
            if (ShowFrankfurt) cities.Add("Frankfurt");
            if (ShowParis) cities.Add("Paris");
            if (ShowZurich) cities.Add("Zurich");
            if (ShowSaoPaulo) cities.Add("Sao Paulo");
            if (ShowNewYork) cities.Add("New York");
            if (ShowToronto) cities.Add("Toronto");

            return cities;
        }

        private TradingStatus GetTradingStatus(TradingCenter center, DateTime utcNow)
        {
            try
            {
                DateTime localTime = TimeZoneInfo.ConvertTimeFromUtc(utcNow, center.TimeZone);

                if (center.MarketId == MarketId.Local)
                {
                    return new TradingStatus
                    {
                        IsOpen = false,
                        TimeToChange = TimeSpan.Zero,
                        CurrentTime = localTime,
                        IsLocalTime = true,
                        Why = "Local time display only"
                    };
                }

                var result = calendarEngine.GetStatus(center.MarketId, utcNow);

                return new TradingStatus
                {
                    IsOpen = result.IsOpenNow,
                    TimeToChange = result.TimeToTransition,
                    CurrentTime = localTime,
                    HolidayName = result.HolidayName,
                    IsEarlyClose = result.IsEarlyClose,
                    IsDailyBreak = result.IsDailyBreak,
                    EarlyCloseTime = result.EarlyCloseHour,
                    Why = result.Why
                };
            }
            catch (Exception ex)
            {
                return new TradingStatus
                {
                    IsOpen = false,
                    TimeToChange = TimeSpan.Zero,
                    Why = $"Error: {ex.Message}"
                };
            }
        }

        private string GetUpcomingHolidayInfo(DateTime utcNow)
        {
            try
            {
                var easternTz = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                DateTime today = TimeZoneInfo.ConvertTimeFromUtc(utcNow, easternTz).Date;

                // Check today and next 7 days
                for (int i = 0; i <= 7; i++)
                {
                    DateTime checkDate = today.AddDays(i);

                    // Check NYSE/CME for holidays
                    var nyseInfo = calendarEngine.GetHolidayInfo(MarketId.NYSE, checkDate);
                    var cmeInfo = calendarEngine.GetHolidayInfo(MarketId.CME, checkDate);

                    if (nyseInfo.IsHoliday)
                    {
                        string dayText = i == 0 ? "TODAY" : (i == 1 ? "TOMORROW" : checkDate.ToString("ddd MMM dd"));
                        return $"* {dayText}: {nyseInfo.HolidayName}";
                    }

                    if (cmeInfo.IsEarlyClose)
                    {
                        string dayText = i == 0 ? "TODAY" : (i == 1 ? "TOMORROW" : checkDate.ToString("ddd MMM dd"));
                        return $"* {dayText}: CME early close {cmeInfo.EarlyCloseHour}:00 CT";
                    }

                    if (nyseInfo.IsEarlyClose)
                    {
                        string dayText = i == 0 ? "TODAY" : (i == 1 ? "TOMORROW" : checkDate.ToString("ddd MMM dd"));
                        return $"* {dayText}: NYSE early close {nyseInfo.EarlyCloseHour}:00 ET";
                    }
                }

                return "";
            }
            catch
            {
                return "";
            }
        }

        private SharpDX.Direct2D1.SolidColorBrush GetStatusBrush(TradingStatus status)
        {
            if (status.IsLocalTime)
            {
                return liveBrush;
            }

            if (status.IsOpen)
            {
                if (status.TimeToChange.TotalMinutes < 30)
                    return alertBrush;
                return liveBrush;
            }
            else
            {
                if (status.TimeToChange.TotalMinutes < 30)
                    return openingSoonBrush;
                return closedBrush;
            }
        }

        private string FormatCityLine(TradingCenter center, TradingStatus status, DateTime now)
        {
            string timeStr = status.CurrentTime.ToString("HH:mm:ss");
            string statusText;

            if (status.IsLocalTime)
            {
                return $"{center.Name,-11} {timeStr}";
            }

            if (status.IsOpen)
            {
                string remaining = FormatTimeSpan(status.TimeToChange);
                if (status.IsEarlyClose)
                    statusText = $"LIVE (early close {status.EarlyCloseTime}:00 in {remaining})";
                else
                    statusText = $"LIVE ({remaining} left)";
            }
            else
            {
                string countdown = FormatTimeSpan(status.TimeToChange);
                if (!string.IsNullOrEmpty(status.HolidayName))
                    statusText = $"CLOSED ({status.HolidayName})";
                else if (status.IsEarlyClose)
                    statusText = $"CLOSED (early close at {status.EarlyCloseTime}:00)";
                else if (status.IsDailyBreak)
                    statusText = $"MAINTENANCE (opens in {countdown})";
                else
                    statusText = $"CLOSED (opens in {countdown})";
            }

            return $"{center.Name,-11} {timeStr} {statusText}";
        }

        private string FormatTimeSpan(TimeSpan ts)
        {
            if (ts.TotalDays >= 1)
                return $"{(int)ts.TotalDays}d {ts.Hours:D2}h";
            else if (ts.TotalHours >= 1)
                return $"{ts.Hours:D2}h {ts.Minutes:D2}m";
            else
                return $"{ts.Minutes:D2}m {ts.Seconds:D2}s";
        }

        private float CalculateMaxWidth(List<DisplayLine> lines)
        {
            float maxWidth = 0;
            foreach (var line in lines)
            {
                var layout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory,
                    line.Text, line.IsHeader ? headerFormat : textFormat, float.MaxValue, float.MaxValue);
                maxWidth = Math.Max(maxWidth, layout.Metrics.Width);
                layout.Dispose();
            }
            return maxWidth;
        }

        #region Test Harness
        /// <summary>
        /// Runs a comprehensive test suite to verify calendar logic.
        /// Check NinjaTrader Output window (Ctrl+O) for results.
        /// </summary>
        private void RunTestHarness()
        {
            Print("=== WorldClock Calendar Test Harness ===");
            Print($"Data coverage: {DATA_START_DATE:yyyy-MM-dd} to {DATA_END_DATE:yyyy-MM-dd}");
            Print("");

            int passed = 0;
            int failed = 0;

            var tests = GetTestCases();

            foreach (var test in tests)
            {
                bool success = RunSingleTest(test);
                if (success)
                    passed++;
                else
                    failed++;
            }

            Print("");
            Print($"=== RESULTS: {passed} PASSED, {failed} FAILED ===");
        }

        private bool RunSingleTest(TestCase test)
        {
            try
            {
                var result = calendarEngine.GetStatus(test.MarketId, test.UtcTime);

                bool isOpenMatch = result.IsOpenNow == test.ExpectedOpen;
                bool whyMatch = string.IsNullOrEmpty(test.ExpectedWhyContains) ||
                               result.Why.IndexOf(test.ExpectedWhyContains, StringComparison.OrdinalIgnoreCase) >= 0;

                bool pass = isOpenMatch && whyMatch;

                if (pass)
                {
                    Print($"[PASS] {test.Name}");
                }
                else
                {
                    Print($"[FAIL] {test.Name}");
                    Print($"       UTC: {test.UtcTime:yyyy-MM-dd HH:mm}");
                    Print($"       Expected Open={test.ExpectedOpen}, Got Open={result.IsOpenNow}");
                    Print($"       Why: {result.Why}");
                    if (!string.IsNullOrEmpty(test.ExpectedWhyContains))
                        Print($"       Expected Why to contain: '{test.ExpectedWhyContains}'");
                }

                return pass;
            }
            catch (Exception ex)
            {
                Print($"[FAIL] {test.Name} - Exception: {ex.Message}");
                return false;
            }
        }

        private List<TestCase> GetTestCases()
        {
            var tests = new List<TestCase>();

            // Helper to create UTC time from Central Time for CME tests
            var centralTz = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
            var easternTz = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");

            Func<int, int, int, int, int, TimeZoneInfo, DateTime> toUtc = (y, m, d, h, min, tz) =>
            {
                var local = new DateTime(y, m, d, h, min, 0);
                return TimeZoneInfo.ConvertTimeToUtc(local, tz);
            };

            // ==================== NEW YEAR'S DAY TESTS ====================

            // Test 1: NYSE closed on New Year's Day 2026 (Thursday Jan 1)
            tests.Add(new TestCase
            {
                Name = "NYSE_NewYearsDay_2026_Closed",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 1, 1, 12, 0, easternTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "New Year"
            });

            // Test 2: CME day session closed on New Year's Day 2026 at 10:00 CT
            tests.Add(new TestCase
            {
                Name = "CME_NewYearsDay_2026_DaySession_Closed",
                MarketId = MarketId.CME,
                UtcTime = toUtc(2026, 1, 1, 10, 0, centralTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "New Year"
            });

            // Test 3: CME evening session reopens on New Year's Day 2026 at 17:00 CT
            tests.Add(new TestCase
            {
                Name = "CME_NewYearsDay_2026_EveningReopen",
                MarketId = MarketId.CME,
                UtcTime = toUtc(2026, 1, 1, 17, 30, centralTz),
                ExpectedOpen = true,
                ExpectedWhyContains = "evening"
            });

            // Test 4: NYSE closed on New Year's Day 2027 (Friday Jan 1)
            tests.Add(new TestCase
            {
                Name = "NYSE_NewYearsDay_2027_Closed",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2027, 1, 1, 12, 0, easternTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "New Year"
            });

            // ==================== NEW YEAR'S EVE TESTS ====================

            // Test 5: NYSE early close on NYE 2026 (Thursday Dec 31, 2026)
            tests.Add(new TestCase
            {
                Name = "NYSE_NewYearsEve_2026_EarlyClose",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 12, 31, 12, 0, easternTz),
                ExpectedOpen = true,
                ExpectedWhyContains = ""
            });

            // Test 6: CME open normal session on NYE 2026 at 12:00 CT (NOT NYSE-style early close)
            tests.Add(new TestCase
            {
                Name = "CME_NewYearsEve_2026_NoNYSEEarlyClose",
                MarketId = MarketId.CME,
                UtcTime = toUtc(2026, 12, 31, 12, 0, centralTz),
                ExpectedOpen = true,
                ExpectedWhyContains = ""
            });

            // Test 7: CME early close on NYE 2026 at 12:15 CT
            tests.Add(new TestCase
            {
                Name = "CME_NewYearsEve_2026_EarlyCloseCheck",
                MarketId = MarketId.CME,
                UtcTime = toUtc(2026, 12, 31, 12, 0, centralTz),
                ExpectedOpen = true,
                ExpectedWhyContains = ""
            });

            // ==================== GOOD FRIDAY TESTS ====================

            // Test 8: NYSE closed on Good Friday 2026 (April 3)
            tests.Add(new TestCase
            {
                Name = "NYSE_GoodFriday_2026_Closed",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 4, 3, 12, 0, easternTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "Good Friday"
            });

            // Test 9: CME closed on Good Friday 2026
            tests.Add(new TestCase
            {
                Name = "CME_GoodFriday_2026_Closed",
                MarketId = MarketId.CME,
                UtcTime = toUtc(2026, 4, 3, 12, 0, centralTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "Good Friday"
            });

            // Test 10: NYSE closed on Good Friday 2028 (April 14)
            tests.Add(new TestCase
            {
                Name = "NYSE_GoodFriday_2028_Closed",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2028, 4, 14, 12, 0, easternTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "Good Friday"
            });

            // ==================== THANKSGIVING TESTS ====================

            // Test 11: NYSE closed on Thanksgiving 2026 (Nov 26)
            tests.Add(new TestCase
            {
                Name = "NYSE_Thanksgiving_2026_Closed",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 11, 26, 12, 0, easternTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "Thanksgiving"
            });

            // Test 12: NYSE early close day after Thanksgiving 2026 (Nov 27)
            tests.Add(new TestCase
            {
                Name = "NYSE_DayAfterThanksgiving_2026_Open",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 11, 27, 10, 0, easternTz),
                ExpectedOpen = true,
                ExpectedWhyContains = ""
            });

            // Test 13: NYSE closed after early close on day after Thanksgiving 2026
            tests.Add(new TestCase
            {
                Name = "NYSE_DayAfterThanksgiving_2026_EarlyCloseDone",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 11, 27, 14, 0, easternTz),
                ExpectedOpen = false,
                ExpectedWhyContains = ""
            });

            // Test 14: CME early close day after Thanksgiving 2028 (Nov 24)
            tests.Add(new TestCase
            {
                Name = "CME_DayAfterThanksgiving_2028_OpenMorning",
                MarketId = MarketId.CME,
                UtcTime = toUtc(2028, 11, 24, 10, 0, centralTz),
                ExpectedOpen = true,
                ExpectedWhyContains = ""
            });

            // ==================== CHRISTMAS TESTS ====================

            // Test 15: NYSE closed on Christmas 2026 (Friday Dec 25)
            tests.Add(new TestCase
            {
                Name = "NYSE_Christmas_2026_Closed",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 12, 25, 12, 0, easternTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "Christmas"
            });

            // Test 16: NYSE early close on Christmas Eve 2026 (Thursday Dec 24)
            tests.Add(new TestCase
            {
                Name = "NYSE_ChristmasEve_2026_OpenMorning",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 12, 24, 10, 0, easternTz),
                ExpectedOpen = true,
                ExpectedWhyContains = ""
            });

            // Test 17: NYSE closed after early close on Christmas Eve 2026
            tests.Add(new TestCase
            {
                Name = "NYSE_ChristmasEve_2026_ClosedAfternoon",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 12, 24, 14, 0, easternTz),
                ExpectedOpen = false,
                ExpectedWhyContains = ""
            });

            // ==================== DST BOUNDARY TESTS ====================

            // Test 18: NYSE during US DST spring forward week 2026 (March 8 is DST change)
            tests.Add(new TestCase
            {
                Name = "NYSE_DST_SpringForward_2026",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 3, 9, 10, 0, easternTz),
                ExpectedOpen = true,
                ExpectedWhyContains = ""
            });

            // Test 19: LSE during UK DST change week 2026 (March 29 is UK clock change)
            var londonTz = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            tests.Add(new TestCase
            {
                Name = "LSE_DST_UK_SpringForward_2026",
                MarketId = MarketId.LSE,
                UtcTime = toUtc(2026, 3, 30, 10, 0, londonTz),
                ExpectedOpen = true,
                ExpectedWhyContains = ""
            });

            // Test 20: NYSE during US DST fall back week 2026 (Nov 1)
            tests.Add(new TestCase
            {
                Name = "NYSE_DST_FallBack_2026",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 11, 2, 10, 0, easternTz),
                ExpectedOpen = true,
                ExpectedWhyContains = ""
            });

            // ==================== NON-US EXCHANGE TESTS ====================

            // Test 21: Tokyo closed on Japanese New Year 2027 (Jan 1-3 typically)
            var tokyoTz = TimeZoneInfo.FindSystemTimeZoneById("Tokyo Standard Time");
            tests.Add(new TestCase
            {
                Name = "Tokyo_NewYear_2027_Closed",
                MarketId = MarketId.JPX,
                UtcTime = toUtc(2027, 1, 2, 10, 0, tokyoTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "New Year"
            });

            // Test 22: LSE closed on UK Christmas 2026
            tests.Add(new TestCase
            {
                Name = "LSE_Christmas_2026_Closed",
                MarketId = MarketId.LSE,
                UtcTime = toUtc(2026, 12, 25, 12, 0, londonTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "Christmas"
            });

            // Test 23: Hong Kong during normal trading hours
            var hkTz = TimeZoneInfo.FindSystemTimeZoneById("China Standard Time");
            tests.Add(new TestCase
            {
                Name = "HKEX_NormalTradingHours_2026",
                MarketId = MarketId.HKEX,
                UtcTime = toUtc(2026, 6, 15, 10, 0, hkTz),
                ExpectedOpen = true,
                ExpectedWhyContains = ""
            });

            // ==================== WEEKEND TESTS ====================

            // Test 24: NYSE closed on Saturday
            tests.Add(new TestCase
            {
                Name = "NYSE_Weekend_Saturday_Closed",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 6, 6, 12, 0, easternTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "Weekend"
            });

            // Test 25: CME closed on Saturday (before Sunday 17:00 open)
            tests.Add(new TestCase
            {
                Name = "CME_Weekend_Saturday_Closed",
                MarketId = MarketId.CME,
                UtcTime = toUtc(2026, 6, 6, 12, 0, centralTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "Weekend"
            });

            // ==================== FAILSAFE TESTS ====================

            // Test 26: Check out of range date fails closed
            tests.Add(new TestCase
            {
                Name = "OutOfRange_2035_FailsClosed",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2035, 1, 15, 12, 0, easternTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "Missing calendar data"
            });

            // Test 27: Moscow conservative fallback - fail closed if uncertain
            var moscowTz = TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time");
            tests.Add(new TestCase
            {
                Name = "Moscow_ConservativeFallback_2026",
                MarketId = MarketId.MOEX,
                UtcTime = toUtc(2026, 5, 9, 12, 0, moscowTz), // Victory Day
                ExpectedOpen = false,
                ExpectedWhyContains = ""
            });

            // Test 28: CME Sunday evening open at 17:30 CT
            tests.Add(new TestCase
            {
                Name = "CME_SundayEveningOpen_2026",
                MarketId = MarketId.CME,
                UtcTime = toUtc(2026, 6, 7, 17, 30, centralTz), // Sunday
                ExpectedOpen = true,
                ExpectedWhyContains = ""
            });

            // Test 29: CME Friday close at 16:00 CT
            tests.Add(new TestCase
            {
                Name = "CME_FridayClose_2026",
                MarketId = MarketId.CME,
                UtcTime = toUtc(2026, 6, 5, 16, 30, centralTz), // Friday after close
                ExpectedOpen = false,
                ExpectedWhyContains = "Weekend"
            });

            // Test 30: Independence Day 2026 (Saturday, observed Friday July 3)
            tests.Add(new TestCase
            {
                Name = "NYSE_IndependenceDay_2026_ObservedFriday",
                MarketId = MarketId.NYSE,
                UtcTime = toUtc(2026, 7, 3, 12, 0, easternTz),
                ExpectedOpen = false,
                ExpectedWhyContains = "Independence"
            });

            return tests;
        }

        private class TestCase
        {
            public string Name { get; set; }
            public MarketId MarketId { get; set; }
            public DateTime UtcTime { get; set; }
            public bool ExpectedOpen { get; set; }
            public string ExpectedWhyContains { get; set; }
        }
        #endregion

        #region Calendar Engine
        private enum MarketId
        {
            Local,
            NYSE,
            CME,
            TSX,
            LSE,
            Xetra,
            Euronext,
            SIX,
            MOEX,
            DFM,
            NSE,
            SSE,
            JPX,
            HKEX,
            SGX,
            ASX,
            NZX,
            Tadawul,
            JSE,
            B3
        }

        private enum SessionType
        {
            Regular,
            PreMarket,
            AfterHours,
            Evening,
            Holiday,
            EarlyClose,
            Maintenance,
            Closed
        }

        private class SessionWindow
        {
            public TimeSpan StartLocal { get; set; }
            public TimeSpan EndLocal { get; set; }
            public SessionType Type { get; set; }
            public string Reason { get; set; }

            public SessionWindow(int startHour, int startMin, int endHour, int endMin, SessionType type, string reason = "")
            {
                StartLocal = new TimeSpan(startHour, startMin, 0);
                EndLocal = new TimeSpan(endHour, endMin, 0);
                Type = type;
                Reason = reason;
            }
        }

        private class MarketStatusResult
        {
            public bool IsOpenNow { get; set; }
            public DateTime NextTransitionUtc { get; set; }
            public TimeSpan TimeToTransition { get; set; }
            public SessionType ActiveSessionType { get; set; }
            public string Why { get; set; }
            public string HolidayName { get; set; }
            public bool IsEarlyClose { get; set; }
            public int EarlyCloseHour { get; set; }
            public bool IsDailyBreak { get; set; }
        }

        private class HolidayInfo
        {
            public bool IsHoliday { get; set; }
            public bool IsEarlyClose { get; set; }
            public string HolidayName { get; set; }
            public int EarlyCloseHour { get; set; }
            public List<SessionWindow> SpecialSessions { get; set; }
        }

        private class MarketCalendarEngine
        {
            private readonly Action<string> debugPrint;
            private readonly Dictionary<MarketId, TimeZoneInfo> marketTimeZones;
            private readonly Dictionary<MarketId, List<SessionWindow>> defaultSessions;
            private readonly Dictionary<MarketId, Dictionary<DateTime, HolidayInfo>> marketHolidays;

            public MarketCalendarEngine(Action<string> debugPrintAction)
            {
                debugPrint = debugPrintAction;
                marketTimeZones = InitializeTimeZones();
                defaultSessions = InitializeDefaultSessions();
                marketHolidays = InitializeHolidayData();
            }

            private Dictionary<MarketId, TimeZoneInfo> InitializeTimeZones()
            {
                return new Dictionary<MarketId, TimeZoneInfo>
                {
                    { MarketId.NYSE, TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time") },
                    { MarketId.CME, TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time") },
                    { MarketId.TSX, TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time") },
                    { MarketId.LSE, TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time") },
                    { MarketId.Xetra, TimeZoneInfo.FindSystemTimeZoneById("W. Europe Standard Time") },
                    { MarketId.Euronext, TimeZoneInfo.FindSystemTimeZoneById("W. Europe Standard Time") },
                    { MarketId.SIX, TimeZoneInfo.FindSystemTimeZoneById("W. Europe Standard Time") },
                    { MarketId.MOEX, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time") },
                    { MarketId.DFM, TimeZoneInfo.FindSystemTimeZoneById("Arabian Standard Time") },
                    { MarketId.NSE, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time") },
                    { MarketId.SSE, TimeZoneInfo.FindSystemTimeZoneById("China Standard Time") },
                    { MarketId.JPX, TimeZoneInfo.FindSystemTimeZoneById("Tokyo Standard Time") },
                    { MarketId.HKEX, TimeZoneInfo.FindSystemTimeZoneById("China Standard Time") },
                    { MarketId.SGX, TimeZoneInfo.FindSystemTimeZoneById("Singapore Standard Time") },
                    { MarketId.ASX, TimeZoneInfo.FindSystemTimeZoneById("AUS Eastern Standard Time") },
                    { MarketId.NZX, TimeZoneInfo.FindSystemTimeZoneById("New Zealand Standard Time") },
                    { MarketId.Tadawul, TimeZoneInfo.FindSystemTimeZoneById("Arab Standard Time") },
                    { MarketId.JSE, TimeZoneInfo.FindSystemTimeZoneById("South Africa Standard Time") },
                    { MarketId.B3, TimeZoneInfo.FindSystemTimeZoneById("E. South America Standard Time") }
                };
            }

            private Dictionary<MarketId, List<SessionWindow>> InitializeDefaultSessions()
            {
                var sessions = new Dictionary<MarketId, List<SessionWindow>>();

                // NYSE: 9:30 - 16:00 ET
                sessions[MarketId.NYSE] = new List<SessionWindow>
                {
                    new SessionWindow(9, 30, 16, 0, SessionType.Regular, "Regular trading hours")
                };

                // CME Globex: 17:00 - 16:00 next day (with 16:00-17:00 maintenance)
                // Modeled as evening session + day session
                sessions[MarketId.CME] = new List<SessionWindow>
                {
                    new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Evening session"),
                    new SessionWindow(0, 0, 16, 0, SessionType.Regular, "Day session")
                };

                // TSX: 9:30 - 16:00 ET
                sessions[MarketId.TSX] = new List<SessionWindow>
                {
                    new SessionWindow(9, 30, 16, 0, SessionType.Regular, "Regular trading hours")
                };

                // LSE: 8:00 - 16:30 UK time
                sessions[MarketId.LSE] = new List<SessionWindow>
                {
                    new SessionWindow(8, 0, 16, 30, SessionType.Regular, "Regular trading hours")
                };

                // Xetra: 9:00 - 17:30 CET
                sessions[MarketId.Xetra] = new List<SessionWindow>
                {
                    new SessionWindow(9, 0, 17, 30, SessionType.Regular, "Regular trading hours")
                };

                // Euronext Paris: 9:00 - 17:30 CET
                sessions[MarketId.Euronext] = new List<SessionWindow>
                {
                    new SessionWindow(9, 0, 17, 30, SessionType.Regular, "Regular trading hours")
                };

                // SIX Swiss: 9:00 - 17:30 CET
                sessions[MarketId.SIX] = new List<SessionWindow>
                {
                    new SessionWindow(9, 0, 17, 30, SessionType.Regular, "Regular trading hours")
                };

                // MOEX: 10:00 - 18:45 Moscow time
                sessions[MarketId.MOEX] = new List<SessionWindow>
                {
                    new SessionWindow(10, 0, 18, 45, SessionType.Regular, "Regular trading hours")
                };

                // DFM: 10:00 - 14:00 Gulf Standard Time
                sessions[MarketId.DFM] = new List<SessionWindow>
                {
                    new SessionWindow(10, 0, 14, 0, SessionType.Regular, "Regular trading hours")
                };

                // NSE India: 9:15 - 15:30 IST
                sessions[MarketId.NSE] = new List<SessionWindow>
                {
                    new SessionWindow(9, 15, 15, 30, SessionType.Regular, "Regular trading hours")
                };

                // SSE: 9:30 - 15:00 CST (with 11:30-13:00 lunch break)
                sessions[MarketId.SSE] = new List<SessionWindow>
                {
                    new SessionWindow(9, 30, 11, 30, SessionType.Regular, "Morning session"),
                    new SessionWindow(13, 0, 15, 0, SessionType.Regular, "Afternoon session")
                };

                // JPX/TSE: 9:00 - 15:00 JST (with 11:30-12:30 lunch break)
                sessions[MarketId.JPX] = new List<SessionWindow>
                {
                    new SessionWindow(9, 0, 11, 30, SessionType.Regular, "Morning session"),
                    new SessionWindow(12, 30, 15, 0, SessionType.Regular, "Afternoon session")
                };

                // HKEX: 9:30 - 16:00 HKT (with 12:00-13:00 lunch break)
                sessions[MarketId.HKEX] = new List<SessionWindow>
                {
                    new SessionWindow(9, 30, 12, 0, SessionType.Regular, "Morning session"),
                    new SessionWindow(13, 0, 16, 0, SessionType.Regular, "Afternoon session")
                };

                // SGX: 9:00 - 17:00 SGT
                sessions[MarketId.SGX] = new List<SessionWindow>
                {
                    new SessionWindow(9, 0, 17, 0, SessionType.Regular, "Regular trading hours")
                };

                // ASX: 10:00 - 16:00 AEST
                sessions[MarketId.ASX] = new List<SessionWindow>
                {
                    new SessionWindow(10, 0, 16, 0, SessionType.Regular, "Regular trading hours")
                };

                // NZX: 10:00 - 16:45 NZST
                sessions[MarketId.NZX] = new List<SessionWindow>
                {
                    new SessionWindow(10, 0, 16, 45, SessionType.Regular, "Regular trading hours")
                };

                // Tadawul: 10:00 - 15:00 AST (Sunday-Thursday)
                sessions[MarketId.Tadawul] = new List<SessionWindow>
                {
                    new SessionWindow(10, 0, 15, 0, SessionType.Regular, "Regular trading hours")
                };

                // JSE: 9:00 - 17:00 SAST
                sessions[MarketId.JSE] = new List<SessionWindow>
                {
                    new SessionWindow(9, 0, 17, 0, SessionType.Regular, "Regular trading hours")
                };

                // B3: 10:00 - 17:00 BRT
                sessions[MarketId.B3] = new List<SessionWindow>
                {
                    new SessionWindow(10, 0, 17, 0, SessionType.Regular, "Regular trading hours")
                };

                return sessions;
            }

            private Dictionary<MarketId, Dictionary<DateTime, HolidayInfo>> InitializeHolidayData()
            {
                var holidays = new Dictionary<MarketId, Dictionary<DateTime, HolidayInfo>>();

                // Initialize empty dictionaries for all markets
                foreach (MarketId market in Enum.GetValues(typeof(MarketId)))
                {
                    if (market != MarketId.Local)
                        holidays[market] = new Dictionary<DateTime, HolidayInfo>();
                }

                // ===================== NYSE/NASDAQ HOLIDAYS 2026-2030 =====================
                AddUSMarketHolidays(holidays);

                // ===================== CME GLOBEX HOLIDAYS 2026-2030 =====================
                AddCMEHolidays(holidays);

                // ===================== TSX HOLIDAYS 2026-2030 =====================
                AddTSXHolidays(holidays);

                // ===================== LSE HOLIDAYS 2026-2030 =====================
                AddLSEHolidays(holidays);

                // ===================== EUROPEAN EXCHANGES 2026-2030 =====================
                AddEuropeanHolidays(holidays);

                // ===================== ASIAN EXCHANGES 2026-2030 =====================
                AddAsianHolidays(holidays);

                // ===================== OTHER EXCHANGES 2026-2030 =====================
                AddOtherHolidays(holidays);

                return holidays;
            }

            private void AddUSMarketHolidays(Dictionary<MarketId, Dictionary<DateTime, HolidayInfo>> holidays)
            {
                var nyseHolidays = holidays[MarketId.NYSE];

                // 2026
                nyseHolidays[new DateTime(2026, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                nyseHolidays[new DateTime(2026, 1, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Martin Luther King Jr. Day" };
                nyseHolidays[new DateTime(2026, 2, 16)] = new HolidayInfo { IsHoliday = true, HolidayName = "Presidents Day" };
                nyseHolidays[new DateTime(2026, 4, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                nyseHolidays[new DateTime(2026, 5, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Memorial Day" };
                nyseHolidays[new DateTime(2026, 6, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Juneteenth" };
                nyseHolidays[new DateTime(2026, 7, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day (Observed)" }; // July 4 is Saturday
                nyseHolidays[new DateTime(2026, 9, 7)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labor Day" };
                nyseHolidays[new DateTime(2026, 11, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                nyseHolidays[new DateTime(2026, 11, 27)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 13, HolidayName = "Day after Thanksgiving" };
                nyseHolidays[new DateTime(2026, 12, 24)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 13, HolidayName = "Christmas Eve" };
                nyseHolidays[new DateTime(2026, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };

                // 2027
                nyseHolidays[new DateTime(2027, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                nyseHolidays[new DateTime(2027, 1, 18)] = new HolidayInfo { IsHoliday = true, HolidayName = "Martin Luther King Jr. Day" };
                nyseHolidays[new DateTime(2027, 2, 15)] = new HolidayInfo { IsHoliday = true, HolidayName = "Presidents Day" };
                nyseHolidays[new DateTime(2027, 3, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                nyseHolidays[new DateTime(2027, 5, 31)] = new HolidayInfo { IsHoliday = true, HolidayName = "Memorial Day" };
                nyseHolidays[new DateTime(2027, 6, 18)] = new HolidayInfo { IsHoliday = true, HolidayName = "Juneteenth (Observed)" }; // 19th is Saturday
                nyseHolidays[new DateTime(2027, 7, 5)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day (Observed)" }; // 4th is Sunday
                nyseHolidays[new DateTime(2027, 9, 6)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labor Day" };
                nyseHolidays[new DateTime(2027, 11, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                nyseHolidays[new DateTime(2027, 11, 26)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 13, HolidayName = "Day after Thanksgiving" };
                nyseHolidays[new DateTime(2027, 12, 24)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day (Observed)" }; // 25th is Saturday

                // 2028
                nyseHolidays[new DateTime(2027, 12, 31)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day (Observed)" }; // Jan 1 2028 is Saturday
                nyseHolidays[new DateTime(2028, 1, 17)] = new HolidayInfo { IsHoliday = true, HolidayName = "Martin Luther King Jr. Day" };
                nyseHolidays[new DateTime(2028, 2, 21)] = new HolidayInfo { IsHoliday = true, HolidayName = "Presidents Day" };
                nyseHolidays[new DateTime(2028, 4, 14)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                nyseHolidays[new DateTime(2028, 5, 29)] = new HolidayInfo { IsHoliday = true, HolidayName = "Memorial Day" };
                nyseHolidays[new DateTime(2028, 6, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Juneteenth" };
                nyseHolidays[new DateTime(2028, 7, 4)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day" };
                nyseHolidays[new DateTime(2028, 9, 4)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labor Day" };
                nyseHolidays[new DateTime(2028, 11, 23)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                nyseHolidays[new DateTime(2028, 11, 24)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 13, HolidayName = "Day after Thanksgiving" };
                nyseHolidays[new DateTime(2028, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };

                // 2029
                nyseHolidays[new DateTime(2029, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                nyseHolidays[new DateTime(2029, 1, 15)] = new HolidayInfo { IsHoliday = true, HolidayName = "Martin Luther King Jr. Day" };
                nyseHolidays[new DateTime(2029, 2, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Presidents Day" };
                nyseHolidays[new DateTime(2029, 3, 30)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                nyseHolidays[new DateTime(2029, 5, 28)] = new HolidayInfo { IsHoliday = true, HolidayName = "Memorial Day" };
                nyseHolidays[new DateTime(2029, 6, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Juneteenth" };
                nyseHolidays[new DateTime(2029, 7, 4)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day" };
                nyseHolidays[new DateTime(2029, 9, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labor Day" };
                nyseHolidays[new DateTime(2029, 11, 22)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                nyseHolidays[new DateTime(2029, 11, 23)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 13, HolidayName = "Day after Thanksgiving" };
                nyseHolidays[new DateTime(2029, 12, 24)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 13, HolidayName = "Christmas Eve" };
                nyseHolidays[new DateTime(2029, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };

                // 2030
                nyseHolidays[new DateTime(2030, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                nyseHolidays[new DateTime(2030, 1, 21)] = new HolidayInfo { IsHoliday = true, HolidayName = "Martin Luther King Jr. Day" };
                nyseHolidays[new DateTime(2030, 2, 18)] = new HolidayInfo { IsHoliday = true, HolidayName = "Presidents Day" };
                nyseHolidays[new DateTime(2030, 4, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                nyseHolidays[new DateTime(2030, 5, 27)] = new HolidayInfo { IsHoliday = true, HolidayName = "Memorial Day" };
                nyseHolidays[new DateTime(2030, 6, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Juneteenth" };
                nyseHolidays[new DateTime(2030, 7, 4)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day" };
                nyseHolidays[new DateTime(2030, 9, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labor Day" };
                nyseHolidays[new DateTime(2030, 11, 28)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                nyseHolidays[new DateTime(2030, 11, 29)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 13, HolidayName = "Day after Thanksgiving" };
                nyseHolidays[new DateTime(2030, 12, 24)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 13, HolidayName = "Christmas Eve" };
                nyseHolidays[new DateTime(2030, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
            }

            private void AddCMEHolidays(Dictionary<MarketId, Dictionary<DateTime, HolidayInfo>> holidays)
            {
                var cmeHolidays = holidays[MarketId.CME];

                // CME has different patterns than NYSE:
                // - Some holidays close entirely
                // - Some holidays: day session closed, evening session reopens at 17:00 CT
                // - Early closes at 12:00 or 12:15 CT typically (we use 12 for simplicity)

                // 2026
                // New Year's Day: Day session closed, evening reopens at 17:00 CT
                cmeHolidays[new DateTime(2026, 1, 1)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "New Year's Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "New Year's Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2026, 1, 19)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Martin Luther King Jr. Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "MLK Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2026, 2, 16)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Presidents Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Presidents Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2026, 4, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" }; // Fully closed
                cmeHolidays[new DateTime(2026, 5, 25)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Memorial Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Memorial Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2026, 6, 19)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Juneteenth",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Juneteenth evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2026, 7, 2)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Independence Day Eve" };
                cmeHolidays[new DateTime(2026, 7, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day (Observed)" };
                cmeHolidays[new DateTime(2026, 9, 7)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Labor Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Labor Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2026, 11, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" }; // Fully closed
                cmeHolidays[new DateTime(2026, 11, 27)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Day after Thanksgiving" };
                cmeHolidays[new DateTime(2026, 12, 24)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Christmas Eve" };
                cmeHolidays[new DateTime(2026, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" }; // Fully closed
                cmeHolidays[new DateTime(2026, 12, 31)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "New Year's Eve" };

                // 2027
                cmeHolidays[new DateTime(2027, 1, 1)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "New Year's Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "New Year's Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2027, 1, 18)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Martin Luther King Jr. Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "MLK Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2027, 2, 15)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Presidents Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Presidents Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2027, 3, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                cmeHolidays[new DateTime(2027, 5, 31)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Memorial Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Memorial Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2027, 6, 18)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Juneteenth (Observed)",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Juneteenth evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2027, 7, 2)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Independence Day Eve" };
                cmeHolidays[new DateTime(2027, 7, 5)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day (Observed)" };
                cmeHolidays[new DateTime(2027, 9, 6)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Labor Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Labor Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2027, 11, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                cmeHolidays[new DateTime(2027, 11, 26)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Day after Thanksgiving" };
                cmeHolidays[new DateTime(2027, 12, 24)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day (Observed)" };
                cmeHolidays[new DateTime(2027, 12, 31)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "New Year's Eve" };

                // 2028
                cmeHolidays[new DateTime(2027, 12, 31)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day (Observed)" };
                cmeHolidays[new DateTime(2028, 1, 17)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Martin Luther King Jr. Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "MLK Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2028, 2, 21)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Presidents Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Presidents Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2028, 4, 14)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                cmeHolidays[new DateTime(2028, 5, 29)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Memorial Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Memorial Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2028, 6, 19)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Juneteenth",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Juneteenth evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2028, 7, 3)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Independence Day Eve" };
                cmeHolidays[new DateTime(2028, 7, 4)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day" };
                cmeHolidays[new DateTime(2028, 9, 4)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Labor Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Labor Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2028, 11, 23)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                cmeHolidays[new DateTime(2028, 11, 24)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Day after Thanksgiving" };
                cmeHolidays[new DateTime(2028, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                cmeHolidays[new DateTime(2028, 12, 29)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "New Year's Eve" };

                // 2029
                cmeHolidays[new DateTime(2029, 1, 1)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "New Year's Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "New Year's Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2029, 1, 15)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Martin Luther King Jr. Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "MLK Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2029, 2, 19)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Presidents Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Presidents Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2029, 3, 30)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                cmeHolidays[new DateTime(2029, 5, 28)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Memorial Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Memorial Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2029, 6, 19)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Juneteenth",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Juneteenth evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2029, 7, 3)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Independence Day Eve" };
                cmeHolidays[new DateTime(2029, 7, 4)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day" };
                cmeHolidays[new DateTime(2029, 9, 3)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Labor Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Labor Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2029, 11, 22)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                cmeHolidays[new DateTime(2029, 11, 23)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Day after Thanksgiving" };
                cmeHolidays[new DateTime(2029, 12, 24)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Christmas Eve" };
                cmeHolidays[new DateTime(2029, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                cmeHolidays[new DateTime(2029, 12, 31)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "New Year's Eve" };

                // 2030
                cmeHolidays[new DateTime(2030, 1, 1)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "New Year's Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "New Year's Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2030, 1, 21)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Martin Luther King Jr. Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "MLK Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2030, 2, 18)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Presidents Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Presidents Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2030, 4, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                cmeHolidays[new DateTime(2030, 5, 27)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Memorial Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Memorial Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2030, 6, 19)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Juneteenth",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Juneteenth evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2030, 7, 3)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Independence Day Eve" };
                cmeHolidays[new DateTime(2030, 7, 4)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day" };
                cmeHolidays[new DateTime(2030, 9, 2)] = new HolidayInfo
                {
                    IsHoliday = true,
                    HolidayName = "Labor Day",
                    SpecialSessions = new List<SessionWindow>
                    {
                        new SessionWindow(17, 0, 23, 59, SessionType.Evening, "Labor Day evening reopen")
                    }
                };
                cmeHolidays[new DateTime(2030, 11, 28)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                cmeHolidays[new DateTime(2030, 11, 29)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Day after Thanksgiving" };
                cmeHolidays[new DateTime(2030, 12, 24)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "Christmas Eve" };
                cmeHolidays[new DateTime(2030, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                cmeHolidays[new DateTime(2030, 12, 31)] = new HolidayInfo { IsEarlyClose = true, EarlyCloseHour = 12, HolidayName = "New Year's Eve" };
            }

            private void AddTSXHolidays(Dictionary<MarketId, Dictionary<DateTime, HolidayInfo>> holidays)
            {
                var tsxHolidays = holidays[MarketId.TSX];

                // 2026
                tsxHolidays[new DateTime(2026, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                tsxHolidays[new DateTime(2026, 2, 16)] = new HolidayInfo { IsHoliday = true, HolidayName = "Family Day" };
                tsxHolidays[new DateTime(2026, 4, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                tsxHolidays[new DateTime(2026, 5, 18)] = new HolidayInfo { IsHoliday = true, HolidayName = "Victoria Day" };
                tsxHolidays[new DateTime(2026, 7, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Canada Day" };
                tsxHolidays[new DateTime(2026, 8, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Civic Holiday" };
                tsxHolidays[new DateTime(2026, 9, 7)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                tsxHolidays[new DateTime(2026, 10, 12)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                tsxHolidays[new DateTime(2026, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                tsxHolidays[new DateTime(2026, 12, 28)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day (Observed)" };

                // 2027-2030 similar pattern
                tsxHolidays[new DateTime(2027, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                tsxHolidays[new DateTime(2027, 2, 15)] = new HolidayInfo { IsHoliday = true, HolidayName = "Family Day" };
                tsxHolidays[new DateTime(2027, 3, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                tsxHolidays[new DateTime(2027, 5, 24)] = new HolidayInfo { IsHoliday = true, HolidayName = "Victoria Day" };
                tsxHolidays[new DateTime(2027, 7, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Canada Day" };
                tsxHolidays[new DateTime(2027, 8, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "Civic Holiday" };
                tsxHolidays[new DateTime(2027, 9, 6)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                tsxHolidays[new DateTime(2027, 10, 11)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                tsxHolidays[new DateTime(2027, 12, 27)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day (Observed)" };
                tsxHolidays[new DateTime(2027, 12, 28)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day (Observed)" };

                // 2028
                tsxHolidays[new DateTime(2028, 1, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day (Observed)" };
                tsxHolidays[new DateTime(2028, 2, 21)] = new HolidayInfo { IsHoliday = true, HolidayName = "Family Day" };
                tsxHolidays[new DateTime(2028, 4, 14)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                tsxHolidays[new DateTime(2028, 5, 22)] = new HolidayInfo { IsHoliday = true, HolidayName = "Victoria Day" };
                tsxHolidays[new DateTime(2028, 7, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Canada Day (Observed)" };
                tsxHolidays[new DateTime(2028, 8, 7)] = new HolidayInfo { IsHoliday = true, HolidayName = "Civic Holiday" };
                tsxHolidays[new DateTime(2028, 9, 4)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                tsxHolidays[new DateTime(2028, 10, 9)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                tsxHolidays[new DateTime(2028, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                tsxHolidays[new DateTime(2028, 12, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day" };

                // 2029
                tsxHolidays[new DateTime(2029, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                tsxHolidays[new DateTime(2029, 2, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Family Day" };
                tsxHolidays[new DateTime(2029, 3, 30)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                tsxHolidays[new DateTime(2029, 5, 21)] = new HolidayInfo { IsHoliday = true, HolidayName = "Victoria Day" };
                tsxHolidays[new DateTime(2029, 7, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "Canada Day (Observed)" };
                tsxHolidays[new DateTime(2029, 8, 6)] = new HolidayInfo { IsHoliday = true, HolidayName = "Civic Holiday" };
                tsxHolidays[new DateTime(2029, 9, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                tsxHolidays[new DateTime(2029, 10, 8)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                tsxHolidays[new DateTime(2029, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                tsxHolidays[new DateTime(2029, 12, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day" };

                // 2030
                tsxHolidays[new DateTime(2030, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                tsxHolidays[new DateTime(2030, 2, 18)] = new HolidayInfo { IsHoliday = true, HolidayName = "Family Day" };
                tsxHolidays[new DateTime(2030, 4, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                tsxHolidays[new DateTime(2030, 5, 20)] = new HolidayInfo { IsHoliday = true, HolidayName = "Victoria Day" };
                tsxHolidays[new DateTime(2030, 7, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Canada Day" };
                tsxHolidays[new DateTime(2030, 8, 5)] = new HolidayInfo { IsHoliday = true, HolidayName = "Civic Holiday" };
                tsxHolidays[new DateTime(2030, 9, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                tsxHolidays[new DateTime(2030, 10, 14)] = new HolidayInfo { IsHoliday = true, HolidayName = "Thanksgiving" };
                tsxHolidays[new DateTime(2030, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                tsxHolidays[new DateTime(2030, 12, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day" };
            }

            private void AddLSEHolidays(Dictionary<MarketId, Dictionary<DateTime, HolidayInfo>> holidays)
            {
                var lseHolidays = holidays[MarketId.LSE];

                // 2026
                lseHolidays[new DateTime(2026, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                lseHolidays[new DateTime(2026, 4, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                lseHolidays[new DateTime(2026, 4, 6)] = new HolidayInfo { IsHoliday = true, HolidayName = "Easter Monday" };
                lseHolidays[new DateTime(2026, 5, 4)] = new HolidayInfo { IsHoliday = true, HolidayName = "Early May Bank Holiday" };
                lseHolidays[new DateTime(2026, 5, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Spring Bank Holiday" };
                lseHolidays[new DateTime(2026, 8, 31)] = new HolidayInfo { IsHoliday = true, HolidayName = "Summer Bank Holiday" };
                lseHolidays[new DateTime(2026, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                lseHolidays[new DateTime(2026, 12, 28)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day (Observed)" };

                // 2027
                lseHolidays[new DateTime(2027, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                lseHolidays[new DateTime(2027, 3, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                lseHolidays[new DateTime(2027, 3, 29)] = new HolidayInfo { IsHoliday = true, HolidayName = "Easter Monday" };
                lseHolidays[new DateTime(2027, 5, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Early May Bank Holiday" };
                lseHolidays[new DateTime(2027, 5, 31)] = new HolidayInfo { IsHoliday = true, HolidayName = "Spring Bank Holiday" };
                lseHolidays[new DateTime(2027, 8, 30)] = new HolidayInfo { IsHoliday = true, HolidayName = "Summer Bank Holiday" };
                lseHolidays[new DateTime(2027, 12, 27)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day (Observed)" };
                lseHolidays[new DateTime(2027, 12, 28)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day (Observed)" };

                // 2028
                lseHolidays[new DateTime(2028, 1, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day (Observed)" };
                lseHolidays[new DateTime(2028, 4, 14)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                lseHolidays[new DateTime(2028, 4, 17)] = new HolidayInfo { IsHoliday = true, HolidayName = "Easter Monday" };
                lseHolidays[new DateTime(2028, 5, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Early May Bank Holiday" };
                lseHolidays[new DateTime(2028, 5, 29)] = new HolidayInfo { IsHoliday = true, HolidayName = "Spring Bank Holiday" };
                lseHolidays[new DateTime(2028, 8, 28)] = new HolidayInfo { IsHoliday = true, HolidayName = "Summer Bank Holiday" };
                lseHolidays[new DateTime(2028, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                lseHolidays[new DateTime(2028, 12, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day" };

                // 2029
                lseHolidays[new DateTime(2029, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                lseHolidays[new DateTime(2029, 3, 30)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                lseHolidays[new DateTime(2029, 4, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "Easter Monday" };
                lseHolidays[new DateTime(2029, 5, 7)] = new HolidayInfo { IsHoliday = true, HolidayName = "Early May Bank Holiday" };
                lseHolidays[new DateTime(2029, 5, 28)] = new HolidayInfo { IsHoliday = true, HolidayName = "Spring Bank Holiday" };
                lseHolidays[new DateTime(2029, 8, 27)] = new HolidayInfo { IsHoliday = true, HolidayName = "Summer Bank Holiday" };
                lseHolidays[new DateTime(2029, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                lseHolidays[new DateTime(2029, 12, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day" };

                // 2030
                lseHolidays[new DateTime(2030, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                lseHolidays[new DateTime(2030, 4, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                lseHolidays[new DateTime(2030, 4, 22)] = new HolidayInfo { IsHoliday = true, HolidayName = "Easter Monday" };
                lseHolidays[new DateTime(2030, 5, 6)] = new HolidayInfo { IsHoliday = true, HolidayName = "Early May Bank Holiday" };
                lseHolidays[new DateTime(2030, 5, 27)] = new HolidayInfo { IsHoliday = true, HolidayName = "Spring Bank Holiday" };
                lseHolidays[new DateTime(2030, 8, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Summer Bank Holiday" };
                lseHolidays[new DateTime(2030, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                lseHolidays[new DateTime(2030, 12, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day" };
            }

            private void AddEuropeanHolidays(Dictionary<MarketId, Dictionary<DateTime, HolidayInfo>> holidays)
            {
                // Copy LSE holidays as base for European markets (they share many holidays)
                var euMarkets = new[] { MarketId.Xetra, MarketId.Euronext, MarketId.SIX };

                foreach (var market in euMarkets)
                {
                    // 2026
                    holidays[market][new DateTime(2026, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    holidays[market][new DateTime(2026, 4, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                    holidays[market][new DateTime(2026, 4, 6)] = new HolidayInfo { IsHoliday = true, HolidayName = "Easter Monday" };
                    holidays[market][new DateTime(2026, 5, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                    holidays[market][new DateTime(2026, 12, 24)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Eve" };
                    holidays[market][new DateTime(2026, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                    holidays[market][new DateTime(2026, 12, 31)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Eve" };

                    // 2027
                    holidays[market][new DateTime(2027, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    holidays[market][new DateTime(2027, 3, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                    holidays[market][new DateTime(2027, 3, 29)] = new HolidayInfo { IsHoliday = true, HolidayName = "Easter Monday" };
                    holidays[market][new DateTime(2027, 12, 24)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Eve" };
                    holidays[market][new DateTime(2027, 12, 31)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Eve" };

                    // 2028
                    holidays[market][new DateTime(2028, 1, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day (Observed)" };
                    holidays[market][new DateTime(2028, 4, 14)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                    holidays[market][new DateTime(2028, 4, 17)] = new HolidayInfo { IsHoliday = true, HolidayName = "Easter Monday" };
                    holidays[market][new DateTime(2028, 5, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                    holidays[market][new DateTime(2028, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                    holidays[market][new DateTime(2028, 12, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day" };

                    // 2029
                    holidays[market][new DateTime(2029, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    holidays[market][new DateTime(2029, 3, 30)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                    holidays[market][new DateTime(2029, 4, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "Easter Monday" };
                    holidays[market][new DateTime(2029, 5, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                    holidays[market][new DateTime(2029, 12, 24)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Eve" };
                    holidays[market][new DateTime(2029, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                    holidays[market][new DateTime(2029, 12, 31)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Eve" };

                    // 2030
                    holidays[market][new DateTime(2030, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    holidays[market][new DateTime(2030, 4, 19)] = new HolidayInfo { IsHoliday = true, HolidayName = "Good Friday" };
                    holidays[market][new DateTime(2030, 4, 22)] = new HolidayInfo { IsHoliday = true, HolidayName = "Easter Monday" };
                    holidays[market][new DateTime(2030, 5, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                    holidays[market][new DateTime(2030, 12, 24)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Eve" };
                    holidays[market][new DateTime(2030, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                    holidays[market][new DateTime(2030, 12, 31)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Eve" };
                }

                // MOEX (Moscow) - Conservative approach: mark major Russian holidays
                var moexHolidays = holidays[MarketId.MOEX];
                for (int year = 2026; year <= 2030; year++)
                {
                    // New Year holidays (typically Jan 1-8)
                    for (int day = 1; day <= 8; day++)
                        moexHolidays[new DateTime(year, 1, day)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year Holiday" };

                    // Defender of the Fatherland Day (Feb 23)
                    moexHolidays[new DateTime(year, 2, 23)] = new HolidayInfo { IsHoliday = true, HolidayName = "Defender of Fatherland Day" };

                    // International Women's Day (March 8)
                    moexHolidays[new DateTime(year, 3, 8)] = new HolidayInfo { IsHoliday = true, HolidayName = "International Women's Day" };

                    // Labour Day (May 1)
                    moexHolidays[new DateTime(year, 5, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };

                    // Victory Day (May 9)
                    moexHolidays[new DateTime(year, 5, 9)] = new HolidayInfo { IsHoliday = true, HolidayName = "Victory Day" };

                    // Russia Day (June 12)
                    moexHolidays[new DateTime(year, 6, 12)] = new HolidayInfo { IsHoliday = true, HolidayName = "Russia Day" };

                    // Unity Day (Nov 4)
                    moexHolidays[new DateTime(year, 11, 4)] = new HolidayInfo { IsHoliday = true, HolidayName = "Unity Day" };
                }
            }

            private void AddAsianHolidays(Dictionary<MarketId, Dictionary<DateTime, HolidayInfo>> holidays)
            {
                // Tokyo (JPX) - Major Japanese holidays
                var jpxHolidays = holidays[MarketId.JPX];
                for (int year = 2026; year <= 2030; year++)
                {
                    // New Year (Jan 1-3)
                    jpxHolidays[new DateTime(year, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    jpxHolidays[new DateTime(year, 1, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year Holiday" };
                    jpxHolidays[new DateTime(year, 1, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year Holiday" };

                    // Coming of Age Day (2nd Monday of January)
                    jpxHolidays[GetNthDayOfMonth(year, 1, DayOfWeek.Monday, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "Coming of Age Day" };

                    // National Foundation Day (Feb 11)
                    jpxHolidays[new DateTime(year, 2, 11)] = new HolidayInfo { IsHoliday = true, HolidayName = "National Foundation Day" };

                    // Emperor's Birthday (Feb 23)
                    jpxHolidays[new DateTime(year, 2, 23)] = new HolidayInfo { IsHoliday = true, HolidayName = "Emperor's Birthday" };

                    // Vernal Equinox (approx March 20-21)
                    jpxHolidays[new DateTime(year, 3, 20)] = new HolidayInfo { IsHoliday = true, HolidayName = "Vernal Equinox" };

                    // Showa Day (April 29)
                    jpxHolidays[new DateTime(year, 4, 29)] = new HolidayInfo { IsHoliday = true, HolidayName = "Showa Day" };

                    // Golden Week (May 3-5)
                    jpxHolidays[new DateTime(year, 5, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Constitution Day" };
                    jpxHolidays[new DateTime(year, 5, 4)] = new HolidayInfo { IsHoliday = true, HolidayName = "Greenery Day" };
                    jpxHolidays[new DateTime(year, 5, 5)] = new HolidayInfo { IsHoliday = true, HolidayName = "Children's Day" };

                    // Marine Day (3rd Monday of July)
                    jpxHolidays[GetNthDayOfMonth(year, 7, DayOfWeek.Monday, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Marine Day" };

                    // Mountain Day (Aug 11)
                    jpxHolidays[new DateTime(year, 8, 11)] = new HolidayInfo { IsHoliday = true, HolidayName = "Mountain Day" };

                    // Respect for Aged Day (3rd Monday of September)
                    jpxHolidays[GetNthDayOfMonth(year, 9, DayOfWeek.Monday, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Respect for Aged Day" };

                    // Autumnal Equinox (approx Sept 22-23)
                    jpxHolidays[new DateTime(year, 9, 23)] = new HolidayInfo { IsHoliday = true, HolidayName = "Autumnal Equinox" };

                    // Sports Day (2nd Monday of October)
                    jpxHolidays[GetNthDayOfMonth(year, 10, DayOfWeek.Monday, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "Sports Day" };

                    // Culture Day (Nov 3)
                    jpxHolidays[new DateTime(year, 11, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "Culture Day" };

                    // Labour Thanksgiving Day (Nov 23)
                    jpxHolidays[new DateTime(year, 11, 23)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Thanksgiving Day" };

                    // Year end (Dec 31)
                    jpxHolidays[new DateTime(year, 12, 31)] = new HolidayInfo { IsHoliday = true, HolidayName = "Year End" };
                }

                // Hong Kong (HKEX)
                var hkexHolidays = holidays[MarketId.HKEX];
                for (int year = 2026; year <= 2030; year++)
                {
                    hkexHolidays[new DateTime(year, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    // Chinese New Year (varies - simplified, actual dates would need lunar calendar)
                    hkexHolidays[new DateTime(year, 5, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                    hkexHolidays[new DateTime(year, 7, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "HKSAR Establishment Day" };
                    hkexHolidays[new DateTime(year, 10, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "National Day" };
                    hkexHolidays[new DateTime(year, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                    hkexHolidays[new DateTime(year, 12, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day" };
                }

                // Shanghai (SSE)
                var sseHolidays = holidays[MarketId.SSE];
                for (int year = 2026; year <= 2030; year++)
                {
                    // New Year
                    sseHolidays[new DateTime(year, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    // Chinese New Year (simplified - typically late Jan/Feb, week-long)
                    // Labour Day (May 1 week)
                    sseHolidays[new DateTime(year, 5, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                    // National Day (Oct 1-7)
                    for (int day = 1; day <= 7; day++)
                        sseHolidays[new DateTime(year, 10, day)] = new HolidayInfo { IsHoliday = true, HolidayName = "National Day" };
                }

                // Singapore (SGX)
                var sgxHolidays = holidays[MarketId.SGX];
                for (int year = 2026; year <= 2030; year++)
                {
                    sgxHolidays[new DateTime(year, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    sgxHolidays[new DateTime(year, 5, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                    sgxHolidays[new DateTime(year, 8, 9)] = new HolidayInfo { IsHoliday = true, HolidayName = "National Day" };
                    sgxHolidays[new DateTime(year, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                }

                // India (NSE)
                var nseHolidays = holidays[MarketId.NSE];
                for (int year = 2026; year <= 2030; year++)
                {
                    nseHolidays[new DateTime(year, 1, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Republic Day" };
                    nseHolidays[new DateTime(year, 8, 15)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day" };
                    nseHolidays[new DateTime(year, 10, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "Gandhi Jayanti" };
                }
            }

            private void AddOtherHolidays(Dictionary<MarketId, Dictionary<DateTime, HolidayInfo>> holidays)
            {
                // Australia (ASX)
                var asxHolidays = holidays[MarketId.ASX];
                for (int year = 2026; year <= 2030; year++)
                {
                    asxHolidays[new DateTime(year, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    asxHolidays[new DateTime(year, 1, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Australia Day" };
                    asxHolidays[new DateTime(year, 4, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "ANZAC Day" };
                    asxHolidays[new DateTime(year, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                    asxHolidays[new DateTime(year, 12, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day" };
                }

                // New Zealand (NZX)
                var nzxHolidays = holidays[MarketId.NZX];
                for (int year = 2026; year <= 2030; year++)
                {
                    nzxHolidays[new DateTime(year, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    nzxHolidays[new DateTime(year, 1, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "Day after New Year" };
                    nzxHolidays[new DateTime(year, 2, 6)] = new HolidayInfo { IsHoliday = true, HolidayName = "Waitangi Day" };
                    nzxHolidays[new DateTime(year, 4, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "ANZAC Day" };
                    nzxHolidays[new DateTime(year, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                    nzxHolidays[new DateTime(year, 12, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Boxing Day" };
                }

                // Dubai (DFM) - Friday/Saturday weekend
                var dfmHolidays = holidays[MarketId.DFM];
                for (int year = 2026; year <= 2030; year++)
                {
                    dfmHolidays[new DateTime(year, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    dfmHolidays[new DateTime(year, 12, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "UAE National Day" };
                    dfmHolidays[new DateTime(year, 12, 3)] = new HolidayInfo { IsHoliday = true, HolidayName = "UAE National Day" };
                }

                // Riyadh (Tadawul) - Friday/Saturday weekend
                var tadawulHolidays = holidays[MarketId.Tadawul];
                for (int year = 2026; year <= 2030; year++)
                {
                    tadawulHolidays[new DateTime(year, 9, 23)] = new HolidayInfo { IsHoliday = true, HolidayName = "Saudi National Day" };
                }

                // South Africa (JSE)
                var jseHolidays = holidays[MarketId.JSE];
                for (int year = 2026; year <= 2030; year++)
                {
                    jseHolidays[new DateTime(year, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    jseHolidays[new DateTime(year, 3, 21)] = new HolidayInfo { IsHoliday = true, HolidayName = "Human Rights Day" };
                    jseHolidays[new DateTime(year, 4, 27)] = new HolidayInfo { IsHoliday = true, HolidayName = "Freedom Day" };
                    jseHolidays[new DateTime(year, 5, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Workers' Day" };
                    jseHolidays[new DateTime(year, 6, 16)] = new HolidayInfo { IsHoliday = true, HolidayName = "Youth Day" };
                    jseHolidays[new DateTime(year, 8, 9)] = new HolidayInfo { IsHoliday = true, HolidayName = "National Women's Day" };
                    jseHolidays[new DateTime(year, 9, 24)] = new HolidayInfo { IsHoliday = true, HolidayName = "Heritage Day" };
                    jseHolidays[new DateTime(year, 12, 16)] = new HolidayInfo { IsHoliday = true, HolidayName = "Day of Reconciliation" };
                    jseHolidays[new DateTime(year, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                    jseHolidays[new DateTime(year, 12, 26)] = new HolidayInfo { IsHoliday = true, HolidayName = "Day of Goodwill" };
                }

                // Brazil (B3)
                var b3Holidays = holidays[MarketId.B3];
                for (int year = 2026; year <= 2030; year++)
                {
                    b3Holidays[new DateTime(year, 1, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "New Year's Day" };
                    b3Holidays[new DateTime(year, 4, 21)] = new HolidayInfo { IsHoliday = true, HolidayName = "Tiradentes Day" };
                    b3Holidays[new DateTime(year, 5, 1)] = new HolidayInfo { IsHoliday = true, HolidayName = "Labour Day" };
                    b3Holidays[new DateTime(year, 9, 7)] = new HolidayInfo { IsHoliday = true, HolidayName = "Independence Day" };
                    b3Holidays[new DateTime(year, 10, 12)] = new HolidayInfo { IsHoliday = true, HolidayName = "Our Lady of Aparecida" };
                    b3Holidays[new DateTime(year, 11, 2)] = new HolidayInfo { IsHoliday = true, HolidayName = "All Souls' Day" };
                    b3Holidays[new DateTime(year, 11, 15)] = new HolidayInfo { IsHoliday = true, HolidayName = "Republic Day" };
                    b3Holidays[new DateTime(year, 12, 25)] = new HolidayInfo { IsHoliday = true, HolidayName = "Christmas Day" };
                }
            }

            private DateTime GetNthDayOfMonth(int year, int month, DayOfWeek dayOfWeek, int n)
            {
                DateTime first = new DateTime(year, month, 1);
                int daysUntil = ((int)dayOfWeek - (int)first.DayOfWeek + 7) % 7;
                return first.AddDays(daysUntil + (n - 1) * 7);
            }

            public HolidayInfo GetHolidayInfo(MarketId market, DateTime localDate)
            {
                if (market == MarketId.Local)
                    return new HolidayInfo { IsHoliday = false };

                var date = localDate.Date;

                if (marketHolidays.TryGetValue(market, out var holidays))
                {
                    if (holidays.TryGetValue(date, out var info))
                    {
                        return info;
                    }
                }

                return new HolidayInfo { IsHoliday = false };
            }

            public MarketStatusResult GetStatus(MarketId market, DateTime utcNow)
            {
                if (market == MarketId.Local)
                {
                    return new MarketStatusResult
                    {
                        IsOpenNow = false,
                        Why = "Local time display only"
                    };
                }

                // Failsafe: Check if date is within our data range
                if (utcNow.Date < DATA_START_DATE || utcNow.Date > DATA_END_DATE)
                {
                    return new MarketStatusResult
                    {
                        IsOpenNow = false,
                        TimeToTransition = TimeSpan.Zero,
                        Why = $"Missing calendar data for {utcNow:yyyy-MM-dd} (failsafe closed)"
                    };
                }

                if (!marketTimeZones.TryGetValue(market, out var tz))
                {
                    return new MarketStatusResult
                    {
                        IsOpenNow = false,
                        Why = $"Unknown market: {market}"
                    };
                }

                DateTime localTime = TimeZoneInfo.ConvertTimeFromUtc(utcNow, tz);
                DateTime localDate = localTime.Date;
                TimeSpan localTimeOfDay = localTime.TimeOfDay;

                // Check for weekend (most markets)
                bool isWeekend = IsWeekendForMarket(market, localTime.DayOfWeek);

                // Check for holidays
                var holidayInfo = GetHolidayInfo(market, localDate);

                if (market == MarketId.CME)
                {
                    return GetCMEStatus(localTime, localDate, localTimeOfDay, holidayInfo, tz);
                }

                // Standard market logic
                if (isWeekend)
                {
                    var nextOpen = GetNextOpenTime(market, localTime, tz);
                    return new MarketStatusResult
                    {
                        IsOpenNow = false,
                        NextTransitionUtc = nextOpen,
                        TimeToTransition = nextOpen - utcNow,
                        Why = "Weekend - market closed"
                    };
                }

                if (holidayInfo.IsHoliday)
                {
                    var nextOpen = GetNextOpenTime(market, localTime, tz);
                    return new MarketStatusResult
                    {
                        IsOpenNow = false,
                        NextTransitionUtc = nextOpen,
                        TimeToTransition = nextOpen - utcNow,
                        HolidayName = holidayInfo.HolidayName,
                        Why = $"Holiday: {holidayInfo.HolidayName}"
                    };
                }

                // Check regular sessions
                if (defaultSessions.TryGetValue(market, out var sessions))
                {
                    int closeHour = 16; // default

                    // Check for early close
                    if (holidayInfo.IsEarlyClose)
                    {
                        closeHour = holidayInfo.EarlyCloseHour;
                    }

                    foreach (var session in sessions)
                    {
                        var effectiveEnd = holidayInfo.IsEarlyClose ?
                            new TimeSpan(closeHour, 0, 0) : session.EndLocal;

                        if (localTimeOfDay >= session.StartLocal && localTimeOfDay < effectiveEnd)
                        {
                            var closeTimeUtc = TimeZoneInfo.ConvertTimeToUtc(
                                localDate + effectiveEnd, tz);

                            return new MarketStatusResult
                            {
                                IsOpenNow = true,
                                NextTransitionUtc = closeTimeUtc,
                                TimeToTransition = closeTimeUtc - utcNow,
                                ActiveSessionType = session.Type,
                                IsEarlyClose = holidayInfo.IsEarlyClose,
                                EarlyCloseHour = closeHour,
                                Why = holidayInfo.IsEarlyClose ?
                                    $"Open - early close at {closeHour}:00" :
                                    $"Open - {session.Reason}"
                            };
                        }
                    }
                }

                // Market is closed - find next open
                var nextOpenTime = GetNextOpenTime(market, localTime, tz);
                return new MarketStatusResult
                {
                    IsOpenNow = false,
                    NextTransitionUtc = nextOpenTime,
                    TimeToTransition = nextOpenTime - utcNow,
                    Why = "Outside trading hours"
                };
            }

            private MarketStatusResult GetCMEStatus(DateTime localTime, DateTime localDate,
                TimeSpan localTimeOfDay, HolidayInfo holidayInfo, TimeZoneInfo tz)
            {
                DateTime utcNow = TimeZoneInfo.ConvertTimeToUtc(localTime, tz);

                // CME weekend: Friday 16:00 to Sunday 17:00
                bool isCMEWeekend =
                    (localTime.DayOfWeek == DayOfWeek.Saturday) ||
                    (localTime.DayOfWeek == DayOfWeek.Sunday && localTimeOfDay < new TimeSpan(17, 0, 0)) ||
                    (localTime.DayOfWeek == DayOfWeek.Friday && localTimeOfDay >= new TimeSpan(16, 0, 0));

                if (isCMEWeekend)
                {
                    var nextOpen = GetNextCMEOpenTime(localTime, tz);
                    return new MarketStatusResult
                    {
                        IsOpenNow = false,
                        NextTransitionUtc = nextOpen,
                        TimeToTransition = nextOpen - utcNow,
                        Why = "Weekend - CME Globex closed"
                    };
                }

                // CME daily maintenance: 16:00-17:00 CT (except Friday)
                bool isDailyMaintenance =
                    localTime.DayOfWeek != DayOfWeek.Friday &&
                    localTimeOfDay >= new TimeSpan(16, 0, 0) &&
                    localTimeOfDay < new TimeSpan(17, 0, 0);

                if (isDailyMaintenance)
                {
                    var reopenTime = TimeZoneInfo.ConvertTimeToUtc(
                        localDate.AddHours(17), tz);
                    return new MarketStatusResult
                    {
                        IsOpenNow = false,
                        NextTransitionUtc = reopenTime,
                        TimeToTransition = reopenTime - utcNow,
                        IsDailyBreak = true,
                        Why = "Daily maintenance break (16:00-17:00 CT)"
                    };
                }

                // Holiday handling - CME specific
                if (holidayInfo.IsHoliday)
                {
                    // Check if this holiday has evening reopen
                    if (holidayInfo.SpecialSessions != null && holidayInfo.SpecialSessions.Count > 0)
                    {
                        foreach (var session in holidayInfo.SpecialSessions)
                        {
                            if (localTimeOfDay >= session.StartLocal && localTimeOfDay < session.EndLocal)
                            {
                                // In the evening reopen session
                                var endTimeUtc = TimeZoneInfo.ConvertTimeToUtc(
                                    localDate + session.EndLocal, tz);
                                return new MarketStatusResult
                                {
                                    IsOpenNow = true,
                                    NextTransitionUtc = endTimeUtc,
                                    TimeToTransition = endTimeUtc - utcNow,
                                    HolidayName = holidayInfo.HolidayName,
                                    Why = $"{holidayInfo.HolidayName} evening session - market open"
                                };
                            }
                            else if (localTimeOfDay < session.StartLocal)
                            {
                                // Before evening reopen
                                var openTimeUtc = TimeZoneInfo.ConvertTimeToUtc(
                                    localDate + session.StartLocal, tz);
                                return new MarketStatusResult
                                {
                                    IsOpenNow = false,
                                    NextTransitionUtc = openTimeUtc,
                                    TimeToTransition = openTimeUtc - utcNow,
                                    HolidayName = holidayInfo.HolidayName,
                                    Why = $"{holidayInfo.HolidayName} - day session closed, evening reopen at 17:00 CT"
                                };
                            }
                        }
                    }

                    // Fully closed holiday (like Good Friday, Thanksgiving, Christmas)
                    var nextOpen = GetNextCMEOpenTime(localTime, tz);
                    return new MarketStatusResult
                    {
                        IsOpenNow = false,
                        NextTransitionUtc = nextOpen,
                        TimeToTransition = nextOpen - utcNow,
                        HolidayName = holidayInfo.HolidayName,
                        Why = $"{holidayInfo.HolidayName} - CME Globex closed"
                    };
                }

                // Early close handling
                if (holidayInfo.IsEarlyClose)
                {
                    var earlyCloseTime = new TimeSpan(holidayInfo.EarlyCloseHour, 0, 0);

                    if (localTimeOfDay >= earlyCloseTime)
                    {
                        // After early close
                        var nextOpen = GetNextCMEOpenTime(localTime, tz);
                        return new MarketStatusResult
                        {
                            IsOpenNow = false,
                            NextTransitionUtc = nextOpen,
                            TimeToTransition = nextOpen - utcNow,
                            IsEarlyClose = true,
                            EarlyCloseHour = holidayInfo.EarlyCloseHour,
                            Why = $"Early close at {holidayInfo.EarlyCloseHour}:00 CT - market closed"
                        };
                    }
                    else
                    {
                        // Before early close - market open
                        var closeTimeUtc = TimeZoneInfo.ConvertTimeToUtc(
                            localDate.AddHours(holidayInfo.EarlyCloseHour), tz);
                        return new MarketStatusResult
                        {
                            IsOpenNow = true,
                            NextTransitionUtc = closeTimeUtc,
                            TimeToTransition = closeTimeUtc - utcNow,
                            IsEarlyClose = true,
                            EarlyCloseHour = holidayInfo.EarlyCloseHour,
                            Why = $"Open - early close at {holidayInfo.EarlyCloseHour}:00 CT"
                        };
                    }
                }

                // Normal trading - CME is open
                DateTime nextCloseUtc;

                if (localTime.DayOfWeek == DayOfWeek.Friday)
                {
                    // Friday closes at 16:00 for weekend
                    nextCloseUtc = TimeZoneInfo.ConvertTimeToUtc(localDate.AddHours(16), tz);
                }
                else if (localTimeOfDay < new TimeSpan(16, 0, 0))
                {
                    // Day session - closes at 16:00 for maintenance
                    nextCloseUtc = TimeZoneInfo.ConvertTimeToUtc(localDate.AddHours(16), tz);
                }
                else
                {
                    // Evening session - closes at 16:00 next day (or weekend)
                    nextCloseUtc = TimeZoneInfo.ConvertTimeToUtc(localDate.AddDays(1).AddHours(16), tz);
                }

                return new MarketStatusResult
                {
                    IsOpenNow = true,
                    NextTransitionUtc = nextCloseUtc,
                    TimeToTransition = nextCloseUtc - utcNow,
                    Why = "CME Globex - regular session"
                };
            }

            private bool IsWeekendForMarket(MarketId market, DayOfWeek dayOfWeek)
            {
                // Middle East markets (DFM, Tadawul) have Friday-Saturday weekend
                if (market == MarketId.DFM || market == MarketId.Tadawul)
                {
                    return dayOfWeek == DayOfWeek.Friday || dayOfWeek == DayOfWeek.Saturday;
                }

                // Most markets have Saturday-Sunday weekend
                return dayOfWeek == DayOfWeek.Saturday || dayOfWeek == DayOfWeek.Sunday;
            }

            private DateTime GetNextOpenTime(MarketId market, DateTime localNow, TimeZoneInfo tz)
            {
                if (!defaultSessions.TryGetValue(market, out var sessions) || sessions.Count == 0)
                {
                    // Fallback: next business day 9:30 AM
                    return GetNextBusinessDay(market, localNow, tz, new TimeSpan(9, 30, 0));
                }

                var firstSession = sessions[0];
                return GetNextBusinessDay(market, localNow, tz, firstSession.StartLocal);
            }

            private DateTime GetNextCMEOpenTime(DateTime localNow, TimeZoneInfo tz)
            {
                DateTime candidate = localNow;

                // CME opens Sunday 17:00 CT
                if (localNow.DayOfWeek == DayOfWeek.Friday && localNow.TimeOfDay >= new TimeSpan(16, 0, 0))
                {
                    // Friday after close - next open is Sunday 17:00
                    candidate = localNow.Date.AddDays(2).AddHours(17);
                }
                else if (localNow.DayOfWeek == DayOfWeek.Saturday)
                {
                    // Saturday - next open is Sunday 17:00
                    candidate = localNow.Date.AddDays(1).AddHours(17);
                }
                else if (localNow.DayOfWeek == DayOfWeek.Sunday && localNow.TimeOfDay < new TimeSpan(17, 0, 0))
                {
                    // Sunday before 17:00 - opens at 17:00 today
                    candidate = localNow.Date.AddHours(17);
                }
                else if (localNow.TimeOfDay >= new TimeSpan(16, 0, 0) && localNow.TimeOfDay < new TimeSpan(17, 0, 0))
                {
                    // During daily maintenance - reopens at 17:00 today
                    candidate = localNow.Date.AddHours(17);
                }
                else
                {
                    // Already open or will open soon - this shouldn't be called in these cases
                    candidate = localNow.Date.AddHours(17);
                }

                // Check if candidate date is a holiday
                var holidayCheck = GetHolidayInfo(MarketId.CME, candidate.Date);
                int maxIterations = 10;
                while (holidayCheck.IsHoliday && maxIterations-- > 0)
                {
                    // Check if holiday has evening session
                    if (holidayCheck.SpecialSessions != null && holidayCheck.SpecialSessions.Count > 0)
                    {
                        // Evening session available
                        var eveningSession = holidayCheck.SpecialSessions[0];
                        if (candidate.TimeOfDay < eveningSession.StartLocal)
                        {
                            candidate = candidate.Date + eveningSession.StartLocal;
                            break;
                        }
                    }

                    // Move to next day's evening session
                    candidate = candidate.Date.AddDays(1).AddHours(17);

                    // Skip weekends
                    while (candidate.DayOfWeek == DayOfWeek.Saturday ||
                           (candidate.DayOfWeek == DayOfWeek.Sunday && candidate.Hour < 17))
                    {
                        if (candidate.DayOfWeek == DayOfWeek.Saturday)
                            candidate = candidate.Date.AddDays(1).AddHours(17);
                        else
                            candidate = candidate.Date.AddHours(17);
                    }

                    holidayCheck = GetHolidayInfo(MarketId.CME, candidate.Date);
                }

                return TimeZoneInfo.ConvertTimeToUtc(candidate, tz);
            }

            private DateTime GetNextBusinessDay(MarketId market, DateTime localNow, TimeZoneInfo tz, TimeSpan openTime)
            {
                DateTime candidate = localNow.Date + openTime;

                // If we're past today's open, start from tomorrow
                if (localNow.TimeOfDay >= openTime)
                {
                    candidate = candidate.AddDays(1);
                }

                // Skip weekends and holidays
                int maxIterations = 14;
                while (maxIterations-- > 0)
                {
                    if (!IsWeekendForMarket(market, candidate.DayOfWeek))
                    {
                        var holidayCheck = GetHolidayInfo(market, candidate.Date);
                        if (!holidayCheck.IsHoliday)
                        {
                            break;
                        }
                    }
                    candidate = candidate.AddDays(1);
                }

                return TimeZoneInfo.ConvertTimeToUtc(candidate, tz);
            }

            private void DebugPrint(string message)
            {
                debugPrint?.Invoke(message);
            }
        }
        #endregion

        #region Helper Classes
        private class TradingCenter
        {
            public string Name { get; set; }
            public TimeZoneInfo TimeZone { get; set; }
            public MarketId MarketId { get; set; }

            public TradingCenter(string name, TimeZoneInfo timeZone, MarketId marketId)
            {
                Name = name;
                TimeZone = timeZone;
                MarketId = marketId;
            }
        }

        private class TradingStatus
        {
            public bool IsOpen { get; set; }
            public TimeSpan TimeToChange { get; set; }
            public DateTime CurrentTime { get; set; }
            public string HolidayName { get; set; }
            public bool IsEarlyClose { get; set; }
            public bool IsDailyBreak { get; set; }
            public int EarlyCloseTime { get; set; }
            public bool IsLocalTime { get; set; }
            public string Why { get; set; }
        }

        private class DisplayLine
        {
            public string Text { get; set; }
            public SharpDX.Direct2D1.SolidColorBrush Brush { get; set; }
            public bool IsHeader { get; set; }

            public DisplayLine(string text, SharpDX.Direct2D1.SolidColorBrush brush, bool isHeader)
            {
                Text = text;
                Brush = brush;
                IsHeader = isHeader;
            }
        }
        #endregion

        #region Properties
        [NinjaScriptProperty]
        [Display(Name = "Show Local", Order = 1, GroupName = "Trading Centers")]
        public bool ShowLocal { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show New York", Order = 2, GroupName = "Trading Centers")]
        public bool ShowNewYork { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show CME Globex", Order = 3, GroupName = "Trading Centers")]
        public bool ShowCMEGlobex { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Toronto", Order = 4, GroupName = "Trading Centers")]
        public bool ShowToronto { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show London", Order = 5, GroupName = "Trading Centers")]
        public bool ShowLondon { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Frankfurt", Order = 6, GroupName = "Trading Centers")]
        public bool ShowFrankfurt { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Paris", Order = 7, GroupName = "Trading Centers")]
        public bool ShowParis { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Zurich", Order = 8, GroupName = "Trading Centers")]
        public bool ShowZurich { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Moscow", Order = 9, GroupName = "Trading Centers")]
        public bool ShowMoscow { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Dubai", Order = 10, GroupName = "Trading Centers")]
        public bool ShowDubai { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Mumbai", Order = 11, GroupName = "Trading Centers")]
        public bool ShowMumbai { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Shanghai", Order = 12, GroupName = "Trading Centers")]
        public bool ShowShanghai { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Tokyo", Order = 13, GroupName = "Trading Centers")]
        public bool ShowTokyo { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Hong Kong", Order = 14, GroupName = "Trading Centers")]
        public bool ShowHongKong { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Singapore", Order = 15, GroupName = "Trading Centers")]
        public bool ShowSingapore { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Sydney", Order = 16, GroupName = "Trading Centers")]
        public bool ShowSydney { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Wellington", Order = 17, GroupName = "Trading Centers")]
        public bool ShowWellington { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Riyadh", Order = 18, GroupName = "Trading Centers")]
        public bool ShowRiyadh { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Johannesburg", Order = 19, GroupName = "Trading Centers")]
        public bool ShowJohannesburg { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Sao Paulo", Order = 20, GroupName = "Trading Centers")]
        public bool ShowSaoPaulo { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show CME Trading Hours", Order = 1, GroupName = "Display Options")]
        public bool ShowTradingHours { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Holiday Checker", Order = 2, GroupName = "Display Options")]
        public bool ShowHolidayChecker { get; set; }

        [NinjaScriptProperty]
        [Range(8, 48)]
        [Display(Name = "Font Size", Order = 3, GroupName = "Display Options")]
        public int FontSize { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Text Color", Order = 1, GroupName = "Appearance")]
        public System.Windows.Media.Brush TextColor { get; set; }

        [Browsable(false)]
        public string TextColorSerializable
        {
            get { return Serialize.BrushToString(TextColor); }
            set { TextColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Live Market Color", Order = 2, GroupName = "Appearance")]
        public System.Windows.Media.Brush LiveColor { get; set; }

        [Browsable(false)]
        public string LiveColorSerializable
        {
            get { return Serialize.BrushToString(LiveColor); }
            set { LiveColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Closed Market Color", Order = 3, GroupName = "Appearance")]
        public System.Windows.Media.Brush ClosedColor { get; set; }

        [Browsable(false)]
        public string ClosedColorSerializable
        {
            get { return Serialize.BrushToString(ClosedColor); }
            set { ClosedColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Alert Color (Closing Soon)", Order = 4, GroupName = "Appearance")]
        public System.Windows.Media.Brush AlertColor { get; set; }

        [Browsable(false)]
        public string AlertColorSerializable
        {
            get { return Serialize.BrushToString(AlertColor); }
            set { AlertColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Opening Soon Color", Order = 5, GroupName = "Appearance")]
        public System.Windows.Media.Brush OpeningSoonColor { get; set; }

        [Browsable(false)]
        public string OpeningSoonColorSerializable
        {
            get { return Serialize.BrushToString(OpeningSoonColor); }
            set { OpeningSoonColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Background Color", Order = 6, GroupName = "Appearance")]
        public System.Windows.Media.Brush BackgroundColor { get; set; }

        [Browsable(false)]
        public string BackgroundColorSerializable
        {
            get { return Serialize.BrushToString(BackgroundColor); }
            set { BackgroundColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [Range(0, 100)]
        [Display(Name = "Background Opacity", Order = 7, GroupName = "Appearance")]
        public int BackgroundOpacity { get; set; }

        [NinjaScriptProperty]
        [Range(0, 800)]
        [Display(Name = "Horizontal Offset", Order = 1, GroupName = "Position")]
        public int HorizontalOffset { get; set; }

        [NinjaScriptProperty]
        [Range(0, 600)]
        [Display(Name = "Vertical Offset", Order = 2, GroupName = "Position")]
        public int VerticalOffset { get; set; }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PhillyFranksTools.WorldClock[] cacheWorldClock;
		public PhillyFranksTools.WorldClock WorldClock(bool showLocal, bool showNewYork, bool showCMEGlobex, bool showToronto, bool showLondon, bool showFrankfurt, bool showParis, bool showZurich, bool showMoscow, bool showDubai, bool showMumbai, bool showShanghai, bool showTokyo, bool showHongKong, bool showSingapore, bool showSydney, bool showWellington, bool showRiyadh, bool showJohannesburg, bool showSaoPaulo, bool showTradingHours, bool showHolidayChecker, int fontSize, System.Windows.Media.Brush textColor, System.Windows.Media.Brush liveColor, System.Windows.Media.Brush closedColor, System.Windows.Media.Brush alertColor, System.Windows.Media.Brush openingSoonColor, System.Windows.Media.Brush backgroundColor, int backgroundOpacity, int horizontalOffset, int verticalOffset)
		{
			return WorldClock(Input, showLocal, showNewYork, showCMEGlobex, showToronto, showLondon, showFrankfurt, showParis, showZurich, showMoscow, showDubai, showMumbai, showShanghai, showTokyo, showHongKong, showSingapore, showSydney, showWellington, showRiyadh, showJohannesburg, showSaoPaulo, showTradingHours, showHolidayChecker, fontSize, textColor, liveColor, closedColor, alertColor, openingSoonColor, backgroundColor, backgroundOpacity, horizontalOffset, verticalOffset);
		}

		public PhillyFranksTools.WorldClock WorldClock(ISeries<double> input, bool showLocal, bool showNewYork, bool showCMEGlobex, bool showToronto, bool showLondon, bool showFrankfurt, bool showParis, bool showZurich, bool showMoscow, bool showDubai, bool showMumbai, bool showShanghai, bool showTokyo, bool showHongKong, bool showSingapore, bool showSydney, bool showWellington, bool showRiyadh, bool showJohannesburg, bool showSaoPaulo, bool showTradingHours, bool showHolidayChecker, int fontSize, System.Windows.Media.Brush textColor, System.Windows.Media.Brush liveColor, System.Windows.Media.Brush closedColor, System.Windows.Media.Brush alertColor, System.Windows.Media.Brush openingSoonColor, System.Windows.Media.Brush backgroundColor, int backgroundOpacity, int horizontalOffset, int verticalOffset)
		{
			if (cacheWorldClock != null)
				for (int idx = 0; idx < cacheWorldClock.Length; idx++)
					if (cacheWorldClock[idx] != null && cacheWorldClock[idx].ShowLocal == showLocal && cacheWorldClock[idx].ShowNewYork == showNewYork && cacheWorldClock[idx].ShowCMEGlobex == showCMEGlobex && cacheWorldClock[idx].ShowToronto == showToronto && cacheWorldClock[idx].ShowLondon == showLondon && cacheWorldClock[idx].ShowFrankfurt == showFrankfurt && cacheWorldClock[idx].ShowParis == showParis && cacheWorldClock[idx].ShowZurich == showZurich && cacheWorldClock[idx].ShowMoscow == showMoscow && cacheWorldClock[idx].ShowDubai == showDubai && cacheWorldClock[idx].ShowMumbai == showMumbai && cacheWorldClock[idx].ShowShanghai == showShanghai && cacheWorldClock[idx].ShowTokyo == showTokyo && cacheWorldClock[idx].ShowHongKong == showHongKong && cacheWorldClock[idx].ShowSingapore == showSingapore && cacheWorldClock[idx].ShowSydney == showSydney && cacheWorldClock[idx].ShowWellington == showWellington && cacheWorldClock[idx].ShowRiyadh == showRiyadh && cacheWorldClock[idx].ShowJohannesburg == showJohannesburg && cacheWorldClock[idx].ShowSaoPaulo == showSaoPaulo && cacheWorldClock[idx].ShowTradingHours == showTradingHours && cacheWorldClock[idx].ShowHolidayChecker == showHolidayChecker && cacheWorldClock[idx].FontSize == fontSize && cacheWorldClock[idx].TextColor == textColor && cacheWorldClock[idx].LiveColor == liveColor && cacheWorldClock[idx].ClosedColor == closedColor && cacheWorldClock[idx].AlertColor == alertColor && cacheWorldClock[idx].OpeningSoonColor == openingSoonColor && cacheWorldClock[idx].BackgroundColor == backgroundColor && cacheWorldClock[idx].BackgroundOpacity == backgroundOpacity && cacheWorldClock[idx].HorizontalOffset == horizontalOffset && cacheWorldClock[idx].VerticalOffset == verticalOffset && cacheWorldClock[idx].EqualsInput(input))
						return cacheWorldClock[idx];
			return CacheIndicator<PhillyFranksTools.WorldClock>(new PhillyFranksTools.WorldClock(){ ShowLocal = showLocal, ShowNewYork = showNewYork, ShowCMEGlobex = showCMEGlobex, ShowToronto = showToronto, ShowLondon = showLondon, ShowFrankfurt = showFrankfurt, ShowParis = showParis, ShowZurich = showZurich, ShowMoscow = showMoscow, ShowDubai = showDubai, ShowMumbai = showMumbai, ShowShanghai = showShanghai, ShowTokyo = showTokyo, ShowHongKong = showHongKong, ShowSingapore = showSingapore, ShowSydney = showSydney, ShowWellington = showWellington, ShowRiyadh = showRiyadh, ShowJohannesburg = showJohannesburg, ShowSaoPaulo = showSaoPaulo, ShowTradingHours = showTradingHours, ShowHolidayChecker = showHolidayChecker, FontSize = fontSize, TextColor = textColor, LiveColor = liveColor, ClosedColor = closedColor, AlertColor = alertColor, OpeningSoonColor = openingSoonColor, BackgroundColor = backgroundColor, BackgroundOpacity = backgroundOpacity, HorizontalOffset = horizontalOffset, VerticalOffset = verticalOffset }, input, ref cacheWorldClock);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PhillyFranksTools.WorldClock WorldClock(bool showLocal, bool showNewYork, bool showCMEGlobex, bool showToronto, bool showLondon, bool showFrankfurt, bool showParis, bool showZurich, bool showMoscow, bool showDubai, bool showMumbai, bool showShanghai, bool showTokyo, bool showHongKong, bool showSingapore, bool showSydney, bool showWellington, bool showRiyadh, bool showJohannesburg, bool showSaoPaulo, bool showTradingHours, bool showHolidayChecker, int fontSize, System.Windows.Media.Brush textColor, System.Windows.Media.Brush liveColor, System.Windows.Media.Brush closedColor, System.Windows.Media.Brush alertColor, System.Windows.Media.Brush openingSoonColor, System.Windows.Media.Brush backgroundColor, int backgroundOpacity, int horizontalOffset, int verticalOffset)
		{
			return indicator.WorldClock(Input, showLocal, showNewYork, showCMEGlobex, showToronto, showLondon, showFrankfurt, showParis, showZurich, showMoscow, showDubai, showMumbai, showShanghai, showTokyo, showHongKong, showSingapore, showSydney, showWellington, showRiyadh, showJohannesburg, showSaoPaulo, showTradingHours, showHolidayChecker, fontSize, textColor, liveColor, closedColor, alertColor, openingSoonColor, backgroundColor, backgroundOpacity, horizontalOffset, verticalOffset);
		}

		public Indicators.PhillyFranksTools.WorldClock WorldClock(ISeries<double> input , bool showLocal, bool showNewYork, bool showCMEGlobex, bool showToronto, bool showLondon, bool showFrankfurt, bool showParis, bool showZurich, bool showMoscow, bool showDubai, bool showMumbai, bool showShanghai, bool showTokyo, bool showHongKong, bool showSingapore, bool showSydney, bool showWellington, bool showRiyadh, bool showJohannesburg, bool showSaoPaulo, bool showTradingHours, bool showHolidayChecker, int fontSize, System.Windows.Media.Brush textColor, System.Windows.Media.Brush liveColor, System.Windows.Media.Brush closedColor, System.Windows.Media.Brush alertColor, System.Windows.Media.Brush openingSoonColor, System.Windows.Media.Brush backgroundColor, int backgroundOpacity, int horizontalOffset, int verticalOffset)
		{
			return indicator.WorldClock(input, showLocal, showNewYork, showCMEGlobex, showToronto, showLondon, showFrankfurt, showParis, showZurich, showMoscow, showDubai, showMumbai, showShanghai, showTokyo, showHongKong, showSingapore, showSydney, showWellington, showRiyadh, showJohannesburg, showSaoPaulo, showTradingHours, showHolidayChecker, fontSize, textColor, liveColor, closedColor, alertColor, openingSoonColor, backgroundColor, backgroundOpacity, horizontalOffset, verticalOffset);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PhillyFranksTools.WorldClock WorldClock(bool showLocal, bool showNewYork, bool showCMEGlobex, bool showToronto, bool showLondon, bool showFrankfurt, bool showParis, bool showZurich, bool showMoscow, bool showDubai, bool showMumbai, bool showShanghai, bool showTokyo, bool showHongKong, bool showSingapore, bool showSydney, bool showWellington, bool showRiyadh, bool showJohannesburg, bool showSaoPaulo, bool showTradingHours, bool showHolidayChecker, int fontSize, System.Windows.Media.Brush textColor, System.Windows.Media.Brush liveColor, System.Windows.Media.Brush closedColor, System.Windows.Media.Brush alertColor, System.Windows.Media.Brush openingSoonColor, System.Windows.Media.Brush backgroundColor, int backgroundOpacity, int horizontalOffset, int verticalOffset)
		{
			return indicator.WorldClock(Input, showLocal, showNewYork, showCMEGlobex, showToronto, showLondon, showFrankfurt, showParis, showZurich, showMoscow, showDubai, showMumbai, showShanghai, showTokyo, showHongKong, showSingapore, showSydney, showWellington, showRiyadh, showJohannesburg, showSaoPaulo, showTradingHours, showHolidayChecker, fontSize, textColor, liveColor, closedColor, alertColor, openingSoonColor, backgroundColor, backgroundOpacity, horizontalOffset, verticalOffset);
		}

		public Indicators.PhillyFranksTools.WorldClock WorldClock(ISeries<double> input , bool showLocal, bool showNewYork, bool showCMEGlobex, bool showToronto, bool showLondon, bool showFrankfurt, bool showParis, bool showZurich, bool showMoscow, bool showDubai, bool showMumbai, bool showShanghai, bool showTokyo, bool showHongKong, bool showSingapore, bool showSydney, bool showWellington, bool showRiyadh, bool showJohannesburg, bool showSaoPaulo, bool showTradingHours, bool showHolidayChecker, int fontSize, System.Windows.Media.Brush textColor, System.Windows.Media.Brush liveColor, System.Windows.Media.Brush closedColor, System.Windows.Media.Brush alertColor, System.Windows.Media.Brush openingSoonColor, System.Windows.Media.Brush backgroundColor, int backgroundOpacity, int horizontalOffset, int verticalOffset)
		{
			return indicator.WorldClock(input, showLocal, showNewYork, showCMEGlobex, showToronto, showLondon, showFrankfurt, showParis, showZurich, showMoscow, showDubai, showMumbai, showShanghai, showTokyo, showHongKong, showSingapore, showSydney, showWellington, showRiyadh, showJohannesburg, showSaoPaulo, showTradingHours, showHolidayChecker, fontSize, textColor, liveColor, closedColor, alertColor, openingSoonColor, backgroundColor, backgroundOpacity, horizontalOffset, verticalOffset);
		}
	}
}

#endregion
