#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Text;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// DonchianBreakoutFollow -- the manual-execution half of the Donchian Breakout family.
//
// WHY THIS EXISTS
//   Most funding companies let you use tools, but not let a robot trade the account
//   for you. This indicator is the signal engine of the DonchianBreakoutUS strategy
//   with the order routing removed: it plots the channel, tracks which directions are
//   armed, prices the entry, stop and target, and then stands aside. You place the
//   orders.
//
//   It is not a lookalike of the strategy -- it IS the strategy's signal code. The
//   DonchianBreakoutUS strategy in this package calls this indicator for its signals
//   rather than keeping a second copy of the rules.
//
// THE SETUP
//   Price closes beyond the highest high / lowest low of the previous ChannelPeriod
//   bars, in the direction the 5-minute EMA stack is already pointing. Entry is a
//   limit placed a quarter of the trigger bar back inside it, live for one bar only.
//
// THE ONE PLACE THIS CAN DRIFT
//   A stop-out disarms that direction until price trades back through the channel
//   midpoint, so the signal depends on the OUTCOME of the previous trade, not just on
//   price. This indicator arms and disarms from its own simulated fills, and the
//   strategy uses the indicator's state rather than its live fills, so the two always
//   agree with each other. But if your real fill differs from the simulation -- a
//   rejected order, a partial, something you did by hand -- your account's history and
//   this chart's history have diverged, and so has what it will arm next. No other
//   strategy in this series has that coupling. It is called out in AGENTS.md too.
//
// TIME ZONE
//   Every HHMM here is read from the chart's own clock. The published preset is
//   written in US Eastern, so set NinjaTrader to Eastern (Tools > Options > General >
//   Time zone) or translate the session hours yourself.
//
// MIT licensed. No warranty and no guarantee of profit. See LICENSE and README.md.

// Every global-scope type in a NinjaScript package has to be unique across the whole
// Custom folder -- NinjaTrader compiles every file into one assembly, so two downloads
// that both declared, say, "AccountMode" could not be installed together.
public enum DonchianPreset
{
    US_Trend,
    Custom
}

public enum DonchianCorner
{
    TopLeft,
    TopRight,
    BottomLeft,
    BottomRight
}

// Sounds that ship with NinjaTrader 8, plus None (no alert for that event) and
// Custom (plays the file named in "Custom sound file").
public enum DonchianSound
{
    None,
    Alert1,
    Alert2,
    Alert3,
    Alert4,
    Announcement,
    OrderFilled,
    TargetFilled,
    StopFilled,
    Reversing,
    Custom
}

namespace NinjaTrader.NinjaScript.Indicators.PhillyFranksTools
{
    public class DonchianBreakoutFollow : Indicator
    {
        // --- Bracket construction, shared with the strategy -----------------------
        //  Consts, not settings, for the same reason they are consts in the strategy:
        //  they are the tested shape of the trade. A saved instance keeps its own
        //  property values forever, so a risk rule written as a property is silently
        //  defeated on every instance that already exists.
        private const double EntryRetracePct  = 0.25;   // give-back into the trigger bar
        private const double AtrStopMult      = 1.5;    // 1.5 x ATR(14) at the signal bar
        private const double StopFloorPoints  = 15.0;   // never tighter than this
        private const double StopCapPoints    = 40.0;   // nor wider, unless configured wider
        private const double MaxRMultiple     = 3.0;    // ceiling on the scaled R:R

        // --- Clock rules ----------------------------------------------------------
        private const int HardNoEntryHHMM = 1530;   // no new setup is priced at/after this
        private const int HardFlatHHMM    = 1545;   // anything still open is out
        private const int HardFlatEndHHMM = 1900;   // sweep ends before the Asian window

        // Effective (preset-resolved) parameters. Everything downstream reads these and
        // never the public properties, so Custom and preset runs take one code path.
        private int    effChannelPeriod;
        private double effBufferPoints;
        private double effMinAtr;
        private double effMinAdx;
        private bool   effRequireVwapAlign;
        private bool   effUseFiveMinuteTrend;
        private int    effTrendFast;
        private int    effTrendSlow;
        private int    effTrendSlopeBars;
        private bool   effRequireMidpointRearm;
        private double effStopPoints;
        private double effTargetPoints;
        private int    effSessionStart;
        private int    effSessionEnd;
        private string effPresetName = "";

        private EMA trendFast5m, trendSlow5m;

        // Optional session VWAP alignment. Unlike the other strategies in this series
        // this one accumulates on EVERY bar of the session, not only inside the entry
        // window, because that is where the strategy does it. Off in the preset.
        private double cumPV, cumVol;

        // Structural rearm. A stop-out disarms that direction until price trades back
        // through the channel midpoint.
        private bool longBreakoutArmed  = true;
        private bool shortBreakoutArmed = true;
        private double channelHigh, channelLow, channelMid;

        // Follow-along state machine. 0 = nothing, 1 = limit working (this bar only),
        // 2 = in the trade.
        private int    followState;
        private int    followDir;              // 1 long, -1 short
        private double limitPx, stopPx, targetPx, entryPx;
        private double stopPts, targetPts;
        private int    signalBar, entryBar;
        private int    tradesThisSession;
        private int    sessionWins, sessionLosses;
        private string lastOutcome = "";
        private int    currentRegime;          // 0 Unknown 1 Breakout 2 QuietTrend 3 Balance 4 Chop
        private int    drawSeq;                // unique tag suffix per setup
        private bool   forcedBarClose;

        [Browsable(false)] [XmlIgnore] public Series<double> Signal         { get; private set; }
        [Browsable(false)] [XmlIgnore] public Series<double> EntryLimit     { get; private set; }
        [Browsable(false)] [XmlIgnore] public Series<double> StopDistance   { get; private set; }
        [Browsable(false)] [XmlIgnore] public Series<double> TargetDistance { get; private set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name                     = "DonchianBreakoutFollow";
                Description              = "Donchian channel breakout setups priced for manual execution. Plots the channel, shows which directions are armed, and places no orders.";
                Calculate                = Calculate.OnBarClose;
                IsOverlay                = true;
                DrawOnPricePanel         = true;
                DisplayInDataBox         = false;
                PaintPriceMarkers        = false;
                IsSuspendedWhileInactive = false;

                Preset      = DonchianPreset.US_Trend;
                ShowVisuals = true;

                ChannelPeriod               = 30;
                BufferPoints                = 0.0;
                MinAtr                      = 5.0;
                MinAdx                      = 0.0;
                RequireVwapAlign            = false;
                UseFiveMinuteTrendAlignment = true;
                TrendFastPeriod             = 20;
                TrendSlowPeriod             = 50;
                TrendSlopeBars              = 1;
                RequireMidpointRearmAfterStop = true;
                StopPoints                  = 15;
                TargetPoints                = 30;
                SessionStartHHMM            = 930;
                SessionEndHHMM              = 1530;
                MaxTradesPerSession         = 99;
                AvoidLunchChop              = false;
                NewsBlackoutHHMM            = string.Empty;

                ShowPanel        = true;
                PanelCorner      = DonchianCorner.TopRight;
                PanelFontSize    = 13;
                ShowChannelPlots = true;
                EnableAlerts     = true;
                SetupSound       = DonchianSound.Alert1;
                FillSound        = DonchianSound.None;
                ExpirySound      = DonchianSound.None;
                CustomSoundFile  = string.Empty;
                RiskPerTradeUsd  = 0;

                LongBrush   = Brushes.LimeGreen;
                ShortBrush  = Brushes.OrangeRed;
                StopBrush   = Brushes.IndianRed;
                TargetBrush = Brushes.MediumSeaGreen;
                PanelText   = Brushes.Gainsboro;
                PanelArea   = Brushes.Black;

                // The channel is three plots rather than drawing objects: a Draw call
                // per bar would leave one object per bar for the life of the session.
                AddPlot(Brushes.DodgerBlue, "Channel high");
                AddPlot(Brushes.DodgerBlue, "Channel low");
                AddPlot(Brushes.DimGray,    "Midpoint");
            }
            else if (State == State.Configure)
            {
                // Bar-close parity is not optional. The strategy evaluates on closed
                // bars; an intrabar evaluation would show setups the strategy never
                // took and retract them as the bar moved.
                if (Calculate != Calculate.OnBarClose)
                {
                    Calculate      = Calculate.OnBarClose;
                    forcedBarClose = true;
                }
                ResolvePreset();

                // The 5-minute series the trend gate reads. Added unconditionally so
                // the series indices are the same whether or not the gate is enabled.
                AddDataSeries(BarsPeriodType.Minute, 5);
            }
            else if (State == State.DataLoaded)
            {
                Signal         = new Series<double>(this);
                EntryLimit     = new Series<double>(this);
                StopDistance   = new Series<double>(this);
                TargetDistance = new Series<double>(this);

                trendFast5m = EMA(BarsArray[1], effTrendFast);
                trendSlow5m = EMA(BarsArray[1], effTrendSlow);

                if (forcedBarClose)
                    Log(Name + ": Calculate was forced back to OnBarClose so the display matches the strategy.", LogLevel.Information);
            }
        }

        // Preset values are lifted verbatim from the strategy that ran the arena.
        // Custom hands control to the properties below, for research -- a tuned Custom
        // run is your configuration, not a published one.
        private void ResolvePreset()
        {
            switch (Preset)
            {
                case DonchianPreset.US_Trend:
                    effChannelPeriod = 30; effBufferPoints = 0.0;
                    effMinAtr = 5.0; effMinAdx = 0.0;
                    effRequireVwapAlign = false;
                    effUseFiveMinuteTrend = true;
                    effTrendFast = 20; effTrendSlow = 50; effTrendSlopeBars = 1;
                    effRequireMidpointRearm = true;
                    effStopPoints = 15; effTargetPoints = 30;
                    effSessionStart = 930; effSessionEnd = 1530;
                    effPresetName = "US trend-aligned (09:30-15:30 ET)";
                    break;

                default:
                    effChannelPeriod = ChannelPeriod; effBufferPoints = BufferPoints;
                    effMinAtr = MinAtr; effMinAdx = MinAdx;
                    effRequireVwapAlign = RequireVwapAlign;
                    effUseFiveMinuteTrend = UseFiveMinuteTrendAlignment;
                    effTrendFast = TrendFastPeriod; effTrendSlow = TrendSlowPeriod;
                    effTrendSlopeBars = TrendSlopeBars;
                    effRequireMidpointRearm = RequireMidpointRearmAfterStop;
                    effStopPoints = StopPoints; effTargetPoints = TargetPoints;
                    effSessionStart = SessionStartHHMM; effSessionEnd = SessionEndHHMM;
                    effPresetName = "Custom";
                    break;
            }
        }

        protected override void OnBarUpdate()
        {
            if (BarsInProgress != 0)
                return;
            if (CurrentBar < effChannelPeriod + 2)
                return;

            Signal[0]         = 0;
            EntryLimit[0]     = 0;
            StopDistance[0]   = 0;
            TargetDistance[0] = 0;

            if (Bars.IsFirstBarOfSession)
            {
                tradesThisSession = 0;
                cumPV = 0; cumVol = 0;
                longBreakoutArmed = true; shortBreakoutArmed = true;
                sessionWins = 0; sessionLosses = 0;
            }

            int now = ToTime(Time[0]) / 100;

            // A trade that is already on is managed on every bar, in or out of the
            // entry window -- the strategy's bracket does not care what time it is.
            // This is also where a stop-out disarms its direction.
            MaintainOpenTrade(now);

            // Accumulated on every bar of the session, not only in the window: that is
            // where the strategy does it.
            if (effRequireVwapAlign)
            {
                cumPV  += (High[0] + Low[0] + Close[0]) / 3.0 * Volume[0];
                cumVol += Volume[0];
            }

            ClassifyRegime();

            // The blackout returns before the channel and the rearm update, exactly as
            // the strategy does -- so a blacked-out bar does not rearm anything either.
            if (InNewsBlackout(now))
            {
                DrawPanel(now, "NEWS BLACKOUT");
                return;
            }

            channelHigh = MAX(High, effChannelPeriod)[1];
            channelLow  = MIN(Low,  effChannelPeriod)[1];
            channelMid  = (channelHigh + channelLow) / 2.0;

            double price = Close[0];
            UpdateStructuralRearm(price, channelMid);

            if (ShowChannelPlots)
            {
                Values[0][0] = channelHigh;
                Values[1][0] = channelLow;
                Values[2][0] = channelMid;
            }

            if (!InEntryWindow(now))
            {
                DrawPanel(now, "OUT OF WINDOW");
                return;
            }

            if (effMinAtr > 0 && ATR(14)[0] < effMinAtr)
            {
                DrawPanel(now, null);
                return;
            }
            if (effMinAdx > 0 && ADX(14)[0] < effMinAdx)
            {
                DrawPanel(now, null);
                return;
            }

            if (price > channelHigh + effBufferPoints)
            {
                if (!longBreakoutArmed)
                    lastOutcome = "BREAKOUT SKIPPED - long disarmed until the midpoint";
                else if (!FiveMinuteTrendAllows(1))
                    lastOutcome = "BREAKOUT SKIPPED - 5m trend not aligned";
                else if (effRequireVwapAlign && cumVol > 0 && price < cumPV / cumVol)
                    lastOutcome = "BREAKOUT SKIPPED - below session VWAP";
                else
                    PublishSetup(1);
            }
            else if (price < channelLow - effBufferPoints)
            {
                if (!shortBreakoutArmed)
                    lastOutcome = "BREAKOUT SKIPPED - short disarmed until the midpoint";
                else if (!FiveMinuteTrendAllows(-1))
                    lastOutcome = "BREAKOUT SKIPPED - 5m trend not aligned";
                else if (effRequireVwapAlign && cumVol > 0 && price > cumPV / cumVol)
                    lastOutcome = "BREAKOUT SKIPPED - above session VWAP";
                else
                    PublishSetup(-1);
            }

            DrawPanel(now, null);
        }

        // Use only fully closed 5-minute bars. A break is eligible only in the
        // direction of the higher-timeframe EMA stack and fast-EMA slope. Insufficient
        // secondary history fails CLOSED rather than bypassing the gate.
        private bool FiveMinuteTrendAllows(int direction)
        {
            if (!effUseFiveMinuteTrend) return true;
            if (effTrendFast >= effTrendSlow) return false;
            if (CurrentBars == null || CurrentBars.Length < 2 ||
                CurrentBars[1] < effTrendSlow + effTrendSlopeBars + 2)
                return false;

            int    closedBar = 1;
            double close5m   = Closes[1][closedBar];
            double fastNow   = trendFast5m[closedBar];
            double fastPrior = trendFast5m[closedBar + effTrendSlopeBars];
            double slowNow   = trendSlow5m[closedBar];

            if (direction > 0)
                return close5m > fastNow && fastNow > slowNow && fastNow > fastPrior;
            return close5m < fastNow && fastNow < slowNow && fastNow < fastPrior;
        }

        // A stop-out disarms only that direction. It cannot fire again until price
        // traverses back through the current channel midpoint, restoring genuine range
        // structure before a subsequent fresh break.
        private void UpdateStructuralRearm(double price, double midpoint)
        {
            if (!effRequireMidpointRearm)
            {
                longBreakoutArmed  = true;
                shortBreakoutArmed = true;
                return;
            }
            if (!longBreakoutArmed && price <= midpoint)
                longBreakoutArmed = true;
            if (!shortBreakoutArmed && price >= midpoint)
                shortBreakoutArmed = true;
        }

        // Price the order exactly the way the strategy prices it: a limit set
        // EntryRetracePct back inside the trigger bar, with an ATR-scaled bracket whose
        // R multiple comes from the configured stop/target ratio.
        private void PublishSetup(int dir)
        {
            double atr = 0;
            try { atr = ATR(14)[0]; } catch { }

            double rng = High[0] - Low[0];
            double px  = dir == 1 ? Close[0] - EntryRetracePct * rng
                                  : Close[0] + EntryRetracePct * rng;
            if (rng <= 0 || px <= 0) px = Close[0];
            try { px = Instrument.MasterInstrument.RoundToTickSize(px); } catch { }

            // The clamp may only ever WIDEN a configured stop, never tighten it.
            double lo = Math.Max(StopFloorPoints, effStopPoints);
            double hi = Math.Max(StopCapPoints, lo);
            double sp = atr > 0 ? Math.Max(lo, Math.Min(hi, AtrStopMult * atr)) : lo;
            double r  = Math.Min(MaxRMultiple, effStopPoints > 0 ? effTargetPoints / effStopPoints : 1.0);

            double stopDistance, targetDistance;
            if (TickSize > 0)
            {
                stopDistance   = Math.Round(sp / TickSize) * TickSize;
                targetDistance = Math.Round(sp * r / TickSize) * TickSize;
            }
            else
            {
                stopDistance   = sp;
                targetDistance = sp * r;
            }

            Signal[0]         = dir;
            EntryLimit[0]     = px;
            StopDistance[0]   = stopDistance;
            TargetDistance[0] = targetDistance;

            // Already following one, or out of setups for the session: the strategy
            // would decline this, so the chart declines it too and says why.
            if (followState != 0)
            {
                lastOutcome = "SETUP SKIPPED - already in a trade";
                return;
            }
            if (tradesThisSession >= MaxTradesPerSession)
            {
                lastOutcome = "SETUP SKIPPED - session limit reached";
                return;
            }

            stopPts     = stopDistance;
            targetPts   = targetDistance;
            followState = 1;
            followDir   = dir;
            limitPx     = px;
            signalBar   = CurrentBar;
            stopPx      = dir == 1 ? px - stopPts   : px + stopPts;
            targetPx    = dir == 1 ? px + targetPts : px - targetPts;
            drawSeq++;

            if (ShowVisuals && ChartControl != null)
            {
                Brush  b = dir == 1 ? LongBrush : ShortBrush;
                string t = "dn" + drawSeq;
                if (dir == 1) Draw.ArrowUp(this, t + "arw", false, 0, Low[0] - 2 * TickSize, b);
                else          Draw.ArrowDown(this, t + "arw", false, 0, High[0] + 2 * TickSize, b);
                Draw.Text(this, t + "txt", (dir == 1 ? "LONG limit " : "SHORT limit ")
                    + limitPx.ToString("0.00", CultureInfo.InvariantCulture),
                    0, dir == 1 ? Low[0] - 6 * TickSize : High[0] + 6 * TickSize, b);
                DrawFollowLines();
            }

            RaiseAlert("dnSetup", SetupSound, Priority.High,
                (dir == 1 ? "LONG" : "SHORT") + " Donchian breakout -- limit "
                + limitPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ", stop " + stopPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ", target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ". Valid for one bar.",
                dir == 1 ? LongBrush : ShortBrush);
        }

        // One alert path for every event. A sound of None means no alert is raised for
        // that event at all, which is why the fill and expiry cues ship silent.
        //
        // ShowVisuals gates this as well as EnableAlerts. A strategy hosts this
        // indicator with ShowVisuals = false and inherits every other property from
        // SetDefaults -- including EnableAlerts = true -- so without this the invisible
        // compute-only copy would alert alongside the one on your chart.
        private void RaiseAlert(string id, DonchianSound sound, Priority priority,
            string message, Brush foreground)
        {
            if (!EnableAlerts || !ShowVisuals || sound == DonchianSound.None)
                return;
            try
            {
                Alert(id + drawSeq, priority, message, SoundPath(sound),
                    10, Brushes.Black, foreground);
            }
            catch { }
        }

        // NinjaTrader wants a full path; a bare file name is resolved against the
        // install's own sounds folder, so the stock choices work on any machine.
        private string SoundPath(DonchianSound sound)
        {
            string file = sound == DonchianSound.Custom
                ? (CustomSoundFile ?? string.Empty).Trim()
                : sound.ToString() + ".wav";

            if (file.Length == 0)
                return string.Empty;
            if (file.IndexOf('\\') >= 0 || file.IndexOf('/') >= 0)
                return file;
            return NinjaTrader.Core.Globals.InstallDir + @"sounds\" + file;
        }

        // Resolve a working limit, then manage an open trade. Deliberately pessimistic
        // wherever one bar cannot tell you the order of events:
        //   * on the bar the limit fills, only the stop is checked. A backtest that
        //     credits a target on the fill bar reports profit factors it never earned.
        //   * from the next bar on, a bar that touches both is recorded as the stop.
        // A stop here disarms that direction, which is what makes this indicator's
        // simulated history part of the signal rather than just a display.
        private void MaintainOpenTrade(int now)
        {
            if (followState == 0)
                return;

            if (followState == 1)
            {
                if (CurrentBar <= signalBar)
                    return;

                bool filled = followDir == 1 ? Low[0] <= limitPx : High[0] >= limitPx;
                if (!filled)
                {
                    RaiseAlert("dnExpiry", ExpirySound, Priority.Medium,
                        "Donchian breakout limit expired unfilled at "
                        + limitPx.ToString("0.00", CultureInfo.InvariantCulture)
                        + " -- cancel the order and stand down.",
                        Brushes.DimGray);
                    CloseFollow("EXPIRED - no fill, stand down", 0, limitPx);
                    return;
                }

                // A gap through the limit fills at the open, in your favour.
                entryPx  = followDir == 1 ? Math.Min(limitPx, Open[0]) : Math.Max(limitPx, Open[0]);
                stopPx   = followDir == 1 ? entryPx - stopPts   : entryPx + stopPts;
                targetPx = followDir == 1 ? entryPx + targetPts : entryPx - targetPts;
                entryBar    = CurrentBar;
                followState = 2;
                tradesThisSession++;
                DrawFollowLines();

                RaiseAlert("dnFill", FillSound, Priority.Medium,
                    (followDir == 1 ? "LONG" : "SHORT") + " Donchian breakout limit filled at "
                    + entryPx.ToString("0.00", CultureInfo.InvariantCulture)
                    + " -- stop " + stopPx.ToString("0.00", CultureInfo.InvariantCulture)
                    + ", target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture) + ".",
                    followDir == 1 ? LongBrush : ShortBrush);

                // Fill bar: stop only.
                if (followDir == 1 ? Low[0] <= stopPx : High[0] >= stopPx)
                    CloseFollow("STOPPED", -1, stopPx);
                return;
            }

            if (now >= HardFlatHHMM && now < HardFlatEndHHMM)
            {
                double points = (Close[0] - entryPx) * followDir;
                CloseFollow("FLAT 15:45 ET - session rule", points < 0 ? -1 : 0, Close[0]);
                return;
            }

            bool hitStop   = followDir == 1 ? Low[0]  <= stopPx   : High[0] >= stopPx;
            bool hitTarget = followDir == 1 ? High[0] >= targetPx : Low[0]  <= targetPx;

            if (hitStop)        CloseFollow("STOPPED", -1, stopPx);
            else if (hitTarget) CloseFollow("TARGET", 1, targetPx);
            else                DrawFollowLines();
        }

        // result: 1 target, -1 stop, 0 neither (an expiry or a flat on the clock).
        // A stop disarms its direction -- the structural rearm rule.
        private void CloseFollow(string outcome, int result, double markPx)
        {
            if (ShowVisuals && ChartControl != null)
            {
                DrawFollowLines();   // extend the lines to the bar that ended it
                string t = "dn" + drawSeq;
                if (followState == 1)
                    Draw.Dot(this, t + "exp", false, 0, markPx, Brushes.DimGray);
                else
                    Draw.Diamond(this, t + "exit", false, 0, markPx,
                        result > 0 ? TargetBrush : result < 0 ? StopBrush : Brushes.Goldenrod);
            }

            if (result < 0 && followState == 2 && effRequireMidpointRearm)
            {
                if (followDir == 1) longBreakoutArmed  = false;
                else                shortBreakoutArmed = false;
            }

            lastOutcome = outcome;
            if (result > 0) sessionWins++;
            if (result < 0) sessionLosses++;
            followState = 0;
            followDir   = 0;
        }

        // Lines run from the bar that created them to the CURRENT bar and are redrawn
        // each update, rather than being projected into the future: one object per
        // setup, and it tracks the trade instead of floating off the right edge.
        private void DrawFollowLines()
        {
            if (!ShowVisuals || ChartControl == null || followState == 0)
                return;

            string t = "dn" + drawSeq;
            Brush  b = followDir == 1 ? LongBrush : ShortBrush;
            int    signalBars = Math.Max(0, CurrentBar - signalBar);

            if (followState == 1)
            {
                Draw.Line(this, t + "lim", false, signalBars, limitPx, 0, limitPx, b, DashStyleHelper.Dash, 2);
                return;
            }

            int entryBars = Math.Max(0, CurrentBar - entryBar);
            Draw.Line(this, t + "lim", false, signalBars, limitPx,  0, limitPx,  b,           DashStyleHelper.Dash,  1);
            Draw.Line(this, t + "stp", false, entryBars,  stopPx,   0, stopPx,   StopBrush,   DashStyleHelper.Solid, 2);
            Draw.Line(this, t + "tgt", false, entryBars,  targetPx, 0, targetPx, TargetBrush, DashStyleHelper.Solid, 2);
        }

        private bool InEntryWindow(int now)
        {
            if (now >= HardNoEntryHHMM && now < HardFlatEndHHMM) return false;
            if (effSessionStart <= effSessionEnd) return now >= effSessionStart && now < effSessionEnd;
            return now >= effSessionStart || now < effSessionEnd;
        }

        private bool InNewsBlackout(int now)
        {
            if (AvoidLunchChop && now >= 1200 && now < 1300) return true;
            if (string.IsNullOrEmpty(NewsBlackoutHHMM)) return false;
            foreach (var range in NewsBlackoutHHMM.Split(';'))
            {
                var parts = range.Split('-');
                if (parts.Length != 2) continue;
                int s, e;
                if (!int.TryParse(parts[0].Trim(), out s)) continue;
                if (!int.TryParse(parts[1].Trim(), out e)) continue;
                if (now >= s && now < e) return true;
            }
            return false;
        }

        // Context only -- the regime never arms or blocks a setup.
        private int ClassifyRegime()
        {
            if (CurrentBar < 100) return 0;
            double volRatio = ATR(14)[0] / SMA(ATR(14), 100)[0];
            double adx      = ADX(14)[0];

            bool expanding = (currentRegime == 1 || currentRegime == 4) ? volRatio > 1.00 : volRatio >= 1.20;
            bool trending  = (currentRegime == 1 || currentRegime == 2) ? adx > 18.0      : adx >= 22.0;

            if      ( trending &&  expanding) currentRegime = 1;
            else if ( trending && !expanding) currentRegime = 2;
            else if (!trending && !expanding) currentRegime = 3;
            else                              currentRegime = 4;
            return currentRegime;
        }

        private static string RegimeName(int r)
        {
            switch (r)
            {
                case 1:  return "Breakout (trend + expansion)";
                case 2:  return "Quiet trend";
                case 3:  return "Balance";
                case 4:  return "Chop + expansion";
                default: return "Unknown";
            }
        }

        private string TrendState()
        {
            if (!effUseFiveMinuteTrend) return "off";
            if (FiveMinuteTrendAllows(1))  return "UP - longs allowed";
            if (FiveMinuteTrendAllows(-1)) return "DOWN - shorts allowed";
            return "mixed - nothing allowed";
        }

        private void DrawPanel(int now, string windowNote)
        {
            if (!ShowVisuals || !ShowPanel || ChartControl == null)
                return;

            double pointValue = 0;
            try { pointValue = Instrument.MasterInstrument.PointValue; } catch { }

            var sb = new StringBuilder(640);
            sb.Append("DONCHIAN BREAKOUT - MANUAL FOLLOW").Append('\n');
            sb.Append(effPresetName).Append('\n');
            sb.Append("Clock ").Append(FormatHHMM(now));
            sb.Append("   window ").Append(FormatHHMM(effSessionStart)).Append('-').Append(FormatHHMM(effSessionEnd));
            if (windowNote != null) sb.Append("  [").Append(windowNote).Append(']');
            sb.Append('\n');
            sb.Append("Channel ").Append(channelLow.ToString("0.00", CultureInfo.InvariantCulture))
              .Append(" - ").Append(channelHigh.ToString("0.00", CultureInfo.InvariantCulture))
              .Append("   mid ").Append(channelMid.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
            sb.Append("5m trend ").Append(TrendState()).Append('\n');
            sb.Append("Armed  long ").Append(longBreakoutArmed ? "yes" : "NO")
              .Append("   short ").Append(shortBreakoutArmed ? "yes" : "NO")
              .Append("   regime ").Append(RegimeName(currentRegime)).Append('\n');
            sb.Append("------------------------------------------\n");

            if (followState == 1)
            {
                sb.Append(followDir == 1 ? "WORKING LIMIT - LONG" : "WORKING LIMIT - SHORT").Append('\n');
                sb.Append("Valid for THIS BAR ONLY\n");
                sb.Append("Limit  ").Append(limitPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Stop   ").Append(stopPx.ToString("0.00", CultureInfo.InvariantCulture))
                  .Append("   (").Append(stopPts.ToString("0.##", CultureInfo.InvariantCulture)).Append(" pts)").Append('\n');
                sb.Append("Target ").Append(targetPx.ToString("0.00", CultureInfo.InvariantCulture))
                  .Append("   (").Append(targetPts.ToString("0.##", CultureInfo.InvariantCulture)).Append(" pts)").Append('\n');
            }
            else if (followState == 2)
            {
                sb.Append(followDir == 1 ? "IN TRADE - LONG" : "IN TRADE - SHORT").Append('\n');
                sb.Append("Entry  ").Append(entryPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Stop   ").Append(stopPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Target ").Append(targetPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                double open = (Close[0] - entryPx) * followDir;
                sb.Append("Open   ").Append(open.ToString("+0.00;-0.00;0.00", CultureInfo.InvariantCulture)).Append(" pts")
                  .Append("   bars held ").Append(CurrentBar - entryBar).Append('\n');
            }
            else
            {
                sb.Append("WATCHING - needs a close beyond the channel\n");
                if (!string.IsNullOrEmpty(lastOutcome))
                    sb.Append("Last: ").Append(lastOutcome).Append('\n');
            }

            if (followState != 0 && pointValue > 0)
            {
                double riskPerContract = stopPts * pointValue;
                sb.Append("Risk   $").Append(riskPerContract.ToString("0", CultureInfo.InvariantCulture)).Append(" per contract");
                if (RiskPerTradeUsd > 0 && riskPerContract > 0)
                {
                    int size = (int)Math.Floor(RiskPerTradeUsd / riskPerContract);
                    sb.Append("   -> ").Append(size).Append(size == 1 ? " contract" : " contracts")
                      .Append(" at $").Append(RiskPerTradeUsd.ToString("0", CultureInfo.InvariantCulture));
                }
                sb.Append('\n');
            }

            sb.Append("------------------------------------------\n");
            sb.Append("Setups filled today ").Append(tradesThisSession).Append(" / ").Append(MaxTradesPerSession);
            sb.Append("    target ").Append(sessionWins).Append("  stop ").Append(sessionLosses).Append('\n');
            sb.Append("No new entry 15:30 ET  -  flat 15:45 ET\n");
            sb.Append("YOU place the orders. Nothing here trades.");

            Draw.TextFixed(this, "dnPanel", sb.ToString(), CornerToPosition(PanelCorner),
                PanelText, new SimpleFont("Consolas", PanelFontSize), Brushes.Transparent, PanelArea, 60);
        }

        private static string FormatHHMM(int hhmm)
        {
            int h = hhmm / 100, m = hhmm % 100;
            return h.ToString("00", CultureInfo.InvariantCulture) + ":" + m.ToString("00", CultureInfo.InvariantCulture);
        }

        private static TextPosition CornerToPosition(DonchianCorner corner)
        {
            switch (corner)
            {
                case DonchianCorner.TopLeft:     return TextPosition.TopLeft;
                case DonchianCorner.BottomLeft:  return TextPosition.BottomLeft;
                case DonchianCorner.BottomRight: return TextPosition.BottomRight;
                default:                         return TextPosition.TopRight;
            }
        }

        #region Properties
        // Only Preset and ShowVisuals carry [NinjaScriptProperty]: those two are the
        // generated constructor arguments a strategy passes. Holding the signature at
        // two arguments means adding a display option here never breaks the strategy.
        [NinjaScriptProperty]
        [Display(Name = "Preset", Order = 1, GroupName = "1. Setup", Description = "Published configuration to follow. Custom hands control to the parameters below.")]
        public DonchianPreset Preset { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show visuals", Order = 2, GroupName = "1. Setup", Description = "Off when a strategy hosts this indicator for its signals.")]
        public bool ShowVisuals { get; set; }

        [Range(2, 400)]
        [Display(Name = "Channel period (bars)", Order = 1, GroupName = "2. Custom rules", Description = "Highest high and lowest low of the previous N bars, current bar excluded.")]
        public int ChannelPeriod { get; set; }

        [Range(0, 100)]
        [Display(Name = "Buffer beyond channel (points)", Order = 2, GroupName = "2. Custom rules")]
        public double BufferPoints { get; set; }

        [Range(0, 200)]
        [Display(Name = "Min ATR(14) (0 = off)", Order = 3, GroupName = "2. Custom rules")]
        public double MinAtr { get; set; }

        [Range(0, 100)]
        [Display(Name = "Min ADX(14) (0 = off)", Order = 4, GroupName = "2. Custom rules")]
        public double MinAdx { get; set; }

        [Display(Name = "Require session VWAP alignment", Order = 5, GroupName = "2. Custom rules")]
        public bool RequireVwapAlign { get; set; }

        [Display(Name = "Require 5-minute trend alignment", Order = 6, GroupName = "2. Custom rules", Description = "Break only with the 5m EMA stack and fast-EMA slope. Insufficient history fails closed.")]
        public bool UseFiveMinuteTrendAlignment { get; set; }

        [Range(2, 200)]
        [Display(Name = "5m fast EMA", Order = 7, GroupName = "2. Custom rules")]
        public int TrendFastPeriod { get; set; }

        [Range(3, 400)]
        [Display(Name = "5m slow EMA", Order = 8, GroupName = "2. Custom rules")]
        public int TrendSlowPeriod { get; set; }

        [Range(1, 50)]
        [Display(Name = "5m slope lookback (bars)", Order = 9, GroupName = "2. Custom rules")]
        public int TrendSlopeBars { get; set; }

        [Display(Name = "Rearm at channel midpoint after a stop", Order = 10, GroupName = "2. Custom rules", Description = "A stop-out disarms that direction until price trades back through the midpoint.")]
        public bool RequireMidpointRearmAfterStop { get; set; }

        [Range(0.25, 200)]
        [Display(Name = "Stop (points)", Order = 11, GroupName = "2. Custom rules", Description = "Floor for the ATR stop and, with the target, the R multiple.")]
        public double StopPoints { get; set; }

        [Range(0.25, 200)]
        [Display(Name = "Target (points)", Order = 12, GroupName = "2. Custom rules")]
        public double TargetPoints { get; set; }

        [Range(0, 2400)]
        [Display(Name = "Session start (HHMM)", Order = 13, GroupName = "2. Custom rules")]
        public int SessionStartHHMM { get; set; }

        [Range(0, 2400)]
        [Display(Name = "Session end (HHMM)", Order = 14, GroupName = "2. Custom rules")]
        public int SessionEndHHMM { get; set; }

        [Range(1, 999)]
        [Display(Name = "Max setups / session", Order = 1, GroupName = "3. Filters")]
        public int MaxTradesPerSession { get; set; }

        [Display(Name = "Avoid lunch chop (12:00-13:00)", Order = 2, GroupName = "3. Filters")]
        public bool AvoidLunchChop { get; set; }

        [Display(Name = "News blackout (HHMM-HHMM;...)", Order = 3, GroupName = "3. Filters", Description = "Your own event windows, entered by hand. Nothing is downloaded.")]
        public string NewsBlackoutHHMM { get; set; }

        [Display(Name = "Show panel", Order = 1, GroupName = "4. Display")]
        public bool ShowPanel { get; set; }

        [Display(Name = "Panel corner", Order = 2, GroupName = "4. Display")]
        public DonchianCorner PanelCorner { get; set; }

        [Range(8, 30)]
        [Display(Name = "Panel font size", Order = 3, GroupName = "4. Display")]
        public int PanelFontSize { get; set; }

        [Display(Name = "Plot the channel", Order = 4, GroupName = "4. Display", Description = "Plots the channel high, low and midpoint. Style them under Plots.")]
        public bool ShowChannelPlots { get; set; }

        [Range(0, 100000)]
        [Display(Name = "Risk per trade ($, 0 = off)", Order = 5, GroupName = "4. Display", Description = "Shows how many contracts that budget buys at this stop distance. Sizing stays your decision.")]
        public double RiskPerTradeUsd { get; set; }

        [Display(Name = "Enable alerts", Order = 1, GroupName = "5. Alerts", Description = "Master switch. Off means no alert of any kind.")]
        public bool EnableAlerts { get; set; }

        [Display(Name = "Setup armed sound", Order = 2, GroupName = "5. Alerts", Description = "Plays when a breakout fires and the limit goes live. None raises no alert for this event.")]
        public DonchianSound SetupSound { get; set; }

        [Display(Name = "Limit filled sound", Order = 3, GroupName = "5. Alerts", Description = "Plays when price reaches the limit. Silent by default.")]
        public DonchianSound FillSound { get; set; }

        [Display(Name = "Limit expired sound", Order = 4, GroupName = "5. Alerts", Description = "Plays when the limit lapses unfilled and you should cancel. Silent by default.")]
        public DonchianSound ExpirySound { get; set; }

        [Display(Name = "Custom sound file", Order = 5, GroupName = "5. Alerts", Description = "Used by any event set to Custom. A .wav name resolves against NinjaTrader 8/sounds; a full path is taken as given.")]
        public string CustomSoundFile { get; set; }

        [XmlIgnore] [Display(Name = "Long", Order = 1, GroupName = "6. Colors")]
        public Brush LongBrush { get; set; }
        [Browsable(false)]
        public string LongBrushSerialize { get { return Serialize.BrushToString(LongBrush); } set { LongBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Short", Order = 2, GroupName = "6. Colors")]
        public Brush ShortBrush { get; set; }
        [Browsable(false)]
        public string ShortBrushSerialize { get { return Serialize.BrushToString(ShortBrush); } set { ShortBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Stop", Order = 3, GroupName = "6. Colors")]
        public Brush StopBrush { get; set; }
        [Browsable(false)]
        public string StopBrushSerialize { get { return Serialize.BrushToString(StopBrush); } set { StopBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Target", Order = 4, GroupName = "6. Colors")]
        public Brush TargetBrush { get; set; }
        [Browsable(false)]
        public string TargetBrushSerialize { get { return Serialize.BrushToString(TargetBrush); } set { TargetBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Panel text", Order = 5, GroupName = "6. Colors")]
        public Brush PanelText { get; set; }
        [Browsable(false)]
        public string PanelTextSerialize { get { return Serialize.BrushToString(PanelText); } set { PanelText = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Panel background", Order = 6, GroupName = "6. Colors")]
        public Brush PanelArea { get; set; }
        [Browsable(false)]
        public string PanelAreaSerialize { get { return Serialize.BrushToString(PanelArea); } set { PanelArea = Serialize.StringToBrush(value); } }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PhillyFranksTools.DonchianBreakoutFollow[] cacheDonchianBreakoutFollow;
		public PhillyFranksTools.DonchianBreakoutFollow DonchianBreakoutFollow(DonchianPreset preset, bool showVisuals)
		{
			return DonchianBreakoutFollow(Input, preset, showVisuals);
		}

		public PhillyFranksTools.DonchianBreakoutFollow DonchianBreakoutFollow(ISeries<double> input, DonchianPreset preset, bool showVisuals)
		{
			if (cacheDonchianBreakoutFollow != null)
				for (int idx = 0; idx < cacheDonchianBreakoutFollow.Length; idx++)
					if (cacheDonchianBreakoutFollow[idx] != null && cacheDonchianBreakoutFollow[idx].Preset == preset && cacheDonchianBreakoutFollow[idx].ShowVisuals == showVisuals && cacheDonchianBreakoutFollow[idx].EqualsInput(input))
						return cacheDonchianBreakoutFollow[idx];
			return CacheIndicator<PhillyFranksTools.DonchianBreakoutFollow>(new PhillyFranksTools.DonchianBreakoutFollow(){ Preset = preset, ShowVisuals = showVisuals }, input, ref cacheDonchianBreakoutFollow);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PhillyFranksTools.DonchianBreakoutFollow DonchianBreakoutFollow(DonchianPreset preset, bool showVisuals)
		{
			return indicator.DonchianBreakoutFollow(Input, preset, showVisuals);
		}

		public Indicators.PhillyFranksTools.DonchianBreakoutFollow DonchianBreakoutFollow(ISeries<double> input , DonchianPreset preset, bool showVisuals)
		{
			return indicator.DonchianBreakoutFollow(input, preset, showVisuals);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PhillyFranksTools.DonchianBreakoutFollow DonchianBreakoutFollow(DonchianPreset preset, bool showVisuals)
		{
			return indicator.DonchianBreakoutFollow(Input, preset, showVisuals);
		}

		public Indicators.PhillyFranksTools.DonchianBreakoutFollow DonchianBreakoutFollow(ISeries<double> input , DonchianPreset preset, bool showVisuals)
		{
			return indicator.DonchianBreakoutFollow(input, preset, showVisuals);
		}
	}
}

#endregion
