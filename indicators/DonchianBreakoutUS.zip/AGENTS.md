# AGENTS.md — Donchian Breakout

Working notes for a coding agent asked to change anything in this package. Read this
before editing either `.cs` file. `CLAUDE.md` carries the same rules in shorter form.

## What this package is

A NinjaTrader 8 trading system shipped in two halves:

| File | Owns |
|---|---|
| `Indicators/DonchianBreakoutFollow.cs` | **All** signal logic, the bracket sizing, the display, the alerts |
| `Strategies/DonchianBreakoutUS.cs` | Order submission, account guard, clock enforcement, target limit exit |

The strategy hosts the indicator (`signals = DonchianBreakoutFollow(Preset, false);` in
`State.DataLoaded`) and reads four series from it: `Signal`, `EntryLimit`,
`StopDistance`, `TargetDistance`.

## The one rule that matters

**There is exactly one copy of the signal logic, and it lives in the indicator.**

The package is sold on the claim that what a trader sees on the chart is what the
strategy does. A second copy of any entry condition — even "just for clarity", even
"just so the strategy is standalone" — breaks that claim silently, because the two
copies will be edited at different times by different people.

Corollaries:

- Add a condition? It goes in `DonchianBreakoutFollow.OnBarUpdate`, never in the strategy.
- Change the bracket maths? `PublishSetup` in the indicator, never `SubmitEntry`.
- The strategy may only ever **decline** a signal (flat check, trade count, account
  guard, news blackout). It must never construct one.

## Parity invariants — do not "fix" these

Each of these looks like a bug and is not. They reproduce the code that produced the
published results; changing one changes the signals and invalidates `README.md`.

1. **The rearm state makes the signal depend on trade OUTCOMES.** A stop-out disarms
   that direction until price trades back through the channel midpoint. The indicator
   arms and disarms from its own simulated fills and the strategy consumes the
   indicator's state rather than its live fills, so the two halves always agree — but a
   real fill that differs from the simulation permanently diverges the chart's armed
   state from the account's. This is the only strategy in the series with that coupling.
   It is stated plainly in `README.md`; do not quietly drop the caveat.
2. **The channel excludes the current bar.** `MAX(High, N)[1]` and `MIN(Low, N)[1]`. The
   bar that breaks out is not part of what it breaks.
3. **The 5-minute trend gate fails CLOSED.** Insufficient secondary history returns
   false rather than passing the gate, and `TrendFastPeriod >= TrendSlowPeriod` also
   returns false. Never "helpfully" bypass it while data is loading.
4. **A news blackout also freezes the rearm.** The strategy returns before the channel
   and rearm update, so a disarmed direction stays disarmed through a blackout even if
   price crosses the midpoint. Reproduced exactly.
5. **The optional VWAP filter accumulates on every bar of the session**, not only inside
   the entry window — unlike the VwapReclaim package, where the window is the anchor.
   Same words, different meaning; do not unify them.
6. **Bar close only.** The indicator forces `Calculate` back to `OnBarClose` in
   `State.Configure`. Intrabar evaluation would surface setups that retract.
7. **Pessimistic simulated fills.** On the fill bar only the stop is checked; after that
   a bar touching both stop and target is recorded as a stop. Here that pessimism also
   feeds the rearm, so it makes the chart slightly stricter than the account.
8. **One-bar limit life.** `EnterLongLimit(0, false, ...)` with
   `isLiveUntilCancelled = false`. A setup that does not retrace is declined, not chased.
9. **`BarsRequiredToTrade = 32`** on the strategy, and the indicator gates at
   `ChannelPeriod + 2`. The 5-minute gate needs roughly 55 secondary bars on top.
10. **Risk constants are `const`, not properties.** `EntryRetracePct`, `AtrStopMult`,
   `StopFloorPoints`, `StopCapPoints`, `MaxRMultiple`, `HardNoEntryHHMM`,
   `HardFlatHHMM`, `HardFlatEndHHMM`. A NinjaTrader strategy instance already configured
   on the Strategies tab keeps its own saved property values, so a risk rule written as
   a property is silently defeated on every instance that already exists. This was
   learned the expensive way. Do not promote any of them to a property.
11. **The stop clamp may only widen a configured stop, never tighten it.**
12. **15:30 / 15:45 ET.** No new entry from 15:30, flat from 15:45, re-checked every bar
   and every tick until 19:00. Never make these conditional on anything.

## NinjaScript constraints

- **Every global-scope type must be unique across the whole Custom folder.** NinjaTrader
  compiles every file in `bin/Custom` into one assembly, so two downloads that both
  declared `AccountMode` or `Sound` could not be installed side by side. That is why
  everything here is prefixed: `DonchianPreset`, `DonchianAccountMode`,
  `DonchianSound`, `DonchianCorner`. Keep the prefix on anything you add.
- `DonchianBreakoutFollow` is named to match its sibling packages, and to stay clear of
  NinjaTrader's own `@DonchianChannel` indicator.
- Enums used as `[NinjaScriptProperty]` parameter types sit at **global scope**, outside
  the namespace: the generated wrapper resolves enum parameter types by bare name.
- Only two properties on the indicator carry `[NinjaScriptProperty]`: `Preset` and
  `ShowVisuals`, in that order. NinjaTrader builds the strategy-facing wrapper from
  those in declaration order, so **adding a third breaks the strategy's call**.
- **The `#region NinjaScript generated code` block belongs to NinjaTrader.** It is what
  makes `DonchianBreakoutFollow(Preset, false)` resolve inside the strategy; with no region
  the compile fails `CS0103`. Never write one by hand — NinjaTrader *appends* its own on
  compile rather than replacing what it finds, so a hand-written copy yields two and
  fails with `CS0111` / `CS0121` / `CS0102`. To change it, delete the whole region and
  let the next compile regenerate it.
- **Line endings decide whether that happens to you.** NinjaTrader writes the region
  with CRLF and finds it again by matching that text. An editor that normalises the file
  to LF leaves the region readable to you and invisible to NinjaTrader, which appends a
  second copy on the next compile. So: the copy in this repo carries **no region at
  all**; install it, let NinjaTrader generate one, and copy the result back **byte for
  byte** as the artifact to ship. Never edit a file that already has a region without
  stripping it first.
- Targets C# 5 / .NET 4.8 as NinjaTrader compiles it. No `$` string interpolation, no
  tuples, no pattern matching.
- Files must stay **pure ASCII**.
- **Two data series.** The indicator calls `AddDataSeries(BarsPeriodType.Minute, 5)` in
  `State.Configure`, and the strategy declares the same one because the original did.
  Every `OnBarUpdate` must therefore guard `if (BarsInProgress != 0) return;`.
- No blocking work, no network calls, no unbounded file IO on the update path. The only
  file the strategy writes is a single four-field line under
  `NinjaTrader.Core.Globals.UserDataDir\Donchian\`.
- **No hardcoded machine-specific paths.**
- Catch blocks either log to `NinjaTrader.Code.Output.Process` / `Log()` or are a
  documented no-op on a cosmetic call. Nothing fails silently.
- Draw objects: one per setup, tagged `dn<seq>...`, redrawn from their origin bar to bar
  0. Never draw one object per bar — that leaks objects for the life of the session.

## Verifying a change

NinjaTrader is the compiler and Market Replay is the test bed.

1. Compile from the NinjaScript editor (F5). Warnings matter — an unused field usually
   means a code path was half-removed.
2. Put `DonchianBreakoutFollow` on a 1-minute NQ chart, ETH template, NinjaTrader set to
   US Eastern. Check the channel plots track the previous 30 bars' extremes, that the
   5-minute trend line in the panel is blank until the secondary series has history,
   and that a simulated stop flips its direction to `Armed ... NO` until price crosses
   the midpoint.
3. Run `DonchianBreakoutUS` on the same chart in Market Replay on a sim account. **Every
   entry the strategy takes must sit on a bar the indicator marked**, at the same limit
   price. If they disagree, the parity claim is broken — fix that first.
4. Watch the NinjaScript Output window for guard lines and failure messages.
5. If you changed a signal rule, the numbers in `README.md` no longer describe this
   code. Re-test over the same window or delete the claim.

## Out of bounds

Do not, without the owner explicitly asking:

- remove or weaken the clock rules or the account guard
- turn the indicator into an order-placing tool — its whole purpose is that it does not
  trade, so that it can be used where automation is not allowed
- add a network call, a licence check, telemetry, or anything that phones home
- reintroduce the per-trade JSONL research logger that was stripped from the strategy
- change `README.md`'s performance numbers to anything other than what the record says
