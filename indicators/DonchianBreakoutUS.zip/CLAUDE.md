# CLAUDE.md

Guidance for Claude Code when working in this package. `AGENTS.md` has the long form and
the reasoning; this file is the short version you should hold in your head.

## Project

A NinjaTrader 8 trading system, two files, shipped as a free download:

- `Indicators/DonchianBreakoutFollow.cs` — the signal engine and the manual-trading display.
  Places no orders. This is what a trader on a funded account uses.
- `Strategies/DonchianBreakoutUS.cs` — the automated half. Orders, account guard, clock
  rules. It **calls the indicator** for its signals.

The setup: a close beyond the highest high or lowest low of the previous 30 bars, taken
only in the direction the 5-minute EMA stack already points. Entry is a one-bar
retracement limit with an ATR-scaled bracket. A stop-out disarms that direction until
price trades back through the channel midpoint.

There is no build system. NinjaTrader compiles these in place (F5 in the NinjaScript
editor). There are no tests to run; verification is a Market Replay session.

## Rules

1. **Signal logic lives in the indicator only.** Never copy an entry condition into the
   strategy, not even a simplified one. The package's entire promise is that the chart
   and the strategy cannot disagree.
2. **The strategy may only decline a signal, never create one.**
3. **Never promote a risk constant to a property.** `EntryRetracePct`, `AtrStopMult`,
   `StopFloorPoints`, `StopCapPoints`, `MaxRMultiple` and the three `HardFlat*` /
   `HardNoEntry*` clock constants are `const` on purpose: a configured NinjaTrader
   strategy instance keeps its saved property values, so a risk rule expressed as a
   property is silently defeated on every instance that already exists.
4. **Never add a `[NinjaScriptProperty]` to the indicator.** Exactly two exist —
   `Preset` then `ShowVisuals` — and NinjaTrader builds the strategy's call signature
   from them. Everything else is a plain `[Display]` property.
5. **The `#region NinjaScript generated code` block belongs to NinjaTrader.** Without
   one the compile fails `CS0103`. Never hand-write it: NinjaTrader appends its own on
   compile instead of replacing yours, and two copies fail with `CS0111` / `CS0121`.
   **It matches its own region by CRLF text**, so normalising the file to LF makes it
   invisible and earns you a duplicate. The copy in this repo therefore has no region:
   install it, let NinjaTrader generate one, and copy the result back byte for byte to
   ship.
6. **Keep the `Donchian` prefix on every global-scope type.** All of `bin/Custom`
   compiles into one assembly, so an unprefixed `AccountMode` or `Sound` would collide
   with another download.
7. **Pure ASCII, C# 5 syntax, no `$` interpolation.**
8. **No hardcoded paths, no network calls, no silent catches.** Disk access resolves
   from `NinjaTrader.Core.Globals.UserDataDir`. Failures print to the NinjaScript Output
   window.

## Things that look like bugs and are not

- The rearm state means the signal depends on the OUTCOME of the last trade, not just
  on price. The indicator arms from its own simulated fills and the strategy uses the
  indicator's state, so the halves agree with each other — but a real fill that differs
  from the simulation diverges the chart from the account for good. Only this package
  has that coupling, and the README says so out loud.
- The channel excludes the current bar: the break is measured against the previous 30.
- The 5-minute trend gate fails closed. Not enough secondary history means no trade.
- A news blackout freezes the rearm too, because the strategy returns before the rearm
  update.
- The optional VWAP filter accumulates across the whole session here, unlike the
  VwapReclaim package where it is anchored to the entry window.
- The fill bar checks the stop but not the target, and ambiguous bars count as stops —
  which here also feeds the rearm, making the chart slightly stricter than the account.
- The entry limit lives for one bar and is allowed to expire unfilled about a third of
  the time. Not chasing is the edge, not a defect.

Full reasoning for each is in `AGENTS.md` under "Parity invariants".

## If you change a signal rule

The pass-rate numbers in `README.md` describe the code as published. Change a condition
and those numbers no longer apply — re-test over the same window or remove the claim.
Say so in your summary rather than leaving the README quietly wrong.
