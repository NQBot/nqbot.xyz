# Donchian Breakout — strategy + manual signal indicator (NinjaTrader 8)

Two files. One set of rules.

- **`Indicators/DonchianBreakoutFollow.cs`** — plots the channel, shows which directions
  are armed and what the 5-minute trend allows, prices the entry, stop and target, and
  places **no orders**. This is the one to use on a funded or evaluation account.
- **`Strategies/DonchianBreakoutUS.cs`** — the automated version, for simulation, Market
  Replay and your own capital. It does not contain a copy of the entry rules; it calls
  the indicator for them.

---

## The setup

1. **Break.** A bar closes beyond the highest high or lowest low of the previous
   **30 bars** (the current bar excluded).
2. **Trend.** The break is only taken in the direction the **5-minute** EMA stack
   already points: close above EMA(20), EMA(20) above EMA(50), and EMA(20) rising. The
   mirror image for shorts. Not enough 5-minute history means **no trade**, not a free
   pass.
3. **Volatility.** ATR(14) must be at least 5 points.
4. **Armed.** A stop-out disarms that direction until price trades back through the
   channel midpoint — see below, it matters.
5. **Entry.** A limit 25% of the trigger bar's range back inside it, live for one bar.
6. **Bracket.** Stop = 1.5 × ATR(14), clamped to 15–40 points. Target = stop × 2.
7. **Clock.** Window 09:30–15:30 ET. No new entry from 15:30, flat at 15:45.

### The rearm rule, and the one place this can drift

A stop-out doesn't just end a trade — it **disarms that direction** until price trades
back through the channel midpoint. The idea is that a failed break has to rebuild
genuine range structure before the next one counts.

That means the signal depends on the **outcome of the previous trade**, not just on
price. Nothing else in this series works that way, and it has a consequence worth
understanding:

> The indicator arms and disarms from its **own simulated fills**, and the strategy uses
> the indicator's state rather than its live fills, so the two always agree with each
> other. But if your real fill differs from the simulation — a rejected order, a
> partial, something you did by hand — your account's history and this chart's history
> have diverged, and so has what the chart will arm next.

The panel always shows the current state (`Armed  long yes   short NO`), so you can see
when a direction is sidelined and why.

---

## The honest record

These strategies ran in a simulated evaluation arena — one NinjaTrader sim account per
strategy, each playing out a $50,000 / +$3,000 target / $2,000 trailing-drawdown
evaluation over and over.

**US preset, 6 July – 18 September 2026: 24 attempts, 9 passed, 15 failed. 37.5%.**

Read that properly, and this one needs reading more carefully than most:

- **This is the weakest of the three strategies published here.** Trend Pullback B
  passed 45% of its attempts and VWAP Reclaim 46.2%. This passed 37.5%. Fifteen of
  twenty-four attempts ended at the drawdown limit.
- **The same code on the Asian session passed 1 of 17 attempts.** That variant is
  deliberately *not* included in this download. It is the clearest evidence in the whole
  roster that a session window is not a cosmetic setting: identical logic, different
  hours, near-total failure. If you move the window, you are not tuning — you are
  testing something new, and you should expect it to fail until it doesn't.
- **A pass rate is not an edge.** What produces passes is a modest geometric edge, hard
  discipline, and an account guard that stops the moment the target is banked.
- **Simulated fills, one instrument, one ten-week window.** NQ, 1-minute bars, sim
  account fills, no slippage stress, no audit.
- **The manual indicator did not produce that record** — the automated strategy did.

Past results do not predict future results. This is a tool, not a promise.

---

## What you need

| | |
|---|---|
| Platform | NinjaTrader 8 (8.1.x) |
| Instrument | NQ or MNQ — the stop floor and cap are written in NQ points |
| Chart | **1-minute**, ETH (24-hour) session template |
| Data | A **5-minute** series is added automatically; your data connection must be able to load it |
| Time zone | **US Eastern.** Tools → Options → General → Time zone. |
| Warmup | 32 bars on the primary series, plus ~55 five-minute bars before the trend gate will pass |

That last row is worth expecting: on a freshly loaded chart the trend gate fails closed
until the 5-minute series has enough history, so the panel will say
`5m trend mixed - nothing allowed` for a while. That is correct behaviour, not a fault.

---

## Install

1. NinjaTrader → **Control Center → Tools → Import → NinjaScript Add-On…**
2. Pick `DonchianBreakoutUS.zip`.
3. Restart NinjaTrader, or **Tools → New NinjaScript → Compile**.
4. The indicator appears under **PhillyFranksTools** in the indicator picker.

If the importer objects to the markdown files in the archive, extract it by hand and
copy the two `.cs` files into:

```
Documents\NinjaTrader 8\bin\Custom\Indicators\DonchianBreakoutFollow.cs
Documents\NinjaTrader 8\bin\Custom\Strategies\DonchianBreakoutUS.cs
```

then compile. **Both files must be present** — the strategy will not compile without
the indicator.

---

## Trading it by hand

Put `DonchianBreakoutFollow` on a 1-minute NQ chart and leave `Preset` on `US_Trend`.
The channel is plotted, and the panel tells you what is gating what:

```
DONCHIAN BREAKOUT - MANUAL FOLLOW
US trend-aligned (09:30-15:30 ET)
Clock 10:42   window 09:30-15:30
Channel 24271.25 - 24318.50   mid 24294.88
5m trend UP - longs allowed
Armed  long yes   short NO   regime Breakout (trend + expansion)
------------------------------------------
WATCHING - needs a close beyond the channel
Last: BREAKOUT SKIPPED - 5m trend not aligned
------------------------------------------
Setups filled today 2 / 99    target 1  stop 1
No new entry 15:30 ET  -  flat 15:45 ET
YOU place the orders. Nothing here trades.
```

When a break fires you get an arrow, a sound, and a dashed line at the limit price.

**The limit is live for one bar only.** Place it with a one-minute life, or cancel it at
the close of the next bar. Roughly a third of setups never come back to the limit and
are simply skipped — that is the design. The system refuses to chase the end of the bar
that broke the channel.

### Why a breakout system waits for a pullback

It looks contradictory: the channel breaks and the system asks price to come *back*.
That is deliberate. Entering at the close of the trigger bar means buying the extreme of
the move that fired the signal while carrying a stop that is often smaller than that bar
— 34% of trigger bars are 15 points or more. Measured over May–August 2026, entering at
the trigger close with a 15-point stop was stopped within five bars 37.8% of the time.
The limit gives back a quarter of the bar and declines the trade if price never returns.

### What the markers mean

| Marker | Meaning |
|---|---|
| Arrow up / down | Break fired on this bar's close |
| Dashed line | The limit price, live for one bar |
| Grey dot | Limit expired unfilled — stand down |
| Solid red / green lines | Stop and target once filled |
| Diamond | Simulated bracket resolved (green target, red stop, gold session flat) |

### Sounds

Three moments can be given a sound, each chosen from the sounds NinjaTrader ships with
(or `Custom`, which plays the file you name in **Custom sound file**). `None` means no
alert is raised for that event at all.

| Event | Default |
|---|---|
| Setup armed | `Alert1` |
| Limit filled | `None` |
| Limit expired | `None` |

**Enable alerts** is the master switch. The copy of this indicator that the strategy
runs internally never alerts, so you will not hear anything twice.

### Deliberately pessimistic

- On the bar the limit fills, **only the stop is checked**. Crediting a target on the
  fill bar is the single most common way a backtest reports profit it never made.
- After that, a bar that touches both the stop and the target is recorded as a **stop**.
- A gap through your limit is filled at the open, in your favour — that part is real.

Because a stop disarms a direction, that pessimism also makes the chart *slightly
stricter* than reality: a bar recorded as a stop that your real trade survived will
sideline that direction here when your account is still armed.

---

## Running the strategy

For simulation, Market Replay and accounts that are yours. Most funding companies do not
allow a fully automated strategy on an evaluation or funded account — check your own
contract, and when in doubt use the indicator.

### Account mode

Who enforces the account rules — the strategy, or your funding company. One setting with
three values, because Sim and Eval are mutually exclusive.

| Mode | Daily loss limit | Trailing drawdown | Profit target |
|---|---|---|---|
| **Sim** | strategy | strategy | strategy |
| **Eval** | *your provider* | strategy | strategy |
| **Off** | nobody | nobody | nobody |

**Sim** — nothing else is watching a simulation account, so the strategy enforces
everything. **Eval** — your provider already stops the account at its own daily loss
number, so the strategy does not duplicate it; it still stops at the profit target and
still converts the bracket into a resting limit to bank it. **Off** — no limits at all.

### Account guard settings

| Setting | Default | Notes |
|---|---|---|
| Account mode | Sim | Sim / Eval / Off, as above |
| Starting balance ($) | 50000 | Your account's starting balance |
| Profit target ($) | 3000 | Trading stops, terminally, when this is banked |
| Trailing drawdown ($) | 2000 | Threshold = highest end-of-day balance − this |
| Trailing locks at start balance | true | The common "stops trailing once it reaches your start" rule |
| Daily loss limit ($) | 950 | Sim only. **Set it below your provider's hard number**, not equal to it |
| Use target limit exit | true | Resting limit at the exact profit-target price |

The guard can only act on trades **it** placed. It cannot see or stop anything you do by
hand on the same account. It is not a substitute for reading your contract.

---

## Things you should know before relying on it

- **The 5-minute gate fails closed.** Not enough history means no trade. On a fresh
  chart, expect the panel to say nothing is allowed until the secondary series fills in.
- **The channel excludes the current bar.** It is the previous 30 bars' extremes, so the
  bar that breaks out is not part of what it breaks.
- **A news blackout also freezes the rearm.** During a blackout window the strategy
  returns before the rearm check, so a direction that was disarmed stays disarmed even
  if price crosses the midpoint. Reproduced exactly.
- **The session VWAP filter is off** in the published preset, and when it is on it
  accumulates across the whole session rather than only the entry window — unlike the
  VWAP Reclaim download, where the anchor is the window. Same words, different meaning.
- **Nothing in this package fails silently.** Anything that goes wrong prints to the
  NinjaScript Output window.

---

## Files

```
Indicators/DonchianBreakoutFollow.cs   the signal engine + manual display
Strategies/DonchianBreakoutUS.cs       order handling, account guard, clock rules
CLAUDE.md                              working notes for Claude Code
AGENTS.md                              working notes for any coding agent
LICENSE                                MIT
Info.xml                               NinjaTrader import descriptor
```

---

## License and disclaimer

MIT. See `LICENSE`. Use it, change it, ship it.

Futures trading involves substantial risk of loss and is not suitable for everyone. This
software is provided for education and research. It is not financial advice, it is not a
recommendation to trade anything, and its author is not a licensed advisor. Simulated
and past performance does not predict future results. You are responsible for every
order that reaches the market from your machine, and for knowing the rules of whatever
account you are trading.
