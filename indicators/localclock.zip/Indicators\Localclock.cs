#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
#endregion

public enum LocalClockTimeZone
{
    Local,
    UTC,
    Custom
}

namespace NinjaTrader.NinjaScript.Indicators.PhillyFranksTools
{
    /// <summary>
    /// PhillyFrank's Tools - Local Clock
    /// A professional-grade local clock indicator with multiple time zones, 
    /// flexible positioning, and customizable appearance options.
    /// 
    /// Features:
    /// - Multiple time zone support (Local, UTC, Custom)
    /// - Flexible positioning with alignment and pixel offsets
    /// - Customizable fonts, colors, and background styling
    /// - Real-time updates every second
    /// - Professional transparency controls
    /// 
    /// Created by: PhillyFrank
    /// Version: 1.0
    /// </summary>
    public class LocalClock : Indicator
    {
        private string clockText = "";
        private SharpDX.DirectWrite.TextFormat textFormat;
        private SharpDX.Direct2D1.SolidColorBrush textBrush;
        private SharpDX.Direct2D1.SolidColorBrush backgroundBrush;
        private DateTime lastUpdateTime;
        private System.Windows.Threading.DispatcherTimer uiTimer;
        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"PhillyFrank's Tools - Local Clock: Displays a customizable local clock with multiple time zones, positioning options, and appearance settings.";
                Name = "Local Clock";
                Calculate = Calculate.OnEachTick;
                IsOverlay = true;
                DisplayInDataBox = false;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = false;
                DrawVerticalGridLines = false;
                PaintPriceMarkers = false;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                IsSuspendedWhileInactive = false;
                
                // Default settings
                TimeZoneSelection = LocalClockTimeZone.Local;
                CustomTimeZoneId = "Eastern Standard Time";
                ShowSeconds = true;
                Use24HourFormat = false;
                ShowDate = false;
                DateFormat = "MM/dd/yyyy";
                HorizontalPosition = HorizontalAlignment.Right;
                VerticalPosition = VerticalAlignment.Top;
                HorizontalOffset = 10;
                VerticalOffset = 10;
                FontSize = 12;
                FontFamilyName = "Arial";
                TextColor = System.Windows.Media.Brushes.White;
                BackgroundColor = System.Windows.Media.Brushes.Black;
                BackgroundOpacity = 0.7;
                ShowBackground = true;
            }
            else if (State == State.Active)
            {
                // Initialize last update time
                lastUpdateTime = DateTime.MinValue;
            }
            else if (State == State.SetDefaults)
            {
                // This runs after State.Active when the chart is fully loaded
            }
            else if (State == State.Terminated)
            {
                // Clean up the timer
                if (uiTimer != null)
                {
                    uiTimer.Stop();
                    uiTimer = null;
                }
                
                // Clean up DirectX resources
                textFormat?.Dispose();
                textBrush?.Dispose();
                backgroundBrush?.Dispose();
            }
        }

        protected override void OnBarUpdate()
        {
            // This method can be empty now - timer handles updates
        }

        private void UpdateClockText()
        {
            DateTime currentTime = GetCurrentTime();
            
            string timeFormat = "";
            if (Use24HourFormat)
            {
                timeFormat = ShowSeconds ? "HH:mm:ss" : "HH:mm";
            }
            else
            {
                timeFormat = ShowSeconds ? "hh:mm:ss tt" : "hh:mm tt";
            }
            
            clockText = currentTime.ToString(timeFormat);
            
            if (ShowDate)
            {
                clockText = currentTime.ToString(DateFormat) + "\n" + clockText;
            }
        }

        private DateTime GetCurrentTime()
        {
            DateTime now = DateTime.Now;
            
            switch (TimeZoneSelection)
            {
                case LocalClockTimeZone.Local:
                    return now;
                    
                case LocalClockTimeZone.UTC:
                    return DateTime.UtcNow;
                    
                case LocalClockTimeZone.Custom:
                    try
                    {
                        TimeZoneInfo customTimeZone = TimeZoneInfo.FindSystemTimeZoneById(CustomTimeZoneId);
                        return TimeZoneInfo.ConvertTime(DateTime.UtcNow, customTimeZone);
                    }
                    catch
                    {
                        return now; // Fallback to local time if custom timezone fails
                    }
                    
                default:
                    return now;
            }
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            // Start the timer on first render if not already started
            if (uiTimer == null && ChartControl != null)
            {
                uiTimer = new System.Windows.Threading.DispatcherTimer(System.Windows.Threading.DispatcherPriority.Background);
                uiTimer.Interval = TimeSpan.FromSeconds(1);
                uiTimer.Tick += (s, e) => 
                {
                    if (ChartControl != null && !ChartControl.Dispatcher.CheckAccess())
                        return;
                    try 
                    { 
                        ChartControl?.InvalidateVisual(); 
                    } 
                    catch { }
                };
                uiTimer.Start();
            }
            
            // Always update the clock text on every render
            UpdateClockText();

            // Create DirectX resources if needed
            if (textFormat == null)
            {
                textFormat = new SharpDX.DirectWrite.TextFormat(
                    Core.Globals.DirectWriteFactory,
                    FontFamilyName,
                    (float)FontSize);
            }

            if (textBrush == null || textBrush.IsDisposed)
            {
                var wpfTextBrush = TextColor as System.Windows.Media.SolidColorBrush;
                textBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, 
                    new SharpDX.Color4(wpfTextBrush.Color.R / 255f,
                                       wpfTextBrush.Color.G / 255f,
                                       wpfTextBrush.Color.B / 255f,
                                       wpfTextBrush.Color.A / 255f));
            }

            if (ShowBackground && (backgroundBrush == null || backgroundBrush.IsDisposed))
            {
                var wpfBackgroundBrush = BackgroundColor as System.Windows.Media.SolidColorBrush;
                if (wpfBackgroundBrush != null)
                {
                    backgroundBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget,
                        new SharpDX.Color4(wpfBackgroundBrush.Color.R / 255f,
                                           wpfBackgroundBrush.Color.G / 255f,
                                           wpfBackgroundBrush.Color.B / 255f,
                                           (float)BackgroundOpacity));
                }
            }

            // Measure text
            var textLayout = new SharpDX.DirectWrite.TextLayout(
                Core.Globals.DirectWriteFactory,
                clockText,
                textFormat,
                ChartPanel.W,
                ChartPanel.H);

            float textWidth = textLayout.Metrics.Width;
            float textHeight = textLayout.Metrics.Height;

            // Calculate position based on alignment settings
            float x = 0;
            float y = 0;
            
            switch (HorizontalPosition)
            {
                case HorizontalAlignment.Left:
                    x = HorizontalOffset;
                    break;
                case HorizontalAlignment.Center:
                    x = (ChartPanel.W - textWidth) / 2 + HorizontalOffset;
                    break;
                case HorizontalAlignment.Right:
                    x = ChartPanel.W - textWidth - HorizontalOffset;
                    break;
            }
            
            switch (VerticalPosition)
            {
                case VerticalAlignment.Top:
                    y = VerticalOffset;
                    break;
                case VerticalAlignment.Center:
                    y = (ChartPanel.H - textHeight) / 2 + VerticalOffset;
                    break;
                case VerticalAlignment.Bottom:
                    y = ChartPanel.H - textHeight - VerticalOffset;
                    break;
            }

            // Draw background if enabled and brush exists
            if (ShowBackground && backgroundBrush != null && BackgroundOpacity > 0)
            {
                var backgroundRect = new SharpDX.RectangleF(x - 5, y - 2, textWidth + 10, textHeight + 4);
                RenderTarget.FillRectangle(backgroundRect, backgroundBrush);
            }

            // Draw the text
            RenderTarget.DrawTextLayout(new SharpDX.Vector2(x, y), textLayout, textBrush);
            
            textLayout.Dispose();
        }

        #region Properties
        
        [NinjaScriptProperty]
        [Display(Name = "Time Zone", Description = "Select the time zone to display", Order = 1, GroupName = "Time Settings")]
        public LocalClockTimeZone TimeZoneSelection { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Custom Time Zone ID", Description = "Time zone ID when using Custom option (e.g., 'Eastern Standard Time', 'Pacific Standard Time')", Order = 2, GroupName = "Time Settings")]
        public string CustomTimeZoneId { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Seconds", Description = "Display seconds in the time", Order = 3, GroupName = "Time Settings")]
        public bool ShowSeconds { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "24-Hour Format", Description = "Use 24-hour time format instead of 12-hour", Order = 4, GroupName = "Time Settings")]
        public bool Use24HourFormat { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Date", Description = "Display the date above the time", Order = 5, GroupName = "Time Settings")]
        public bool ShowDate { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Date Format", Description = "Date format string (e.g., MM/dd/yyyy, dd/MM/yyyy)", Order = 6, GroupName = "Time Settings")]
        public string DateFormat { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Horizontal Position", Description = "Horizontal alignment of the clock", Order = 1, GroupName = "Position")]
        public HorizontalAlignment HorizontalPosition { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Vertical Position", Description = "Vertical alignment of the clock", Order = 2, GroupName = "Position")]
        public VerticalAlignment VerticalPosition { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Horizontal Offset", Description = "Horizontal offset in pixels", Order = 3, GroupName = "Position")]
        public int HorizontalOffset { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Vertical Offset", Description = "Vertical offset in pixels", Order = 4, GroupName = "Position")]
        public int VerticalOffset { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Font Size", Description = "Size of the clock text", Order = 1, GroupName = "Appearance")]
        public double FontSize { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Font Family", Description = "Font family name for the clock text (e.g., Arial, Times New Roman)", Order = 2, GroupName = "Appearance")]
        public string FontFamilyName { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Text Color", Description = "Color of the clock text", Order = 3, GroupName = "Appearance")]
        public System.Windows.Media.Brush TextColor { get; set; }

        [Browsable(false)]
        public string TextColorSerializable
        {
            get { return Serialize.BrushToString(TextColor); }
            set { TextColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [Display(Name = "Show Background", Description = "Show background behind the clock", Order = 4, GroupName = "Appearance")]
        public bool ShowBackground { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Background Color", Description = "Background color of the clock", Order = 5, GroupName = "Appearance")]
        public System.Windows.Media.Brush BackgroundColor { get; set; }

        [Browsable(false)]
        public string BackgroundColorSerializable
        {
            get { return Serialize.BrushToString(BackgroundColor); }
            set { BackgroundColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [Range(0.0, 1.0)]
        [Display(Name = "Background Opacity", Description = "Opacity of the background (0.0 = transparent, 1.0 = opaque)", Order = 6, GroupName = "Appearance")]
        public double BackgroundOpacity { get; set; }

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PhillyFranksTools.LocalClock[] cacheLocalClock;
		public PhillyFranksTools.LocalClock LocalClock(LocalClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, HorizontalAlignment horizontalPosition, VerticalAlignment verticalPosition, int horizontalOffset, int verticalOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			return LocalClock(Input, timeZoneSelection, customTimeZoneId, showSeconds, use24HourFormat, showDate, dateFormat, horizontalPosition, verticalPosition, horizontalOffset, verticalOffset, fontSize, fontFamilyName, textColor, showBackground, backgroundColor, backgroundOpacity);
		}

		public PhillyFranksTools.LocalClock LocalClock(ISeries<double> input, LocalClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, HorizontalAlignment horizontalPosition, VerticalAlignment verticalPosition, int horizontalOffset, int verticalOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			if (cacheLocalClock != null)
				for (int idx = 0; idx < cacheLocalClock.Length; idx++)
					if (cacheLocalClock[idx] != null && cacheLocalClock[idx].TimeZoneSelection == timeZoneSelection && cacheLocalClock[idx].CustomTimeZoneId == customTimeZoneId && cacheLocalClock[idx].ShowSeconds == showSeconds && cacheLocalClock[idx].Use24HourFormat == use24HourFormat && cacheLocalClock[idx].ShowDate == showDate && cacheLocalClock[idx].DateFormat == dateFormat && cacheLocalClock[idx].HorizontalPosition == horizontalPosition && cacheLocalClock[idx].VerticalPosition == verticalPosition && cacheLocalClock[idx].HorizontalOffset == horizontalOffset && cacheLocalClock[idx].VerticalOffset == verticalOffset && cacheLocalClock[idx].FontSize == fontSize && cacheLocalClock[idx].FontFamilyName == fontFamilyName && cacheLocalClock[idx].TextColor == textColor && cacheLocalClock[idx].ShowBackground == showBackground && cacheLocalClock[idx].BackgroundColor == backgroundColor && cacheLocalClock[idx].BackgroundOpacity == backgroundOpacity && cacheLocalClock[idx].EqualsInput(input))
						return cacheLocalClock[idx];
			return CacheIndicator<PhillyFranksTools.LocalClock>(new PhillyFranksTools.LocalClock(){ TimeZoneSelection = timeZoneSelection, CustomTimeZoneId = customTimeZoneId, ShowSeconds = showSeconds, Use24HourFormat = use24HourFormat, ShowDate = showDate, DateFormat = dateFormat, HorizontalPosition = horizontalPosition, VerticalPosition = verticalPosition, HorizontalOffset = horizontalOffset, VerticalOffset = verticalOffset, FontSize = fontSize, FontFamilyName = fontFamilyName, TextColor = textColor, ShowBackground = showBackground, BackgroundColor = backgroundColor, BackgroundOpacity = backgroundOpacity }, input, ref cacheLocalClock);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PhillyFranksTools.LocalClock LocalClock(LocalClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, HorizontalAlignment horizontalPosition, VerticalAlignment verticalPosition, int horizontalOffset, int verticalOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			return indicator.LocalClock(Input, timeZoneSelection, customTimeZoneId, showSeconds, use24HourFormat, showDate, dateFormat, horizontalPosition, verticalPosition, horizontalOffset, verticalOffset, fontSize, fontFamilyName, textColor, showBackground, backgroundColor, backgroundOpacity);
		}

		public Indicators.PhillyFranksTools.LocalClock LocalClock(ISeries<double> input , LocalClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, HorizontalAlignment horizontalPosition, VerticalAlignment verticalPosition, int horizontalOffset, int verticalOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			return indicator.LocalClock(input, timeZoneSelection, customTimeZoneId, showSeconds, use24HourFormat, showDate, dateFormat, horizontalPosition, verticalPosition, horizontalOffset, verticalOffset, fontSize, fontFamilyName, textColor, showBackground, backgroundColor, backgroundOpacity);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PhillyFranksTools.LocalClock LocalClock(LocalClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, HorizontalAlignment horizontalPosition, VerticalAlignment verticalPosition, int horizontalOffset, int verticalOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			return indicator.LocalClock(Input, timeZoneSelection, customTimeZoneId, showSeconds, use24HourFormat, showDate, dateFormat, horizontalPosition, verticalPosition, horizontalOffset, verticalOffset, fontSize, fontFamilyName, textColor, showBackground, backgroundColor, backgroundOpacity);
		}

		public Indicators.PhillyFranksTools.LocalClock LocalClock(ISeries<double> input , LocalClockTimeZone timeZoneSelection, string customTimeZoneId, bool showSeconds, bool use24HourFormat, bool showDate, string dateFormat, HorizontalAlignment horizontalPosition, VerticalAlignment verticalPosition, int horizontalOffset, int verticalOffset, double fontSize, string fontFamilyName, System.Windows.Media.Brush textColor, bool showBackground, System.Windows.Media.Brush backgroundColor, double backgroundOpacity)
		{
			return indicator.LocalClock(input, timeZoneSelection, customTimeZoneId, showSeconds, use24HourFormat, showDate, dateFormat, horizontalPosition, verticalPosition, horizontalOffset, verticalOffset, fontSize, fontFamilyName, textColor, showBackground, backgroundColor, backgroundOpacity);
		}
	}
}

#endregion
