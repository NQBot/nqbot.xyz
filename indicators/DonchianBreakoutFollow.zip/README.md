# Donchian Breakout Follow - manual signal indicator (NinjaTrader 8)

One file. It plots a 30-bar channel, marks a breakout that agrees with the 5-minute trend,
prices the entry, the stop and the target, and sounds an alert. **It places no orders. You do.**

There is no strategy in this download and nothing in it trades for you. That is on
purpose: most funding companies do not allow automated trading on an evaluation or funded
account, and an indicator you act on by hand is a different thing from a robot. Read your
own contract; the rule is theirs to change.

---

## Read this first

- **No edge is claimed.** This is a defined rule set you can watch work and judge for
  yourself. Our own tests over years of 1-minute NQ data did not find a reliable edge in
  it, and nothing here says it makes money.
- **Its history is simulated.** These rules once ran as an automated strategy in a
  simulated evaluation arena that is now closed. Those results are on the website's Eval
  Arena page. They are simulated, they are not a track record, and the strategy is no
  longer distributed. The same logic run on the Asian session instead of the US one did
  far worse there, which is why the window is part of the rules.
- **The simulated outcomes the indicator draws** (the diamonds, the open points) are a
  model of what the rules would have done, not a record of any trade anyone took.
- **You are responsible for every order you place**, and for the rules of the account you
  place it on.

---

## The setup, in plain English

1. **Channel.** The highest high and lowest low of the **previous 30 bars**. The current bar
   is not part of the channel it breaks.
2. **Trend gate.** Only in the direction the **5-minute** EMA stack already points (EMA 20
   against EMA 50, with the fast EMA sloping the same way). A break against that is skipped,
   and the panel says so.
3. **Trigger.** A bar closes beyond the channel, with ATR(14) at least 5.
4. **Entry.** A limit 25% of the trigger bar's range back inside that bar. **It is live for
   one bar only.** A breakout system asking price to come back is deliberate: entering at the
   close of the trigger bar means buying the extreme of the move while carrying a stop that
   is often smaller than that bar.
5. **Bracket.** Stop = 1.5 x ATR(14), never tighter than 15 points and never wider than 40.
   Target = the stop scaled to 2R, capped at 3R.
6. **Rearm.** A stop-out **disarms that direction** until price trades back through the
   channel midpoint. So the next signal depends on how the last trade ended, not only on price.
7. **Clock.** Nothing new is priced from 15:30 ET, and a followed trade still open at 15:45 ET
   is closed in the simulation.

| Preset | Window (ET) |
|---|---|
| US_Trend (default) | 09:30-15:30 |
| Custom | yours |

If you move the window you are not tuning, you are testing something new.

---

## What you need

| | |
|---|---|
| Platform | NinjaTrader 8 (8.1.x) |
| Instrument | NQ or MNQ. The stop floor and cap are written in NQ points |
| Chart | **1-minute**, ETH (24-hour) session template |
| Data | A **5-minute** series is added automatically; your data connection must be able to load it |
| Time zone | **US Eastern**: Tools > Options > General > Time zone |
| Warmup | 32 bars on the 1-minute series, plus about 55 five-minute bars before the trend gate passes |

On a freshly loaded chart the trend gate **fails closed**: until the 5-minute series has
enough history the panel says `5m trend mixed - nothing allowed`. That is correct
behaviour, not a fault.

---

## Install

1. Control Center > **Tools > Import > NinjaScript Add-On...** and pick `DonchianBreakoutFollow.zip`.
2. Restart NinjaTrader, or **Tools > New NinjaScript > Compile**.
3. Add **DonchianBreakoutFollow** to a 1-minute NQ chart (it is listed under PhillyFranksTools).

If the importer objects to the extra files in the archive, extract the zip by hand and
copy `Indicators\DonchianBreakoutFollow.cs` into
`Documents\NinjaTrader 8\bin\Custom\Indicators\`, then compile.

---

## Trading it by hand

The channel is plotted and the panel tells you what is gating what:

```
DONCHIAN BREAKOUT - MANUAL FOLLOW
US trend-aligned (09:30-15:30 ET)
Clock 10:42   window 09:30-15:30
Channel 24271.25 - 24318.50   mid 24294.88
5m trend UP - longs allowed
Armed  long yes   short NO   regime Breakout (trend + expansion)
------------------------------------------
WATCHING - needs a close beyond the channel
Last: BREAKOUT SKIPPED - 5m trend not aligned
------------------------------------------
Setups filled today 2 / 99    target 1  stop loss 1
YOU place the orders. Nothing here trades.
```

When a break fires you get an arrow, a sound and a dashed line at the limit price, and the
panel switches to the numbers you place (limit, stop loss, target, risk per contract).

**The limit is live for one bar.** Place it as a limit order with a one-minute life, or
cancel it at the close of the next bar. Often a third or more of setups never come back to
the limit and are simply skipped. That is the design, not a missed trade.

| Marker | Meaning |
|---|---|
| Arrow up / down | Break fired on this bar's close |
| Dashed line | The limit price, live for one bar |
| Grey dot | Limit expired unfilled: stand down |
| Solid red / green lines | Stop and target once filled |
| Diamond | Simulated bracket resolved (green target, red stop, gold session flat) |

### Sounds

Three moments can have a sound, picked from the sounds NinjaTrader ships with (or `Custom`,
which plays the file named in **Custom sound file**). `None` raises no alert for that event
at all. **Enable alerts** is the master switch.

| Event | Default |
|---|---|
| Setup armed | `Alert1` |
| Limit filled | `None` |
| Limit expired | `None` |

### Deliberately pessimistic tracking

- On the bar the limit fills, **only the stop is checked**.
- After that, a bar that touches both stop and target is recorded as a **stop**.
- A gap through your limit fills at the open, in your favour.

Because a stop disarms a direction, this pessimism also makes the chart slightly stricter
than reality: a bar recorded as a stop that your real trade survived will sideline that
direction on the chart.

### The one place the chart can drift from your account

The chart arms and disarms from its **own simulated fills**. If your real fill differs from
the simulation (a rejected order, a partial, something you did by hand), your account's
history and the chart's have parted company, and so has what the chart arms next. The panel
always shows the current state (`Armed  long yes   short NO`), so you can see when a direction
is sidelined and why.

---

## Settings

| Group | What is in it |
|---|---|
| 1. Setup | Preset, Show visuals |
| 2. Custom rules | Used only with the Custom preset: channel period, buffer beyond the channel, ATR and ADX minimums, session VWAP alignment, the 5-minute trend gate and its EMA periods and slope bars, rearm at the midpoint, stop and target points, session start and end |
| 3. Filters | Max setups per session (default 99), avoid lunch chop (12:00-13:00), your own news blackout windows |
| 4. Display | Panel on/off, corner, size and offsets, label size, plot the channel, risk per trade (shows how many contracts that budget buys; sizing stays your decision), hide the panel outside the session, and "Show 'you place the orders' line" |
| 5. Alerts | Master switch, the three sounds, custom sound file |
| 6. Colors | Long, short, stop, target, panel text and background |

---

## Things you should know

- **The 5-minute gate fails closed.** Not enough history means no setup.
- **Everything evaluates on bar close.** If you change `Calculate`, the indicator forces it
  back to `OnBarClose`.
- **The news blackout is empty and manual.** Nothing is downloaded or guessed.
- **Failures print to the NinjaScript Output window** (Control Center > New > NinjaScript
  Output). Look there first.

### Optional call log (off by default)

If you create a text file named `NQBotFollowerCallLog.txt` in `Documents\NinjaTrader 8` and
put a folder path on its first line, the indicator appends one JSON line per call (setup,
fill, exit, alert) to `DonchianBreakoutFollow_calls_<day>.jsonl` in that folder, in realtime
only. Without the file nothing is written. The indicator makes no network calls.

---

## Files

```
Indicators/DonchianBreakoutFollow.cs   the signal engine and the manual display
LICENSE                                MIT
Info.xml                               NinjaTrader import descriptor
```

---

## Risk, licence, and what this is not

MIT licence. See `LICENSE`. Use it, change it, share it. If you modify it to place orders
automatically, that is your choice and your risk, and it may breach your funding agreement.

**These are trade signals.** The indicator tells you a direction, an entry price, a stop and
a target. Treat that with the seriousness it deserves, even though it sends no order.

**Nothing here is financial advice.** The author is not a registered investment adviser,
commodity trading advisor or broker, and nothing in this package is a recommendation to buy
or sell anything or a solicitation to trade. It is published for education and research.
Trading futures carries a substantial risk of loss, is not suitable for every investor, and
you can lose more than you deposit. Simulated performance especially does not indicate
future results.

**Test it in simulation first, for long enough to watch it lose**, and never trade money you
cannot afford to lose.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND. See `LICENSE`.
