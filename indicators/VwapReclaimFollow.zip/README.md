# VWAP Reclaim Follow - manual signal indicator (NinjaTrader 8)

One file. It watches price leave the session VWAP and take it back, marks the reclaim,
prices the entry, the stop and the target, and sounds an alert. **It places no orders. You do.**

There is no strategy in this download and nothing in it trades for you. That is on
purpose: most funding companies do not allow automated trading on an evaluation or funded
account, and an indicator you act on by hand is a different thing from a robot. Read your
own contract; the rule is theirs to change.

---

## Read this first

- **No edge is claimed.** This is a defined rule set you can watch work and judge for
  yourself. Our own tests over years of 1-minute NQ data did not find a reliable edge in
  it, and nothing here says it makes money.
- **Its history is simulated.** These rules once ran as an automated strategy in a
  simulated evaluation arena that is now closed. Those results are on the website's Eval
  Arena page. They are simulated, they are not a track record, and the strategy is no
  longer distributed.
- **The simulated outcomes the indicator draws** (the diamonds, the open points) are a
  model of what the rules would have done, not a record of any trade anyone took.
- **You are responsible for every order you place**, and for the rules of the account you
  place it on.

---

## The setup, in plain English

1. **Break.** A bar closes at least **5 points** clear of the session VWAP.
2. **Reclaim.** Within **30 bars**, a bar closes back through the VWAP by at least **3 points**.
3. **Entry.** In the direction of the reclaim: a limit 25% of the trigger bar's range back
   inside that bar. **It is live for one bar only.**
4. **Bracket.** Stop = 1.5 x ATR(14), never tighter than 15 points and never wider than 40.
   Target = the stop scaled to 2R, capped at 3R.
5. **Clock.** Nothing new is priced from 15:30 ET, and a followed trade still open at 15:45 ET
   is closed in the simulation.

### Presets

| Preset | Window (ET) | ATR(14) gate |
|---|---|---|
| Asian_NoAtrFilter (default) | 20:00-01:30 | none |
| US_AtrBand | 09:30-15:30 | at least 15 and under 30 |
| Custom | yours | yours |

The Asian preset has **no ATR gate** on purpose: Asian ATR runs low, and a floor derived on
US data rejected most Asian signals. The US preset keeps the band: under 15 the move is too
small to pay for the stop, and at 30 and above stops come fast. On the US preset a reclaim
rejected on ATR **still uses up the break**, and the panel tells you when that happens.

A window is not a cosmetic setting: the same rules on different hours are a different test.
A tuned Custom setup is your configuration, not a published one.

---

## What you need

| | |
|---|---|
| Platform | NinjaTrader 8 (8.1.x) |
| Instrument | NQ or MNQ. The stop floor and cap are written in NQ points |
| Chart | **1-minute**, ETH (24-hour) session template |
| Time zone | **US Eastern**: Tools > Options > General > Time zone |
| Warmup | Give ATR(14) a few hundred bars to settle |

**The ETH template matters more here than for most indicators.** The VWAP resets on the first
bar of the session, so a different session template moves the anchor and changes every
signal. It is a window-anchored VWAP, not a 24-hour one, and it will not match a standard
VWAP indicator. That is deliberate. The indicator plots the VWAP it measures against.

---

## Install

1. Control Center > **Tools > Import > NinjaScript Add-On...** and pick `VwapReclaimFollow.zip`.
2. Restart NinjaTrader, or **Tools > New NinjaScript > Compile**.
3. Add **VwapReclaimFollow** to a 1-minute NQ chart (it is listed under PhillyFranksTools).

If the importer objects to the extra files in the archive, extract the zip by hand and
copy `Indicators\VwapReclaimFollow.cs` into
`Documents\NinjaTrader 8\bin\Custom\Indicators\`, then compile.

---

## Trading it by hand

The panel walks the state machine with you, so you are never guessing what it wants:

```
VWAP RECLAIM - MANUAL FOLLOW
Asian, no ATR filter (20:00-01:30 ET)
Clock 21:14   window 20:00-01:30
VWAP anchored 8pm 24288.50   regime Quiet trend
------------------------------------------
BROKE BELOW VWAP anchored 8pm
Reclaim above 24291.50 for a LONG
Bars left 21
------------------------------------------
Setups filled today 1 / 99    target 1  stop loss 0
YOU place the orders. Nothing here trades.
```

When the reclaim fires you get an arrow, a sound and a dashed line at the limit price, and
the panel switches to the numbers you place:

```
WORKING LIMIT - LONG
Valid for THIS BAR ONLY
Limit     24294.25
Stop loss 24276.00   (18.25 pts)
Target    24330.75   (36.5 pts)
Risk      $365 per contract
```

**The limit is live for one bar.** Place it as a limit order with a one-minute life, or
cancel it at the close of the next bar. Often a third or more of setups never come back to
the limit and are simply skipped. Not chasing the bar that triggered it is the design.

| Marker | Meaning |
|---|---|
| Arrow up / down | Reclaim fired on this bar's close |
| Dashed line | The limit price, live for one bar |
| Grey dot | Limit expired unfilled: stand down |
| Solid red / green lines | Stop and target once filled |
| Diamond | Simulated bracket resolved (green target, red stop, gold session flat) |

### Sounds

Four moments can have a sound, picked from the sounds NinjaTrader ships with (or `Custom`,
which plays the file named in **Custom sound file**). `None` raises no alert for that event
at all. **Enable alerts** is the master switch.

| Event | Default | Why |
|---|---|---|
| VWAP broken | `None` | Heads-up: a reclaim is now possible |
| Setup armed | `Alert1` | The limit is live and you have one bar to place it |
| Limit filled | `None` | Price reached the limit |
| Limit expired | `None` | It lapsed unfilled: cancel and stand down |

### Deliberately pessimistic tracking

- On the bar the limit fills, **only the stop is checked**.
- After that, a bar that touches both stop and target is recorded as a **stop**.
- A gap through your limit fills at the open, in your favour.

---

## Settings

| Group | What is in it |
|---|---|
| 1. Setup | Preset, Show visuals |
| 2. Custom rules | Used only with the Custom preset: minimum break and reclaim points, bars allowed to reclaim, ATR(14) min and max, stop and target points, session start and end |
| 3. Filters | Max setups per session (default 99), avoid lunch chop (12:00-13:00), your own news blackout windows |
| 4. Display | Panel on/off, corner, size and offsets, label size, plot the session VWAP, risk per trade (shows how many contracts that budget buys; sizing stays your decision), hide the panel outside the session, and "Show 'you place the orders' line" |
| 5. Alerts | Master switch, the four sounds, custom sound file |
| 6. Colors | Long, short, stop, target, panel text and background |

---

## Things you should know

- **Everything evaluates on bar close.** If you change `Calculate`, the indicator forces it
  back to `OnBarClose`, because an intrabar version would show setups that vanish.
- **The news blackout is empty and manual.** Nothing is downloaded or guessed.
- **Failures print to the NinjaScript Output window** (Control Center > New > NinjaScript
  Output). Look there first.

### Optional call log (off by default)

If you create a text file named `NQBotFollowerCallLog.txt` in `Documents\NinjaTrader 8` and
put a folder path on its first line, the indicator appends one JSON line per call (setup,
fill, exit, alert) to `VwapReclaimFollow_calls_<day>.jsonl` in that folder, in realtime
only. Without the file nothing is written. The indicator makes no network calls.

---

## Files

```
Indicators/VwapReclaimFollow.cs   the signal engine and the manual display
LICENSE                           MIT
Info.xml                          NinjaTrader import descriptor
```

---

## Risk, licence, and what this is not

MIT licence. See `LICENSE`. Use it, change it, share it. If you modify it to place orders
automatically, that is your choice and your risk, and it may breach your funding agreement.

**These are trade signals.** The indicator tells you a direction, an entry price, a stop and
a target. Treat that with the seriousness it deserves, even though it sends no order.

**Nothing here is financial advice.** The author is not a registered investment adviser,
commodity trading advisor or broker, and nothing in this package is a recommendation to buy
or sell anything or a solicitation to trade. It is published for education and research.
Trading futures carries a substantial risk of loss, is not suitable for every investor, and
you can lose more than you deposit. Simulated performance especially does not indicate
future results.

**Test it in simulation first, for long enough to watch it lose**, and never trade money you
cannot afford to lose.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND. See `LICENSE`.
