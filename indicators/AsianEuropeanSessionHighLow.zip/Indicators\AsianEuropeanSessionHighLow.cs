#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.PhillyFranksTools
{
    public class AsianEuropeanSessionHighLow : Indicator
    {
        #region Variables
        private DateTime currentDate;
        private DateTime lastProcessedBar;
        
        // Asian session tracking
        private double asianHigh;
        private double asianLow;
        private int asianHighBar;
        private int asianLowBar;
        private int asianSessionStartBar;
        private bool asianSessionActive;
        private bool asianSessionComplete;
        
        // European session tracking
        private double europeanHigh;
        private double europeanLow;
        private int europeanHighBar;
        private int europeanLowBar;
        private int europeanSessionStartBar;
        private bool europeanSessionActive;
        private bool europeanSessionComplete;
        
        // Line tags for management
        private string asianHighLineTag;
        private string asianLowLineTag;
        private string asianHighLineSolidTag;
        private string asianLowLineSolidTag;
        private string europeanHighLineTag;
        private string europeanLowLineTag;
        private string europeanHighLineSolidTag;
        private string europeanLowLineSolidTag;
        #endregion
        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Plots horizontal lines showing the high and low of Asian and European trading sessions";
                Name = "AsianEuropeanSessionHighLow";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                IsSuspendedWhileInactive = true;
                
                // Asian session properties
                ShowAsianSession = true;
                AsianHighColor = Brushes.Yellow;
                AsianLowColor = Brushes.Orange;
                AsianLineStyle = DashStyleHelper.Solid;
                AsianLineWidth = 2;
                
                // European session properties
                ShowEuropeanSession = true;
                EuropeanHighColor = Brushes.Cyan;
                EuropeanLowColor = Brushes.DeepSkyBlue;
                EuropeanLineStyle = DashStyleHelper.Solid;
                EuropeanLineWidth = 2;
                
                // Label properties
                ShowLabels = true;
                LabelFont = new SimpleFont("Arial", 10);
                LabelOffset = 20;
                AsianLabelTrailingBars = 10;
                EuropeanLabelTrailingBars = 10;
            }
            else if (State == State.Configure)
            {
            }
            else if (State == State.DataLoaded)
            {
                ResetSessionVariables();
            }
        }
        
        protected override void OnBarUpdate()
        {
            if (CurrentBar < 1) return;
            
           // Skip weekends - but allow Sunday evening after 5 PM ET (start of Monday trading)
			DateTime easternTimeCheck = TimeZoneInfo.ConvertTime(Time[0], TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"));
			if (Time[0].DayOfWeek == DayOfWeek.Saturday)
    		return;
			if (Time[0].DayOfWeek == DayOfWeek.Sunday && easternTimeCheck.Hour < 17)
    		return;
            
            // Get current time in Eastern Time
            DateTime easternTime = TimeZoneInfo.ConvertTime(Time[0], TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"));
            TimeSpan currentTimeOfDay = easternTime.TimeOfDay;
            
            // Initialize currentDate on first run
            if (currentDate == DateTime.MinValue)
            {
                currentDate = easternTime.Date;
                if (easternTime.Hour < 17)
                    currentDate = currentDate.AddDays(-1); // We're still in yesterday's trading day
            }
            
            // Check if we're on a new trading day (reset at 5:00 PM ET)
            bool newTradingDay = false;
            if (easternTime.Hour >= 17 && lastProcessedBar.Hour < 17 && easternTime.Date == lastProcessedBar.Date)
            {
                // Crossed 5 PM on the same calendar day
                currentDate = easternTime.Date;
                newTradingDay = true;
            }
            else if (easternTime.Date > lastProcessedBar.Date && easternTime.Hour < 17)
            {
                // New calendar day but before 5 PM (still previous trading day)
                // Don't reset
            }
            else if (easternTime.Date > currentDate.AddDays(1))
            {
                // We've skipped days (weekend/holiday)
                currentDate = easternTime.Date;
                if (easternTime.Hour < 17)
                    currentDate = currentDate.AddDays(-1);
                newTradingDay = true;
            }
            
            if (newTradingDay)
            {
                ResetSessionVariables();
                // Don't remove old lines - let them stay on the chart
            }
            
            lastProcessedBar = easternTime;
            
            // Define session times
            TimeSpan asianStart = new TimeSpan(19, 0, 0);    // 7:00 PM
            TimeSpan asianEnd = new TimeSpan(3, 0, 0);      // 3:00 AM next day
            TimeSpan europeanStart = new TimeSpan(3, 0, 0);  // 3:00 AM
            TimeSpan europeanEnd = new TimeSpan(8, 0, 0);    // 8:00 AM
            
            // Handle Asian session (crosses midnight)
            if (ShowAsianSession)
            {
                bool inAsianSession = currentTimeOfDay >= asianStart || currentTimeOfDay < asianEnd;
                
                if (inAsianSession && !asianSessionComplete)
                {
                    if (!asianSessionActive)
                    {
                        // Start of Asian session
                        asianSessionActive = true;
                        asianHigh = High[0];
                        asianLow = Low[0];
                        asianHighBar = CurrentBar;
                        asianLowBar = CurrentBar;
                        asianSessionStartBar = CurrentBar;
                    }
                    else
                    {
                        // Update Asian session high/low
                        if (High[0] > asianHigh)
                        {
                            asianHigh = High[0];
                            asianHighBar = CurrentBar;
                        }
                        if (Low[0] < asianLow)
                        {
                            asianLow = Low[0];
                            asianLowBar = CurrentBar;
                        }
                    }
                    
                    // Draw/update lines in real-time
                    DrawAsianSessionLines();
                }
                else if (!inAsianSession && asianSessionActive && !asianSessionComplete && currentTimeOfDay >= asianEnd && currentTimeOfDay < asianStart)
                {
                    // End of Asian session - finalize lines
                    asianSessionActive = false;
                    asianSessionComplete = true;
                    DrawAsianSessionLines();
                }
            }
            
            // Handle European session
            if (ShowEuropeanSession)
            {
                bool inEuropeanSession = currentTimeOfDay >= europeanStart && currentTimeOfDay < europeanEnd;
                
                if (inEuropeanSession && !europeanSessionComplete)
                {
                    if (!europeanSessionActive)
                    {
                        // Start of European session
                        europeanSessionActive = true;
                        europeanHigh = High[0];
                        europeanLow = Low[0];
                        europeanHighBar = CurrentBar;
                        europeanLowBar = CurrentBar;
                        europeanSessionStartBar = CurrentBar;
                    }
                    else
                    {
                        // Update European session high/low
                        if (High[0] > europeanHigh)
                        {
                            europeanHigh = High[0];
                            europeanHighBar = CurrentBar;
                        }
                        if (Low[0] < europeanLow)
                        {
                            europeanLow = Low[0];
                            europeanLowBar = CurrentBar;
                        }
                    }
                    
                    // Draw/update lines in real-time
                    DrawEuropeanSessionLines();
                }
                else if (!inEuropeanSession && europeanSessionActive && !europeanSessionComplete && currentTimeOfDay >= europeanEnd)
                {
                    // End of European session - finalize lines
                    europeanSessionActive = false;
                    europeanSessionComplete = true;
                    DrawEuropeanSessionLines();
                }
            }
            
            // Keep drawing completed session lines
            if (asianSessionComplete && asianHighBar > 0 && asianLowBar > 0)
            {
                DrawAsianSessionLines();
            }
            if (europeanSessionComplete && europeanHighBar > 0 && europeanLowBar > 0)
            {
                DrawEuropeanSessionLines();
            }
        }
        
        private void DrawAsianSessionLines()
        {
            if (asianHigh <= 0 || asianLow <= 0 || asianSessionStartBar == 0) return;
            
            // Create unique tags for today's lines
            string dateTag = currentDate.ToString("yyyyMMdd");
            asianHighLineTag = "AsianHighDash_" + dateTag;
            asianLowLineTag = "AsianLowDash_" + dateTag;
            asianHighLineSolidTag = "AsianHighSolid_" + dateTag;
            asianLowLineSolidTag = "AsianLowSolid_" + dateTag;
            
            // Calculate bars ago for session start
            int sessionStartBarsAgo = CurrentBar - asianSessionStartBar;
            
            // Ensure bars ago values are valid
            if (sessionStartBarsAgo < 0 || sessionStartBarsAgo > CurrentBar) return;
            
            // Remove old lines before drawing new ones
            RemoveDrawObject(asianHighLineTag);
            RemoveDrawObject(asianLowLineTag);
            RemoveDrawObject(asianHighLineSolidTag);
            RemoveDrawObject(asianLowLineSolidTag);
            RemoveDrawObject(asianHighLineTag + "_Label");
            RemoveDrawObject(asianLowLineTag + "_Label");
            
            if (asianSessionActive)
            {
                // During active session - draw dashed line from session start to current bar
                Draw.Line(this, asianHighLineTag, false, sessionStartBarsAgo, asianHigh, 0, asianHigh, 
                    AsianHighColor, DashStyleHelper.Dash, AsianLineWidth);
                Draw.Line(this, asianLowLineTag, false, sessionStartBarsAgo, asianLow, 0, asianLow, 
                    AsianLowColor, DashStyleHelper.Dash, AsianLineWidth);
            }
            else if (asianSessionComplete)
            {
                // Session is complete - need to draw both dashed and solid portions
                
                // Calculate session end time (3 AM)
                DateTime sessionEndTime = currentDate.AddHours(3); // 3 AM
                
                // If we're in the same day but past 3 AM, session ended today
                // If we're in the next day, session ended this morning
                if (lastProcessedBar.Hour >= 3 && lastProcessedBar.Date == currentDate)
                {
                    // We're after 3 AM on the trading day
                }
                else if (lastProcessedBar.Date > currentDate)
                {
                    // We're on the next calendar day
                    sessionEndTime = lastProcessedBar.Date.AddHours(3);
                }
                
                DateTime chartSessionEndTime = TimeZoneInfo.ConvertTime(sessionEndTime, 
                    TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"), 
                    TimeZoneInfo.Local);
                
                int sessionEndBar = Bars.GetBar(chartSessionEndTime);
                int sessionEndBarsAgo = -1;
                
                if (sessionEndBar > 0 && sessionEndBar <= CurrentBar)
                {
                    sessionEndBarsAgo = CurrentBar - sessionEndBar;
                }
                
                if (sessionEndBarsAgo >= 0 && sessionEndBarsAgo < sessionStartBarsAgo)
                {
                    // Draw dashed lines for session period (7 PM to 3 AM)
                    Draw.Line(this, asianHighLineTag, false, sessionStartBarsAgo, asianHigh, sessionEndBarsAgo, asianHigh, 
                        AsianHighColor, DashStyleHelper.Dash, AsianLineWidth);
                    Draw.Line(this, asianLowLineTag, false, sessionStartBarsAgo, asianLow, sessionEndBarsAgo, asianLow, 
                        AsianLowColor, DashStyleHelper.Dash, AsianLineWidth);
                    
                    // Draw solid line from 3 AM to 5 PM ET
                    DateTime endTime = currentDate.AddHours(17); // 5 PM today
                    if (lastProcessedBar.Hour >= 17)
                    {
                        endTime = endTime.AddDays(1); // 5 PM tomorrow
                    }
                    
                    DateTime chartEndTime = TimeZoneInfo.ConvertTime(endTime, 
                        TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"), 
                        TimeZoneInfo.Local);
                    
                    int endBar = Bars.GetBar(chartEndTime);
                    int endBarsAgo = 0;
                    
                    if (endBar > CurrentBar)
                    {
                        endBarsAgo = 0; // Extend to current bar
                    }
                    else if (endBar > 0)
                    {
                        endBarsAgo = CurrentBar - endBar;
                        if (endBarsAgo < 0 || endBarsAgo > sessionEndBarsAgo)
                        {
                            endBarsAgo = 0;
                        }
                    }
                    
                    // Draw solid lines from 3 AM to 5 PM
                    Draw.Line(this, asianHighLineSolidTag, false, sessionEndBarsAgo, asianHigh, endBarsAgo, asianHigh, 
                        AsianHighColor, AsianLineStyle, AsianLineWidth);
                    Draw.Line(this, asianLowLineSolidTag, false, sessionEndBarsAgo, asianLow, endBarsAgo, asianLow, 
                        AsianLowColor, AsianLineStyle, AsianLineWidth);
                }
                else
                {
                    // Fallback - just draw dashed to current if we can't find proper end
                    Draw.Line(this, asianHighLineTag, false, sessionStartBarsAgo, asianHigh, 0, asianHigh, 
                        AsianHighColor, DashStyleHelper.Dash, AsianLineWidth);
                    Draw.Line(this, asianLowLineTag, false, sessionStartBarsAgo, asianLow, 0, asianLow, 
                        AsianLowColor, DashStyleHelper.Dash, AsianLineWidth);
                }
            }
            
            // Add labels if enabled
            if (ShowLabels)
            {
                // Position label trailing behind current bar, clamped to not exceed session start
                int labelBarsAgo = Math.Min(AsianLabelTrailingBars, sessionStartBarsAgo);

                Draw.Text(this, asianHighLineTag + "_Label", false, "Asian High", labelBarsAgo,
                    asianHigh + (TickSize * LabelOffset), 0, AsianHighColor, LabelFont,
                    TextAlignment.Right, Brushes.Transparent, Brushes.Transparent, 0);
                Draw.Text(this, asianLowLineTag + "_Label", false, "Asian Low", labelBarsAgo,
                    asianLow - (TickSize * LabelOffset), 0, AsianLowColor, LabelFont,
                    TextAlignment.Right, Brushes.Transparent, Brushes.Transparent, 0);
            }
        }

        private void DrawEuropeanSessionLines()
        {
            if (europeanHigh <= 0 || europeanLow <= 0 || europeanSessionStartBar == 0) return;
            
            // Create unique tags for today's lines
            string dateTag = currentDate.ToString("yyyyMMdd");
            europeanHighLineTag = "EuropeanHighDash_" + dateTag;
            europeanLowLineTag = "EuropeanLowDash_" + dateTag;
            europeanHighLineSolidTag = "EuropeanHighSolid_" + dateTag;
            europeanLowLineSolidTag = "EuropeanLowSolid_" + dateTag;
            
            // Calculate bars ago for session start
            int sessionStartBarsAgo = CurrentBar - europeanSessionStartBar;
            
            // Ensure bars ago values are valid
            if (sessionStartBarsAgo < 0 || sessionStartBarsAgo > CurrentBar) return;
            
            // Remove old lines before drawing new ones
            RemoveDrawObject(europeanHighLineTag);
            RemoveDrawObject(europeanLowLineTag);
            RemoveDrawObject(europeanHighLineSolidTag);
            RemoveDrawObject(europeanLowLineSolidTag);
            RemoveDrawObject(europeanHighLineTag + "_Label");
            RemoveDrawObject(europeanLowLineTag + "_Label");
            
            if (europeanSessionActive)
            {
                // During active session - draw dashed line from session start to current bar
                Draw.Line(this, europeanHighLineTag, false, sessionStartBarsAgo, europeanHigh, 0, europeanHigh, 
                    EuropeanHighColor, DashStyleHelper.Dash, EuropeanLineWidth);
                Draw.Line(this, europeanLowLineTag, false, sessionStartBarsAgo, europeanLow, 0, europeanLow, 
                    EuropeanLowColor, DashStyleHelper.Dash, EuropeanLineWidth);
            }
            else if (europeanSessionComplete)
            {
                // Session is complete - draw dashed portion from 3 AM to 8 AM, then solid from 8 AM onward
                
                // Find 8 AM bar for today's session
                DateTime sessionStart = Time[sessionStartBarsAgo];
                DateTime easternSessionStart = TimeZoneInfo.ConvertTime(sessionStart, TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"));
                
                // Session end is 8 AM on the same day as session start
                DateTime sessionEndTime = easternSessionStart.Date.AddHours(8);
                DateTime chartSessionEndTime = TimeZoneInfo.ConvertTime(sessionEndTime, 
                    TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"), 
                    TimeZoneInfo.Local);
                
                int sessionEndBar = Bars.GetBar(chartSessionEndTime);
                int sessionEndBarsAgo = 0;
                
                bool canDrawSolid = false;
                
                if (sessionEndBar > 0 && sessionEndBar <= CurrentBar)
                {
                    sessionEndBarsAgo = CurrentBar - sessionEndBar;
                    if (sessionEndBarsAgo >= 0 && sessionEndBarsAgo < sessionStartBarsAgo)
                    {
                        canDrawSolid = true;
                        
                        // Draw dashed lines for session period (3 AM to 8 AM)
                        Draw.Line(this, europeanHighLineTag, false, sessionStartBarsAgo, europeanHigh, sessionEndBarsAgo, europeanHigh, 
                            EuropeanHighColor, DashStyleHelper.Dash, EuropeanLineWidth);
                        Draw.Line(this, europeanLowLineTag, false, sessionStartBarsAgo, europeanLow, sessionEndBarsAgo, europeanLow, 
                            EuropeanLowColor, DashStyleHelper.Dash, EuropeanLineWidth);
                    }
                }
                
                if (!canDrawSolid)
                {
                    // If we can't find 8 AM properly, draw dashed to current
                    Draw.Line(this, europeanHighLineTag, false, sessionStartBarsAgo, europeanHigh, 0, europeanHigh, 
                        EuropeanHighColor, DashStyleHelper.Dash, EuropeanLineWidth);
                    Draw.Line(this, europeanLowLineTag, false, sessionStartBarsAgo, europeanLow, 0, europeanLow, 
                        EuropeanLowColor, DashStyleHelper.Dash, EuropeanLineWidth);
                }
                else
                {
                    // Draw solid line from 8 AM to 5 PM (or current bar)
                    DateTime endTime = currentDate.AddHours(17); // 5 PM today
                    
                    // If we're past 5 PM, the line should extend to 5 PM tomorrow
                    if (lastProcessedBar.Hour >= 17 && lastProcessedBar.Date >= currentDate)
                    {
                        endTime = endTime.AddDays(1);
                    }
                    
                    DateTime chartEndTime = TimeZoneInfo.ConvertTime(endTime, 
                        TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"), 
                        TimeZoneInfo.Local);
                    
                    int endBar = Bars.GetBar(chartEndTime);
                    int endBarsAgo = 0;
                    
                    if (endBar > CurrentBar || endBar <= 0)
                    {
                        // End time is in the future or not found, extend to current bar
                        endBarsAgo = 0;
                    }
                    else
                    {
                        endBarsAgo = CurrentBar - endBar;
                        // Ensure we don't go backwards
                        if (endBarsAgo > sessionEndBarsAgo)
                        {
                            endBarsAgo = 0;
                        }
                    }
                    
                    // Draw solid lines from 8 AM onward
                    Draw.Line(this, europeanHighLineSolidTag, false, sessionEndBarsAgo, europeanHigh, endBarsAgo, europeanHigh, 
                        EuropeanHighColor, EuropeanLineStyle, EuropeanLineWidth);
                    Draw.Line(this, europeanLowLineSolidTag, false, sessionEndBarsAgo, europeanLow, endBarsAgo, europeanLow, 
                        EuropeanLowColor, EuropeanLineStyle, EuropeanLineWidth);
                }
            }
            
            // Add labels if enabled
            if (ShowLabels)
            {
                // Position label trailing behind current bar, clamped to not exceed session start
                int labelBarsAgo = Math.Min(EuropeanLabelTrailingBars, sessionStartBarsAgo);

                Draw.Text(this, europeanHighLineTag + "_Label", false, "European High", labelBarsAgo,
                    europeanHigh + (TickSize * LabelOffset), 0, EuropeanHighColor, LabelFont,
                    TextAlignment.Right, Brushes.Transparent, Brushes.Transparent, 0);
                Draw.Text(this, europeanLowLineTag + "_Label", false, "European Low", labelBarsAgo,
                    europeanLow - (TickSize * LabelOffset), 0, EuropeanLowColor, LabelFont,
                    TextAlignment.Right, Brushes.Transparent, Brushes.Transparent, 0);
            }
        }

        private void RemoveOldLines()
        {
            // Remove previous day's lines
            if (!string.IsNullOrEmpty(asianHighLineTag))
            {
                RemoveDrawObject(asianHighLineTag);
                RemoveDrawObject(asianHighLineSolidTag);
                RemoveDrawObject(asianHighLineTag + "_Label");
            }
            if (!string.IsNullOrEmpty(asianLowLineTag))
            {
                RemoveDrawObject(asianLowLineTag);
                RemoveDrawObject(asianLowLineSolidTag);
                RemoveDrawObject(asianLowLineTag + "_Label");
            }
            if (!string.IsNullOrEmpty(europeanHighLineTag))
            {
                RemoveDrawObject(europeanHighLineTag);
                RemoveDrawObject(europeanHighLineSolidTag);
                RemoveDrawObject(europeanHighLineTag + "_Label");
            }
            if (!string.IsNullOrEmpty(europeanLowLineTag))
            {
                RemoveDrawObject(europeanLowLineTag);
                RemoveDrawObject(europeanLowLineSolidTag);
                RemoveDrawObject(europeanLowLineTag + "_Label");
            }
        }
        
        private void ResetSessionVariables()
        {
            asianSessionActive = false;
            asianSessionComplete = false;
            europeanSessionActive = false;
            europeanSessionComplete = false;
            asianHigh = 0;
            asianLow = double.MaxValue;
            europeanHigh = 0;
            europeanLow = double.MaxValue;
            asianHighBar = 0;
            asianLowBar = 0;
            europeanHighBar = 0;
            europeanLowBar = 0;
            asianSessionStartBar = 0;
            europeanSessionStartBar = 0;
        }
        
        #region Properties
        
        [NinjaScriptProperty]
        [Display(Name="Show Asian Session", Description="Toggle visibility of Asian session lines", Order=1, GroupName="Asian Session")]
        public bool ShowAsianSession
        { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="Asian High Color", Description="Color for Asian session high line", Order=2, GroupName="Asian Session")]
        public Brush AsianHighColor
        { get; set; }
        
        [Browsable(false)]
        public string AsianHighColorSerializable
        {
            get { return Serialize.BrushToString(AsianHighColor); }
            set { AsianHighColor = Serialize.StringToBrush(value); }
        }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="Asian Low Color", Description="Color for Asian session low line", Order=3, GroupName="Asian Session")]
        public Brush AsianLowColor
        { get; set; }
        
        [Browsable(false)]
        public string AsianLowColorSerializable
        {
            get { return Serialize.BrushToString(AsianLowColor); }
            set { AsianLowColor = Serialize.StringToBrush(value); }
        }
        
        [NinjaScriptProperty]
        [Display(Name="Asian Line Style", Description="Line style for Asian session lines", Order=4, GroupName="Asian Session")]
        public DashStyleHelper AsianLineStyle
        { get; set; }
        
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="Asian Line Width", Description="Line width for Asian session lines", Order=5, GroupName="Asian Session")]
        public int AsianLineWidth
        { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name="Show European Session", Description="Toggle visibility of European session lines", Order=1, GroupName="European Session")]
        public bool ShowEuropeanSession
        { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="European High Color", Description="Color for European session high line", Order=2, GroupName="European Session")]
        public Brush EuropeanHighColor
        { get; set; }
        
        [Browsable(false)]
        public string EuropeanHighColorSerializable
        {
            get { return Serialize.BrushToString(EuropeanHighColor); }
            set { EuropeanHighColor = Serialize.StringToBrush(value); }
        }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name="European Low Color", Description="Color for European session low line", Order=3, GroupName="European Session")]
        public Brush EuropeanLowColor
        { get; set; }
        
        [Browsable(false)]
        public string EuropeanLowColorSerializable
        {
            get { return Serialize.BrushToString(EuropeanLowColor); }
            set { EuropeanLowColor = Serialize.StringToBrush(value); }
        }
        
        [NinjaScriptProperty]
        [Display(Name="European Line Style", Description="Line style for European session lines", Order=4, GroupName="European Session")]
        public DashStyleHelper EuropeanLineStyle
        { get; set; }
        
        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name="European Line Width", Description="Line width for European session lines", Order=5, GroupName="European Session")]
        public int EuropeanLineWidth
        { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name="Show Labels", Description="Show session labels on lines", Order=1, GroupName="Labels")]
        public bool ShowLabels
        { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name="Label Font", Description="Font for session labels", Order=2, GroupName="Labels")]
        public SimpleFont LabelFont
        { get; set; }
        
        [NinjaScriptProperty]
        [Range(1, 20)]
        [Display(Name="Label Offset (Ticks)", Description="Vertical offset for labels in ticks", Order=3, GroupName="Labels")]
        public int LabelOffset
        { get; set; }

        [NinjaScriptProperty]
        [Range(0, 100)]
        [Display(Name="Asian Label Trailing (Bars)", Description="How many bars behind the current bar to position Asian session labels (0 = at current bar)", Order=4, GroupName="Labels")]
        public int AsianLabelTrailingBars
        { get; set; }

        [NinjaScriptProperty]
        [Range(0, 100)]
        [Display(Name="European Label Trailing (Bars)", Description="How many bars behind the current bar to position European session labels (0 = at current bar)", Order=5, GroupName="Labels")]
        public int EuropeanLabelTrailingBars
        { get; set; }

        // ===== NEW PUBLIC PROPERTIES FOR EXTERNAL ACCESS =====
        // These allow other indicators (like MultiSymbolStreamer) to read the session values
        
        [Browsable(false)]
        [XmlIgnore]
        public double AsianSessionHigh
        { 
            get { return asianSessionComplete ? asianHigh : 0; }
        }
        
        [Browsable(false)]
        [XmlIgnore]
        public double AsianSessionLow
        { 
            get { return asianSessionComplete ? asianLow : double.MaxValue; }
        }
        
        [Browsable(false)]
        [XmlIgnore]
        public double EuropeanSessionHigh
        { 
            get { return europeanSessionComplete ? europeanHigh : 0; }
        }
        
        [Browsable(false)]
        [XmlIgnore]
        public double EuropeanSessionLow
        { 
            get { return europeanSessionComplete ? europeanLow : double.MaxValue; }
        }
        
        [Browsable(false)]
        [XmlIgnore]
        public bool IsAsianSessionComplete
        { 
            get { return asianSessionComplete; }
        }
        
        [Browsable(false)]
        [XmlIgnore]
        public bool IsEuropeanSessionComplete
        { 
            get { return europeanSessionComplete; }
        }
        
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PhillyFranksTools.AsianEuropeanSessionHighLow[] cacheAsianEuropeanSessionHighLow;
		public PhillyFranksTools.AsianEuropeanSessionHighLow AsianEuropeanSessionHighLow(bool showAsianSession, Brush asianHighColor, Brush asianLowColor, DashStyleHelper asianLineStyle, int asianLineWidth, bool showEuropeanSession, Brush europeanHighColor, Brush europeanLowColor, DashStyleHelper europeanLineStyle, int europeanLineWidth, bool showLabels, SimpleFont labelFont, int labelOffset, int asianLabelTrailingBars, int europeanLabelTrailingBars)
		{
			return AsianEuropeanSessionHighLow(Input, showAsianSession, asianHighColor, asianLowColor, asianLineStyle, asianLineWidth, showEuropeanSession, europeanHighColor, europeanLowColor, europeanLineStyle, europeanLineWidth, showLabels, labelFont, labelOffset, asianLabelTrailingBars, europeanLabelTrailingBars);
		}

		public PhillyFranksTools.AsianEuropeanSessionHighLow AsianEuropeanSessionHighLow(ISeries<double> input, bool showAsianSession, Brush asianHighColor, Brush asianLowColor, DashStyleHelper asianLineStyle, int asianLineWidth, bool showEuropeanSession, Brush europeanHighColor, Brush europeanLowColor, DashStyleHelper europeanLineStyle, int europeanLineWidth, bool showLabels, SimpleFont labelFont, int labelOffset, int asianLabelTrailingBars, int europeanLabelTrailingBars)
		{
			if (cacheAsianEuropeanSessionHighLow != null)
				for (int idx = 0; idx < cacheAsianEuropeanSessionHighLow.Length; idx++)
					if (cacheAsianEuropeanSessionHighLow[idx] != null && cacheAsianEuropeanSessionHighLow[idx].ShowAsianSession == showAsianSession && cacheAsianEuropeanSessionHighLow[idx].AsianHighColor == asianHighColor && cacheAsianEuropeanSessionHighLow[idx].AsianLowColor == asianLowColor && cacheAsianEuropeanSessionHighLow[idx].AsianLineStyle == asianLineStyle && cacheAsianEuropeanSessionHighLow[idx].AsianLineWidth == asianLineWidth && cacheAsianEuropeanSessionHighLow[idx].ShowEuropeanSession == showEuropeanSession && cacheAsianEuropeanSessionHighLow[idx].EuropeanHighColor == europeanHighColor && cacheAsianEuropeanSessionHighLow[idx].EuropeanLowColor == europeanLowColor && cacheAsianEuropeanSessionHighLow[idx].EuropeanLineStyle == europeanLineStyle && cacheAsianEuropeanSessionHighLow[idx].EuropeanLineWidth == europeanLineWidth && cacheAsianEuropeanSessionHighLow[idx].ShowLabels == showLabels && cacheAsianEuropeanSessionHighLow[idx].LabelFont == labelFont && cacheAsianEuropeanSessionHighLow[idx].LabelOffset == labelOffset && cacheAsianEuropeanSessionHighLow[idx].AsianLabelTrailingBars == asianLabelTrailingBars && cacheAsianEuropeanSessionHighLow[idx].EuropeanLabelTrailingBars == europeanLabelTrailingBars && cacheAsianEuropeanSessionHighLow[idx].EqualsInput(input))
						return cacheAsianEuropeanSessionHighLow[idx];
			return CacheIndicator<PhillyFranksTools.AsianEuropeanSessionHighLow>(new PhillyFranksTools.AsianEuropeanSessionHighLow(){ ShowAsianSession = showAsianSession, AsianHighColor = asianHighColor, AsianLowColor = asianLowColor, AsianLineStyle = asianLineStyle, AsianLineWidth = asianLineWidth, ShowEuropeanSession = showEuropeanSession, EuropeanHighColor = europeanHighColor, EuropeanLowColor = europeanLowColor, EuropeanLineStyle = europeanLineStyle, EuropeanLineWidth = europeanLineWidth, ShowLabels = showLabels, LabelFont = labelFont, LabelOffset = labelOffset, AsianLabelTrailingBars = asianLabelTrailingBars, EuropeanLabelTrailingBars = europeanLabelTrailingBars }, input, ref cacheAsianEuropeanSessionHighLow);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PhillyFranksTools.AsianEuropeanSessionHighLow AsianEuropeanSessionHighLow(bool showAsianSession, Brush asianHighColor, Brush asianLowColor, DashStyleHelper asianLineStyle, int asianLineWidth, bool showEuropeanSession, Brush europeanHighColor, Brush europeanLowColor, DashStyleHelper europeanLineStyle, int europeanLineWidth, bool showLabels, SimpleFont labelFont, int labelOffset, int asianLabelTrailingBars, int europeanLabelTrailingBars)
		{
			return indicator.AsianEuropeanSessionHighLow(Input, showAsianSession, asianHighColor, asianLowColor, asianLineStyle, asianLineWidth, showEuropeanSession, europeanHighColor, europeanLowColor, europeanLineStyle, europeanLineWidth, showLabels, labelFont, labelOffset, asianLabelTrailingBars, europeanLabelTrailingBars);
		}

		public Indicators.PhillyFranksTools.AsianEuropeanSessionHighLow AsianEuropeanSessionHighLow(ISeries<double> input , bool showAsianSession, Brush asianHighColor, Brush asianLowColor, DashStyleHelper asianLineStyle, int asianLineWidth, bool showEuropeanSession, Brush europeanHighColor, Brush europeanLowColor, DashStyleHelper europeanLineStyle, int europeanLineWidth, bool showLabels, SimpleFont labelFont, int labelOffset, int asianLabelTrailingBars, int europeanLabelTrailingBars)
		{
			return indicator.AsianEuropeanSessionHighLow(input, showAsianSession, asianHighColor, asianLowColor, asianLineStyle, asianLineWidth, showEuropeanSession, europeanHighColor, europeanLowColor, europeanLineStyle, europeanLineWidth, showLabels, labelFont, labelOffset, asianLabelTrailingBars, europeanLabelTrailingBars);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PhillyFranksTools.AsianEuropeanSessionHighLow AsianEuropeanSessionHighLow(bool showAsianSession, Brush asianHighColor, Brush asianLowColor, DashStyleHelper asianLineStyle, int asianLineWidth, bool showEuropeanSession, Brush europeanHighColor, Brush europeanLowColor, DashStyleHelper europeanLineStyle, int europeanLineWidth, bool showLabels, SimpleFont labelFont, int labelOffset, int asianLabelTrailingBars, int europeanLabelTrailingBars)
		{
			return indicator.AsianEuropeanSessionHighLow(Input, showAsianSession, asianHighColor, asianLowColor, asianLineStyle, asianLineWidth, showEuropeanSession, europeanHighColor, europeanLowColor, europeanLineStyle, europeanLineWidth, showLabels, labelFont, labelOffset, asianLabelTrailingBars, europeanLabelTrailingBars);
		}

		public Indicators.PhillyFranksTools.AsianEuropeanSessionHighLow AsianEuropeanSessionHighLow(ISeries<double> input , bool showAsianSession, Brush asianHighColor, Brush asianLowColor, DashStyleHelper asianLineStyle, int asianLineWidth, bool showEuropeanSession, Brush europeanHighColor, Brush europeanLowColor, DashStyleHelper europeanLineStyle, int europeanLineWidth, bool showLabels, SimpleFont labelFont, int labelOffset, int asianLabelTrailingBars, int europeanLabelTrailingBars)
		{
			return indicator.AsianEuropeanSessionHighLow(input, showAsianSession, asianHighColor, asianLowColor, asianLineStyle, asianLineWidth, showEuropeanSession, europeanHighColor, europeanLowColor, europeanLineStyle, europeanLineWidth, showLabels, labelFont, labelOffset, asianLabelTrailingBars, europeanLabelTrailingBars);
		}
	}
}

#endregion
