# AGENTS.md — Trend Pullback B

Working notes for a coding agent asked to change anything in this package. Read this
before editing either `.cs` file. `CLAUDE.md` carries the same rules in shorter form.

## What this package is

A NinjaTrader 8 trading system shipped in two halves:

| File | Owns |
|---|---|
| `Indicators/TrendPullbackSignal.cs` | **All** entry logic, the bracket sizing, the display, the alerts |
| `Strategies/TrendPullbackB.cs` | Order submission, account guard, clock enforcement, target limit exit |

The strategy hosts the indicator (`signals = TrendPullbackSignal(Preset, false);` in
`State.DataLoaded`) and reads four series from it: `Signal`, `EntryLimit`,
`StopDistance`, `TargetDistance`.

## The one rule that matters

**There is exactly one copy of the signal logic, and it lives in the indicator.**

The package is sold on the claim that what a trader sees on the chart is what the
strategy does. A second copy of any entry condition — even "just for clarity", even
"just so the strategy is standalone" — breaks that claim silently, because the two
copies will be edited at different times by different people. If you are asked to make
the strategy independent of the indicator, say what it costs before you do it.

Corollaries:

- Add a condition? It goes in `TrendPullbackSignal.OnBarUpdate`, never in the strategy.
- Change the bracket maths? `PublishSetup` in the indicator, never `SubmitEntry`.
- The strategy may only ever **decline** a signal (flat check, trade count, account
  guard, news blackout). It must never construct one.

## Parity invariants — do not "fix" these

Each of these looks like a bug and is not. They are reproductions of the code that
produced the published results; changing one changes the signals and invalidates the
record in `README.md`.

1. **Window-anchored VWAP.** `cumPV` / `cumVol` accumulate only on bars inside the entry
   window and reset on the calendar date. It is not a session VWAP and not a daily VWAP.
2. **Bar close only.** The indicator forces `Calculate` back to `OnBarClose` in
   `State.Configure`. Intrabar evaluation would surface setups that retract.
3. **Pessimistic simulated fills.** On the fill bar only the stop is checked; after that
   a bar touching both stop and target is recorded as a stop. A fill-bar target credit
   was measured to inflate a profit factor from 1.00 to 1.52 on a related strategy.
4. **One-bar limit life.** `EnterLongLimit(0, false, ...)` with
   `isLiveUntilCancelled = false`. A setup that does not retrace is declined, not chased.
5. **Risk constants are `const`, not properties.** `EntryRetracePct`, `AtrStopMult`,
   `StopFloorPoints`, `StopCapPoints`, `MaxRMultiple`, `HardNoEntryHHMM`,
   `HardFlatHHMM`, `HardFlatEndHHMM`. A NinjaTrader strategy instance that is already
   configured on the Strategies tab keeps its own saved property values forever, so a
   risk rule written as a property is silently defeated on every instance that already
   exists. This was learned the expensive way. Do not promote any of them to a property.
6. **The stop clamp may only widen a configured stop, never tighten it.**
   `lo = Math.Max(StopFloorPoints, effStopPoints)`.
7. **15:30 / 15:45 ET.** No new entry from 15:30, flat from 15:45, re-checked every bar
   and every tick until 19:00. Never make these conditional on anything.

## Wrapper signature stability

Only two properties on the indicator carry `[NinjaScriptProperty]`: `Preset` and
`ShowVisuals`, in that order. NinjaTrader generates the strategy-facing constructor from
those attributes in declaration order, so **adding a `[NinjaScriptProperty]` to the
indicator breaks the strategy's call**. Display and filter options must stay plain
`[Display]` properties.

## NinjaScript constraints

- Targets C# 5 / .NET 4.8 as NinjaTrader compiles it. No `string` interpolation with
  `$`, no tuples, no pattern matching, no `nameof` in attributes.
- Files must stay **pure ASCII**. Non-ASCII characters have broken NinjaTrader compiles
  in this codebase before.
- Enums used as `[NinjaScriptProperty]` parameter types sit at **global scope**, outside
  the namespace: the generated wrapper resolves enum parameter types by bare name.
- No blocking work, no network calls, no unbounded file IO on the update path. The only
  file the strategy writes is a single four-field line under
  `NinjaTrader.Core.Globals.UserDataDir\TrendPullback\`.
- **No hardcoded machine-specific paths.** Anything on disk resolves from
  `NinjaTrader.Core.Globals.UserDataDir` or `InstallDir`.
- Catch blocks either log to `NinjaTrader.Code.Output.Process` / `Log()` or are a
  documented no-op on a cosmetic call. Nothing fails silently.
- Draw objects: one per setup, tagged `tp<seq>...`, redrawn from their origin bar to bar
  0. Never draw one object per bar — that leaks objects for the life of the session.

## Verifying a change

There is no unit-test harness in this package; NinjaTrader is the compiler and Market
Replay is the test bed.

1. Compile in NinjaTrader (**Tools → New NinjaScript → Compile**). Warnings matter —
   an unused field usually means a code path was half-removed.
2. Put `TrendPullbackSignal` on a 1-minute NQ chart, ETH template, NinjaTrader set to
   US Eastern. Check the panel updates and the arrows land on bar closes.
3. Run `TrendPullbackB` on the same chart in Market Replay on a sim account. **Every
   entry the strategy takes must sit on a bar the indicator marked**, at the same limit
   price. If they disagree, the parity claim is broken — stop and fix that first.
4. Watch the NinjaScript Output window for guard lines and any failure messages.
5. If you changed a signal rule, the performance numbers in `README.md` no longer
   describe this code. Either re-test over the same window or delete the claim.

## Out of bounds

Do not, without the owner explicitly asking:

- remove or weaken the clock rules or the account guard
- turn the indicator into an order-placing tool — its whole purpose is that it does not
  trade, so that it can be used where automation is not allowed
- add a network call, a licence check, telemetry, or anything that phones home
- reintroduce the per-trade JSONL research logger that was stripped from the strategy
- change `README.md`'s performance numbers to anything other than what the record says
