#region Using declarations
using System;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;
#endregion

// TrendPullbackB -- trend + pullback to EMA/VWAP, entered on a one-bar retracement
// limit with an ATR-scaled bracket. Variant B, European preset.
//
// READ THIS FIRST
//   THIS FILE PLACES REAL ORDERS. Attached to a live account it buys and sells
//   without asking you again. The account guard below only knows about orders it
//   placed itself: it cannot see anything you do by hand on the same account, it
//   trusts whatever numbers you configure, and like any software it can fail. It is
//   not a safety net and it is not a substitute for reading your account rules.
//
//   The pass rate quoted in README.md is SIMULATED and is not a track record. It
//   came from a simulator that does not model slippage, queue position, partial
//   fills or rejected orders, over the same period used to measure it. No claim is
//   made that any account will do the same, and most attempts in that record failed.
//   Nothing here is financial advice.
//
//   Most funding companies do not allow a fully automated strategy to trade an
//   evaluation or funded account. Some ban it outright, some allow "semi-automated"
//   only, and the rule is theirs to change. This file is for simulation, replay and
//   your own capital. If you are trading someone else's money, run the
//   TrendPullbackSignal indicator instead and place the orders yourself -- it shows
//   the same entry, the same stop and the same target, because it is the same code.
//
// WHERE THE RULES LIVE
//   The signal rules are NOT in this file. This strategy hosts TrendPullbackSignal
//   and reads its Signal / EntryLimit / StopDistance / TargetDistance series. There is
//   exactly one copy of the entry logic in this package, and both halves use it. Do
//   not reimplement a condition here to "keep the strategy standalone" -- the moment
//   two copies exist, the chart stops telling the truth about the strategy.
//
// WHAT THIS FILE OWNS
//   * order submission and the bracket
//   * the account guard (profit target, trailing drawdown, daily loss limit)
//   * the clock rules: no new entry at/after 15:30 ET, flat at/after 15:45 ET
//   * the profit-target limit exit
//
// TIME ZONE
//   Session hours are read from the chart clock and the presets are written in US
//   Eastern. Set NinjaTrader to Eastern, or shift the hours yourself.
//
// MIT licensed. No warranty and no guarantee of profit. See LICENSE and README.md.

// Which account rules this strategy is responsible for enforcing. One value, not two
// switches, because Sim and Eval are mutually exclusive and a pair of checkboxes can be
// ticked together -- there is no state here that means "both".
//
//   Off   no account limits at all. It trades until you stop it.
//   Sim   nothing else is watching, so the strategy enforces everything: the daily
//         loss limit, the trailing drawdown, and stopping at the profit target.
//   Eval  the funding company enforces the daily loss limit, so the strategy does not
//         duplicate it. It still stops at the profit target and still converts the
//         bracket to a resting limit to bank it.
//
// The trailing-drawdown check stays live in both Sim and Eval. In Eval it is redundant
// with the provider's own liquidation, but it can only ever stop trading on an account
// that is already finished, so it costs nothing to leave in.
public enum TrendPullbackAccountMode
{
    Off,
    Sim,
    Eval
}

namespace NinjaTrader.NinjaScript.Strategies
{
    public class TrendPullbackB : Strategy
    {
        private NinjaTrader.NinjaScript.Indicators.PhillyFranksTools.TrendPullbackSignal signals;

        private DateTime lastDate = DateTime.MinValue;
        private int      tradesThisSession;

        // --- Account guard state --------------------------------------------------
        private double peakBalance;          // highest end-of-day balance seen
        private double failThreshold;        // peak - trailing drawdown (capped at start)
        private double dayStartBalance;      // balance at the 17:00 ET roll
        private int    guardDayKey;
        private bool   accountDone;          // target reached or account failed: terminal
        private bool   dayLocked;            // daily loss limit hit: locked until the roll

        // External equity change detector (an operator reset or a deposit).
        private double   lastAcctNL     = double.NaN;
        private double   lastDayPnl     = double.NaN;
        private double   extBaseNL      = double.NaN;
        private double   extBaseDayPnl  = double.NaN;
        private DateTime extSeenAt      = DateTime.MinValue;
        private const double ExtChangeUsd  = 100.0;   // a move trading cannot explain
        private const int    ExtConfirmSec = 5;       // must survive this long to count

        // --- Bracket --------------------------------------------------------------
        //  The stop and target distances arrive from the indicator, already tick
        //  rounded, so the chart and the order use the same numbers.
        private double activeTargetPoints;
        private bool   targetLimitArmed;
        private const double TargetBufferUsd = 50.0;   // exit commission + tick rounding

        // --- Clock rules (consts on purpose) --------------------------------------
        //  A strategy instance already configured on the Strategies tab keeps its own
        //  saved property values, so a risk rule written as a property is silently
        //  defeated on every instance that already exists. These compile in.
        private const int HardNoEntryHHMM = 1530;
        private const int HardFlatHHMM    = 1545;
        private const int HardFlatEndHHMM = 1900;

        private const string SignalName = "TPB";

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name                         = "TrendPullbackB";
                Description                  = "Trend + pullback to EMA/VWAP, one-bar retracement limit, ATR bracket. Signals come from the TrendPullbackSignal indicator.";
                Calculate                    = Calculate.OnBarClose;
                EntriesPerDirection          = 1;
                EntryHandling                = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds    = 30;
                IncludeCommission            = true;
                BarsRequiredToTrade          = 25;

                Preset              = TrendPullbackPreset.VariantB_European;
                Contracts           = 1;
                MaxTradesPerSession = 99;
                AvoidLunchChop      = false;
                NewsBlackoutHHMM    = string.Empty;

                AccountMode          = TrendPullbackAccountMode.Sim;
                StartingBalanceUsd   = 50000;
                ProfitTargetUsd      = 3000;
                TrailingDrawdownUsd  = 2000;
                LockTrailingAtStart  = true;
                DailyLossLimitUsd    = 950;
                UseTargetLimitExit   = true;
            }
            else if (State == State.DataLoaded)
            {
                // ShowVisuals is false: the hosted copy computes, it does not draw.
                // Put TrendPullbackSignal on the chart yourself to see the setups.
                signals = TrendPullbackSignal(Preset, false);

                peakBalance     = StartingBalanceUsd;
                dayStartBalance = StartingBalanceUsd;
                failThreshold   = StartingBalanceUsd - TrailingDrawdownUsd;
            }
        }

        protected override void OnBarUpdate()
        {
            if (BarsInProgress != 0 || CurrentBar < BarsRequiredToTrade)
                return;

            HardFlatCheck(Time[0]);

            if (Time[0].Date != lastDate)
            {
                tradesThisSession = 0;
                lastDate = Time[0].Date;
            }

            EvalAccountGuard(Close[0], Time[0]);

            if (accountDone || dayLocked)
                return;

            int now = ToTime(Time[0]) / 100;
            if (PastEntryCutoff(now) || InNewsBlackout(now))
                return;

            double sig = signals.Signal[0];
            if (sig == 0)
                return;

            if (Position.MarketPosition != MarketPosition.Flat)
                return;
            if (tradesThisSession >= MaxTradesPerSession)
                return;

            SubmitEntry(sig > 0, signals.EntryLimit[0], signals.StopDistance[0], signals.TargetDistance[0]);
        }

        // Place the entry as a one-bar retracement limit and attach the bracket the
        // indicator sized. isLiveUntilCancelled = false: NinjaTrader cancels the order
        // if it has not filled by the end of the next bar, and the signal is allowed to
        // lapse. Price must come back to us; we do not chase the extreme of the bar
        // that fired the setup.
        private void SubmitEntry(bool isLong, double limitPx, double stopPoints, double targetPoints)
        {
            if (limitPx <= 0 || stopPoints <= 0 || targetPoints <= 0 || TickSize <= 0)
                return;

            activeTargetPoints = targetPoints;

            try
            {
                SetStopLoss(SignalName, CalculationMode.Ticks, (int)Math.Round(stopPoints / TickSize), false);
                SetProfitTarget(SignalName, CalculationMode.Ticks, (int)Math.Round(targetPoints / TickSize));
            }
            catch (Exception ex)
            {
                // A bracket that cannot be set is a reason not to trade, not a reason
                // to send a naked entry.
                LogLine("bracket setup failed, entry skipped: " + ex.Message);
                return;
            }

            if (isLong) EnterLongLimit(0, false, Contracts, limitPx, SignalName);
            else        EnterShortLimit(0, false, Contracts, limitPx, SignalName);
        }

        protected override void OnExecutionUpdate(Execution execution, string executionId, double price,
            int quantity, MarketPosition marketPosition, string orderId, DateTime time)
        {
            if (execution.Order != null && execution.Order.Name == SignalName
                && execution.Order.OrderState == OrderState.Filled)
                tradesThisSession++;
        }

        protected override void OnMarketData(MarketDataEventArgs e)
        {
            if (e.MarketDataType != MarketDataType.Last)
                return;
            EvalAccountGuard(e.Price, e.Time);
            HardFlatCheck(e.Time);
        }

        // --- Account guard ---------------------------------------------------------
        //  Written for the shape almost every funding company uses:
        //    PASS  balance reaches start + profit target      -> terminal, stop trading
        //    FAIL  balance touches the trailing threshold     -> flatten, terminal
        //          (threshold = highest end-of-day balance - trailing drawdown, and
        //           with LockTrailingAtStart it stops ratcheting at the start balance)
        //    LOCK  down the daily loss limit from the day's start -> flat for the day
        //          (Sim mode only -- see TrendPullbackAccountMode at the top of the file)
        //  It is not a substitute for reading your own contract. Check the numbers
        //  against your account before you rely on them, and remember that this can
        //  only act on the trades IT placed -- it cannot see or stop anything you do
        //  by hand on the same account.
        //  The Apex trading day rolls at 17:00 ET; eventTime is chart/tick time.
        private void EvalAccountGuard(double px, DateTime eventTime)
        {
            if (AccountMode == TrendPullbackAccountMode.Off || State != State.Realtime || Account == null)
                return;

            double acctNL = Account.Get(AccountItem.NetLiquidation, Currency.UsDollar);
            double dayPnl = Account.Get(AccountItem.RealizedProfitLoss, Currency.UsDollar)
                          + Account.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar);
            if (acctNL <= 0)
                return;

            // Tick-fresh equity. NinjaTrader throttles account-item refreshes, so a
            // fast spike can cross a line and retreat between two NetLiquidation
            // updates. Replace the stale unrealized component with one computed from
            // THIS event's price. Assumes this strategy is the only thing trading the
            // account -- if it is not, the guard is reading someone else's P&L too.
            double liveEq = acctNL;
            if (px > 0 && Position.MarketPosition != MarketPosition.Flat)
            {
                liveEq = acctNL
                       - Account.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar)
                       + Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, px);
            }

            // --- External equity change (reset or deposit) -------------------------
            //  A NetLiquidation move the day's trading does not explain means money
            //  came from outside. Without this, an account reset while still alive
            //  keeps its old daily-loss anchor and hands itself several times the
            //  intended daily rope. NinjaTrader refreshes account items independently,
            //  so a closing fill can briefly show the balance updated and the realized
            //  P&L not yet -- a phantom gap. A gap therefore only OPENS a window; it
            //  must still be there ExtConfirmSec later. Flat only: any open position
            //  discards the window.
            if (Position.MarketPosition != MarketPosition.Flat)
            {
                extBaseNL = double.NaN;
            }
            else if (!double.IsNaN(extBaseNL))
            {
                double cumGap = (acctNL - extBaseNL) - (dayPnl - extBaseDayPnl);
                if ((eventTime - extSeenAt).TotalSeconds >= ExtConfirmSec)
                {
                    if (Math.Abs(cumGap) > ExtChangeUsd)
                        ReanchorGuard(acctNL, eventTime, "external equity change " + cumGap.ToString("+0.00;-0.00"));
                    extBaseNL = double.NaN;
                }
            }
            else if (!double.IsNaN(lastAcctNL)
                     && Math.Abs((acctNL - lastAcctNL) - (dayPnl - lastDayPnl)) > ExtChangeUsd)
            {
                extBaseNL = lastAcctNL; extBaseDayPnl = lastDayPnl; extSeenAt = eventTime;
            }
            lastAcctNL = acctNL; lastDayPnl = dayPnl;

            if (accountDone)
            {
                // A reset back to the starting balance is a new attempt.
                if (Math.Abs(acctNL - StartingBalanceUsd) <= 150.0)
                    ReanchorGuard(acctNL, eventTime, "reset to starting balance");
                else
                {
                    FlattenNow();
                    return;
                }
            }

            int key = TradingDayKey(eventTime);
            if (guardDayKey == 0)
            {
                // Restart-proof anchor: a NinjaTrader restart zeroes the platform's
                // day P&L, so re-deriving the anchor mid-day would re-base the daily
                // loss floor at the drawn-down balance and quietly grant a second full
                // day of rope. Prefer today's saved anchor; derive one only if none
                // exists for this day.
                guardDayKey = key;
                if (!TryLoadGuardDay(key))
                {
                    dayStartBalance = acctNL - dayPnl;
                    SaveGuardDay(key);
                }
            }
            else if (key != guardDayKey)   // 17:00 ET roll: fix the new threshold
            {
                if (acctNL > peakBalance) peakBalance = acctNL;
                double thr = peakBalance - TrailingDrawdownUsd;
                if (LockTrailingAtStart && thr > StartingBalanceUsd) thr = StartingBalanceUsd;
                if (thr > failThreshold) failThreshold = thr;
                guardDayKey     = key;
                dayStartBalance = acctNL - dayPnl;
                dayLocked       = false;
                SaveGuardDay(key);
            }

            MaintainTargetLimit(px, acctNL);

            double passLevel = StartingBalanceUsd + ProfitTargetUsd;
            if (liveEq >= passLevel)
            {
                // Declare the target only when FLAT at or above the line. While in a
                // trade, flatten once tick-fresh equity clears the line plus a cushion
                // for the market exit; a flatten that still lands short simply resumes
                // trading instead of wedging the account.
                if (Position.MarketPosition == MarketPosition.Flat) { accountDone = true; return; }
                if (liveEq >= passLevel + 250.0) FlattenNow();
                return;
            }

            if (liveEq <= failThreshold)
            {
                FlattenNow();
                accountDone = true;
                return;
            }

            // Sim only. On an evaluation the provider enforces the daily loss limit
            // itself, and a second copy of that rule here would only ever stop trading
            // EARLIER than the account actually requires -- on a number this strategy
            // estimates rather than one the provider publishes.
            if (AccountMode == TrendPullbackAccountMode.Sim
                && !dayLocked && DailyLossLimitUsd > 0
                && liveEq <= dayStartBalance - DailyLossLimitUsd)
            {
                FlattenNow();
                dayLocked = true;
                LogLine("daily loss limit reached, flat for the day");
            }
        }

        private void ReanchorGuard(double acctNL, DateTime eventTime, string why)
        {
            dayStartBalance = acctNL;
            peakBalance     = Math.Max(StartingBalanceUsd, acctNL);
            double thr = peakBalance - TrailingDrawdownUsd;
            if (LockTrailingAtStart && thr > StartingBalanceUsd) thr = StartingBalanceUsd;
            failThreshold = thr;
            accountDone   = false;
            dayLocked     = false;
            guardDayKey   = TradingDayKey(eventTime);
            SaveGuardDay(guardDayKey);
            LogLine(why + " -- guard re-anchored at " + acctNL.ToString("0.00")
                + " (daily floor " + (acctNL - DailyLossLimitUsd).ToString("0.00")
                + ", fail " + failThreshold.ToString("0.00") + ")");
        }

        // --- Profit-target limit exit ----------------------------------------------
        //  A market flatten cannot reliably capture the target line: the trigger sees a
        //  spike tick and the order fills after the retreat. Measured on a live account,
        //  a $53,060 trigger realized $52,921 -- 3.2 points of give-up on a 2-lot, and
        //  the attempt failed by $79. Once the target is reachable from the open
        //  position, tighten the bracket to the exact price that realizes it plus a
        //  commission buffer, so the exit is a RESTING LIMIT filled at that price or
        //  better. Only ever tightens; the configured distance is restored once flat.
        private void MaintainTargetLimit(double px, double acctNL)
        {
            if (!UseTargetLimitExit)
                return;

            if (Position.MarketPosition == MarketPosition.Flat)
            {
                if (targetLimitArmed)
                {
                    try { SetProfitTarget(SignalName, CalculationMode.Ticks, (int)Math.Round(activeTargetPoints / TickSize)); }
                    catch { }
                    targetLimitArmed = false;
                }
                return;
            }

            if (targetLimitArmed || accountDone || activeTargetPoints <= 0)
                return;

            int    qty = Position.Quantity;
            double pv  = Instrument.MasterInstrument.PointValue;
            if (qty <= 0 || pv <= 0 || px <= 0 || TickSize <= 0)
                return;

            // Subtract the SAME reported unrealized that is embedded in acctNL so the
            // two cancel exactly. What remains is cash-equivalent equity, which cannot
            // move while the position is open and is therefore staleness-proof.
            double flatEq  = acctNL - Account.Get(AccountItem.UnrealizedProfitLoss, Currency.UsDollar);
            double needUsd = (StartingBalanceUsd + ProfitTargetUsd + TargetBufferUsd) - flatEq;
            if (needUsd <= 0)
                return;                               // already past it flat: the flatten path owns this

            double needPts = needUsd / (pv * qty);
            if (needPts >= activeTargetPoints)
                return;                               // the bracket is already closer; never loosen

            int    dir       = Position.MarketPosition == MarketPosition.Long ? 1 : -1;
            double passPrice = Position.AveragePrice + dir * needPts;
            passPrice = dir > 0 ? Math.Ceiling(passPrice / TickSize) * TickSize
                                : Math.Floor(passPrice / TickSize) * TickSize;

            // A price already at or through the market would be a marketable limit. In
            // that state the position is worth more than the target needs anyway, so
            // leave it to the flatten path and retry on the next tick.
            if (dir > 0 && passPrice <= px) return;
            if (dir < 0 && passPrice >= px) return;

            try { SetProfitTarget(SignalName, CalculationMode.Price, passPrice); }
            catch { return; }

            targetLimitArmed = true;
            LogLine("target limit armed @ " + passPrice.ToString("0.00")
                + " (needs " + needPts.ToString("0.00") + " pts vs bracket "
                + activeTargetPoints.ToString("0.##") + "; flat equity " + flatEq.ToString("0.00") + ")");
        }

        // --- Clock rules -----------------------------------------------------------
        //  HardFlatCheck runs on every bar AND every tick and keeps re-checking until
        //  19:00 ET, so a stray fill after the cutoff (an orphaned resting limit, a
        //  manual add) is closed rather than carried overnight. 19:00 is before the
        //  earliest legitimate entry window, so the sweep can never fight a new session.
        private bool PastEntryCutoff(int nowHHMM)
        {
            return nowHHMM >= HardNoEntryHHMM && nowHHMM < HardFlatEndHHMM;
        }

        private void HardFlatCheck(DateTime eventTime)
        {
            int now = ToTime(eventTime) / 100;
            if (now < HardFlatHHMM || now >= HardFlatEndHHMM) return;
            if (Position.MarketPosition != MarketPosition.Flat) FlattenNow();
        }

        private void FlattenNow()
        {
            if (Position.MarketPosition == MarketPosition.Long) ExitLong();
            else if (Position.MarketPosition == MarketPosition.Short) ExitShort();
        }

        // Pure suppressor: it can only decline an entry, never invent one.
        // AvoidLunchChop is the fixed 12:00-13:00 ET window. NewsBlackoutHHMM is yours
        // to fill in each morning ("0830-0900;1400-1430") -- event dates move every
        // month, so nothing is guessed for you and nothing is downloaded.
        private bool InNewsBlackout(int nowHHMM)
        {
            if (AvoidLunchChop && nowHHMM >= 1200 && nowHHMM < 1300) return true;
            if (string.IsNullOrEmpty(NewsBlackoutHHMM)) return false;
            foreach (var range in NewsBlackoutHHMM.Split(';'))
            {
                var parts = range.Split('-');
                if (parts.Length != 2) continue;
                int s, e;
                if (!int.TryParse(parts[0].Trim(), out s)) continue;
                if (!int.TryParse(parts[1].Trim(), out e)) continue;
                if (nowHHMM >= s && nowHHMM < e) return true;
            }
            return false;
        }

        private int TradingDayKey(DateTime t)
        {
            DateTime d = (t.Hour * 100 + t.Minute >= 1700) ? t.Date.AddDays(1) : t.Date;
            return d.Year * 10000 + d.Month * 100 + d.Day;
        }

        // --- Guard-day persistence --------------------------------------------------
        //  dayStartBalance / peakBalance / failThreshold survive a NinjaTrader or
        //  strategy restart via one small file per strategy instance, written under
        //  your NinjaTrader user data folder. Fail-open: any IO problem falls back to
        //  deriving the anchor, with a note in the Output window.
        private string GuardDayFile
        {
            get
            {
                return System.IO.Path.Combine(
                    NinjaTrader.Core.Globals.UserDataDir, "TrendPullback", Name + "_guardday.txt");
            }
        }

        private bool TryLoadGuardDay(int key)
        {
            try
            {
                if (!System.IO.File.Exists(GuardDayFile)) return false;
                var parts = System.IO.File.ReadAllText(GuardDayFile).Trim().Split('|');
                if (parts.Length != 4) return false;
                if (int.Parse(parts[0], System.Globalization.CultureInfo.InvariantCulture) != key) return false;
                dayStartBalance = double.Parse(parts[1], System.Globalization.CultureInfo.InvariantCulture);
                peakBalance     = double.Parse(parts[2], System.Globalization.CultureInfo.InvariantCulture);
                failThreshold   = double.Parse(parts[3], System.Globalization.CultureInfo.InvariantCulture);
                return true;
            }
            catch { return false; }
        }

        private void SaveGuardDay(int key)
        {
            try
            {
                string path = GuardDayFile;
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path));
                System.IO.File.WriteAllText(path,
                    key.ToString(System.Globalization.CultureInfo.InvariantCulture) + "|"
                    + dayStartBalance.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) + "|"
                    + peakBalance.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) + "|"
                    + failThreshold.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture));
            }
            catch (Exception ex)
            {
                LogLine("guard-day state save failed: " + ex.Message);
            }
        }

        // Every failure in this strategy says so out loud. Nothing here fails silently.
        private void LogLine(string message)
        {
            try
            {
                NinjaTrader.Code.Output.Process(DateTime.Now.ToString("HH:mm:ss")
                    + " [" + Name + "] " + message, PrintTo.OutputTab1);
            }
            catch { }
        }

        #region Properties
        [NinjaScriptProperty]
        [Display(Name = "Preset", Order = 1, GroupName = "1. Setup", Description = "Which published configuration to trade. Passed straight to TrendPullbackSignal.")]
        public TrendPullbackPreset Preset { get; set; }

        [NinjaScriptProperty]
        [Range(1, 50)]
        [Display(Name = "Contracts", Order = 2, GroupName = "1. Setup")]
        public int Contracts { get; set; }

        [NinjaScriptProperty]
        [Range(1, 999)]
        [Display(Name = "Max trades / session", Order = 3, GroupName = "1. Setup")]
        public int MaxTradesPerSession { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Avoid lunch chop (12:00-13:00 ET)", Order = 4, GroupName = "1. Setup")]
        public bool AvoidLunchChop { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "News blackout (HHMM-HHMM;...)", Order = 5, GroupName = "1. Setup")]
        public string NewsBlackoutHHMM { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Account mode", Order = 1, GroupName = "2. Account rules", Description = "Sim: the strategy enforces the daily loss limit, the trailing drawdown and the profit target. Eval: the funding company enforces the daily loss limit, the strategy still stops and banks the profit target. Off: no account limits at all.")]
        public TrendPullbackAccountMode AccountMode { get; set; }

        [NinjaScriptProperty]
        [Range(1000, 10000000)]
        [Display(Name = "Starting balance ($)", Order = 2, GroupName = "2. Account rules")]
        public double StartingBalanceUsd { get; set; }

        [NinjaScriptProperty]
        [Range(100, 1000000)]
        [Display(Name = "Profit target ($)", Order = 3, GroupName = "2. Account rules")]
        public double ProfitTargetUsd { get; set; }

        [NinjaScriptProperty]
        [Range(100, 1000000)]
        [Display(Name = "Trailing drawdown ($)", Order = 4, GroupName = "2. Account rules")]
        public double TrailingDrawdownUsd { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trailing locks at start balance", Order = 5, GroupName = "2. Account rules", Description = "True for the common 'threshold stops trailing once it reaches your starting balance' rule.")]
        public bool LockTrailingAtStart { get; set; }

        [NinjaScriptProperty]
        [Range(0, 1000000)]
        [Display(Name = "Daily loss limit ($, Sim only, 0 = off)", Order = 6, GroupName = "2. Account rules", Description = "Applies in Sim mode. Set it BELOW your provider's hard number so you stop before you breach it. Ignored in Eval, where the provider enforces its own.")]
        public double DailyLossLimitUsd { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use target limit exit", Order = 7, GroupName = "2. Account rules", Description = "Converts the bracket target to the exact price that banks the profit target, once it is in reach.")]
        public bool UseTargetLimitExit { get; set; }
        #endregion
    }
}
