# CLAUDE.md

Guidance for Claude Code when working in this package. `AGENTS.md` has the long form and
the reasoning; this file is the short version you should hold in your head.

## Project

A NinjaTrader 8 trading system, two files, shipped as a free download:

- `Indicators/TrendPullbackSignal.cs` — the signal engine and the manual-trading
  display. Places no orders. This is what a trader on a funded account uses.
- `Strategies/TrendPullbackB.cs` — the automated half. Orders, account guard, clock
  rules. It **calls the indicator** for its signals.

There is no build system. NinjaTrader compiles these in place (Tools → New NinjaScript →
Compile). There are no tests to run; verification is a Market Replay session.

## Rules

1. **Signal logic lives in the indicator only.** Never copy an entry condition into the
   strategy, not even a simplified one. The package's entire promise is that the chart
   and the strategy cannot disagree.
2. **The strategy may only decline a signal, never create one.**
3. **Never promote a risk constant to a property.** `EntryRetracePct`, `AtrStopMult`,
   `StopFloorPoints`, `StopCapPoints`, `MaxRMultiple` and the three `HardFlat*` /
   `HardNoEntry*` clock constants are `const` on purpose: a configured NinjaTrader
   strategy instance keeps its saved property values, so a risk rule expressed as a
   property is silently defeated on every instance that already exists.
4. **Never add a `[NinjaScriptProperty]` to the indicator.** Exactly two exist —
   `Preset` then `ShowVisuals` — and NinjaTrader builds the strategy's call signature
   from them. Everything else is a plain `[Display]` property.
5. **Leave the `#region NinjaScript generated code` block at the bottom of
   `TrendPullbackSignal.cs` to NinjaTrader.** It is the wrapper that makes the indicator
   callable from the strategy. Do not delete it and never hand-write one: NinjaTrader
   appends its own on compile instead of replacing yours, and two copies fail with
   `CS0111` / `CS0121` duplicate-member errors. To change it, delete the whole region
   and let the next compile rewrite it.
6. **Pure ASCII, C# 5 syntax, no `$` interpolation.** Non-ASCII has broken compiles here.
7. **No hardcoded paths, no network calls, no silent catches.** Disk access resolves
   from `NinjaTrader.Core.Globals.UserDataDir`. Failures print to the NinjaScript Output
   window.

## Things that look like bugs and are not

- The VWAP accumulates only inside the entry window and resets at midnight. It is
  window-anchored on purpose.
- The fill bar checks the stop but not the target, and ambiguous bars count as stops.
  That pessimism is deliberate and documented.
- The entry limit lives for one bar and is allowed to expire unfilled about a third of
  the time. Not chasing is the edge, not a defect.
- `Calculate` is forced back to `OnBarClose` in `State.Configure`.

Full reasoning for each of these is in `AGENTS.md` under "Parity invariants".

## If you change a signal rule

The pass-rate numbers in `README.md` describe the code as published. Change a condition
and those numbers no longer apply — re-test over the same window or remove the claim.
Say so in your summary rather than leaving the README quietly wrong.
