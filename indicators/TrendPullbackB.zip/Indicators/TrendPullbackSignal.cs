#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Text;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// TrendPullbackSignal -- the manual-execution half of the Trend Pullback family.
//
// WHY THIS EXISTS
//   Most funding companies let you use tools, but not let a robot trade the account
//   for you. This indicator is the signal engine of the TrendPullback strategies with
//   the order routing removed: it marks the setup, prices the entry, the stop and the
//   target, and then stands aside. You place the orders.
//
//   It is not a lookalike of the strategy -- it IS the strategy's signal code. The
//   TrendPullbackB strategy in this package calls this indicator for its signals
//   rather than keeping a second copy of the rules, so what you are shown and what an
//   automated run would have taken cannot drift apart. Change a rule here and you have
//   changed it for both. That is the point.
//
// WHAT IT DRAWS
//   * an arrow on the bar that fired the setup
//   * the retracement limit price, live for exactly one bar (the strategy cancels the
//     order if it does not fill in that bar -- a setup that never comes back to you is
//     one you decline to chase)
//   * stop and target lines once the entry is taken
//   * a panel with the numbers you need to place the order by hand, plus the clock
//     rules (no new entry after 15:30 ET, flat by 15:45 ET)
//
// TIME ZONE
//   Every HHMM here is read from the chart's own clock. The published presets are
//   written in US Eastern, so set NinjaTrader to Eastern (Tools > Options > General >
//   Time zone) or translate the session hours yourself.
//
// MIT licensed. No warranty and no guarantee of profit. See LICENSE and README.md.

public enum TrendPullbackPreset
{
    VariantB_European,
    VariantA_Asian,
    VariantA_US,
    Custom
}

public enum TrendPullbackLevel
{
    Ema,
    Vwap,
    EmaOrVwap
}

public enum TrendPullbackTriggerMode
{
    Touch,
    Rejection,
    Reclaim
}

public enum TrendPullbackCorner
{
    TopLeft,
    TopRight,
    BottomLeft,
    BottomRight
}

// Sounds that ship with NinjaTrader 8, plus None (no alert for that event) and
// Custom (plays the file named in "Custom sound file").
public enum TrendPullbackSound
{
    None,
    Alert1,
    Alert2,
    Alert3,
    Alert4,
    Announcement,
    OrderFilled,
    TargetFilled,
    StopFilled,
    Reversing,
    Custom
}

namespace NinjaTrader.NinjaScript.Indicators.PhillyFranksTools
{
    public class TrendPullbackSignal : Indicator
    {
        // --- Bracket construction, shared with the strategy -----------------------
        //  Consts, not settings, for the same reason they are consts in the strategy:
        //  they are the tested shape of the trade. A saved instance keeps its own
        //  property values forever, so a risk rule written as a property is silently
        //  defeated on every instance that already exists.
        private const double EntryRetracePct  = 0.25;   // give-back into the trigger bar
        private const double AtrStopMult      = 1.5;    // 1.5 x ATR(14) at the signal bar
        private const double StopFloorPoints  = 15.0;   // never tighter than this
        private const double StopCapPoints    = 40.0;   // nor wider, unless configured wider
        private const double MaxRMultiple     = 3.0;    // ceiling on the scaled R:R

        // --- Clock rules ----------------------------------------------------------
        private const int HardNoEntryHHMM = 1530;   // no new setup is priced at/after this
        private const int HardFlatHHMM    = 1545;   // anything still open is out
        private const int HardFlatEndHHMM = 1900;   // sweep ends before the Asian window

        private const int MinBarsRequired = 25;

        // Effective (preset-resolved) parameters. Everything downstream reads these and
        // never the public properties, so Custom and preset runs take one code path.
        private bool                     effUseAdx;
        private double                   effAdxThreshold;
        private double                   effEmaSlopeMin;
        private TrendPullbackLevel       effPullbackTo;
        private TrendPullbackTriggerMode effTrigger;
        private double                   effStopPoints;
        private double                   effTargetPoints;
        private int                      effSessionStart;
        private int                      effSessionEnd;
        private string                   effPresetName = "";

        // Window-anchored VWAP. The strategy accumulates price*volume only on bars
        // inside its entry window and resets on the calendar date, so this VWAP is
        // anchored to the first in-window bar of the day -- it is not a 24h session
        // VWAP. Reproduced exactly; changing it changes the signals.
        private double   cumPV, cumVol;
        private DateTime lastDate = DateTime.MinValue;

        // Follow-along state machine. 0 = nothing, 1 = limit working (this bar only),
        // 2 = in the trade.
        private int    followState;
        private int    followDir;              // 1 long, -1 short
        private double limitPx, stopPx, targetPx, entryPx;
        private double stopPts, targetPts;
        private int    signalBar, entryBar;
        private int    tradesThisSession;
        private int    sessionWins, sessionLosses;
        private string lastOutcome = "";
        private int    currentRegime;          // 0 Unknown 1 Breakout 2 QuietTrend 3 Balance 4 Chop
        private int    drawSeq;                // unique tag suffix per setup
        private bool   forcedBarClose;

        [Browsable(false)] [XmlIgnore] public Series<double> Signal         { get; private set; }
        [Browsable(false)] [XmlIgnore] public Series<double> EntryLimit     { get; private set; }
        [Browsable(false)] [XmlIgnore] public Series<double> StopDistance   { get; private set; }
        [Browsable(false)] [XmlIgnore] public Series<double> TargetDistance { get; private set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name                     = "TrendPullbackSignal";
                Description              = "Trend Pullback setups priced for manual execution. Draws the entry, stop and target the strategy would have used, and places no orders.";
                Calculate                = Calculate.OnBarClose;
                IsOverlay                = true;
                DrawOnPricePanel         = true;
                DisplayInDataBox         = false;
                PaintPriceMarkers        = false;
                IsSuspendedWhileInactive = false;

                Preset      = TrendPullbackPreset.VariantB_European;
                ShowVisuals = true;

                UseAdx              = false;
                AdxThreshold        = 20;
                EmaSlopeMin         = 0.3;
                PullbackTo          = TrendPullbackLevel.EmaOrVwap;
                EntryTrigger        = TrendPullbackTriggerMode.Touch;
                StopPoints          = 15;
                TargetPoints        = 30;
                SessionStartHHMM    = 300;
                SessionEndHHMM      = 800;
                MaxTradesPerSession = 99;
                AvoidLunchChop      = false;
                NewsBlackoutHHMM    = string.Empty;

                ShowPanel       = true;
                PanelCorner     = TrendPullbackCorner.TopRight;
                PanelFontSize   = 13;
                ShowLevelPlot   = true;
                EnableAlerts    = true;
                SetupSound      = TrendPullbackSound.Alert1;
                FillSound       = TrendPullbackSound.None;
                ExpirySound     = TrendPullbackSound.None;
                CustomSoundFile = string.Empty;
                RiskPerTradeUsd = 0;

                LongBrush   = Brushes.LimeGreen;
                ShortBrush  = Brushes.OrangeRed;
                StopBrush   = Brushes.IndianRed;
                TargetBrush = Brushes.MediumSeaGreen;
                PanelText   = Brushes.Gainsboro;
                PanelArea   = Brushes.Black;

                // The pullback level is a plot, not a drawing object: a Draw call per
                // bar would leave one object per bar on the chart for the life of the
                // session. Bars with no level simply go unassigned and the plot gaps.
                AddPlot(Brushes.DodgerBlue, "Pullback level");
            }
            else if (State == State.Configure)
            {
                // Bar-close parity is not optional. The strategy evaluates on closed
                // bars; an intrabar evaluation would show setups the strategy never
                // took and retract them as the bar moved.
                if (Calculate != Calculate.OnBarClose)
                {
                    Calculate      = Calculate.OnBarClose;
                    forcedBarClose = true;
                }
                ResolvePreset();
            }
            else if (State == State.DataLoaded)
            {
                Signal         = new Series<double>(this);
                EntryLimit     = new Series<double>(this);
                StopDistance   = new Series<double>(this);
                TargetDistance = new Series<double>(this);

                if (forcedBarClose)
                    Log(Name + ": Calculate was forced back to OnBarClose so the display matches the strategy.", LogLevel.Information);
            }
        }

        // Preset values are lifted verbatim from the strategies that ran the arena.
        // Custom hands control to the properties below, for research -- a tuned Custom
        // run is your configuration, not a published one.
        private void ResolvePreset()
        {
            switch (Preset)
            {
                case TrendPullbackPreset.VariantB_European:
                    effUseAdx = false; effAdxThreshold = 20; effEmaSlopeMin = 0.3;
                    effPullbackTo   = TrendPullbackLevel.EmaOrVwap;
                    effTrigger      = TrendPullbackTriggerMode.Touch;
                    effStopPoints   = 15; effTargetPoints = 30;
                    effSessionStart = 300; effSessionEnd = 800;
                    effPresetName   = "Variant B - European (03:00-08:00 ET)";
                    break;

                case TrendPullbackPreset.VariantA_Asian:
                    effUseAdx = true; effAdxThreshold = 25; effEmaSlopeMin = 0.5;
                    effPullbackTo   = TrendPullbackLevel.Vwap;
                    effTrigger      = TrendPullbackTriggerMode.Rejection;
                    effStopPoints   = 15; effTargetPoints = 30;
                    effSessionStart = 2000; effSessionEnd = 130;
                    effPresetName   = "Variant A - Asian (20:00-01:30 ET)";
                    break;

                case TrendPullbackPreset.VariantA_US:
                    effUseAdx = true; effAdxThreshold = 25; effEmaSlopeMin = 0.5;
                    effPullbackTo   = TrendPullbackLevel.Vwap;
                    effTrigger      = TrendPullbackTriggerMode.Rejection;
                    effStopPoints   = 15; effTargetPoints = 30;
                    effSessionStart = 930; effSessionEnd = 1530;
                    effPresetName   = "Variant A - US (09:30-15:30 ET)";
                    break;

                default:
                    effUseAdx     = UseAdx; effAdxThreshold = AdxThreshold; effEmaSlopeMin = EmaSlopeMin;
                    effPullbackTo = PullbackTo; effTrigger = EntryTrigger;
                    effStopPoints = StopPoints; effTargetPoints = TargetPoints;
                    effSessionStart = SessionStartHHMM; effSessionEnd = SessionEndHHMM;
                    effPresetName = "Custom";
                    break;
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < MinBarsRequired)
                return;

            Signal[0]         = 0;
            EntryLimit[0]     = 0;
            StopDistance[0]   = 0;
            TargetDistance[0] = 0;

            if (Time[0].Date != lastDate)
            {
                cumPV = 0; cumVol = 0; tradesThisSession = 0;
                sessionWins = 0; sessionLosses = 0;
                lastDate = Time[0].Date;
            }

            int now = ToTime(Time[0]) / 100;

            // A trade that is already on is managed on every bar, in or out of the
            // entry window -- the strategy's bracket does not care what time it is.
            MaintainOpenTrade(now);

            if (!InEntryWindow(now))
            {
                DrawPanel(now, "OUT OF WINDOW");
                return;
            }

            cumPV  += (High[0] + Low[0] + Close[0]) / 3.0 * Volume[0];
            cumVol += Volume[0];

            ClassifyRegime();

            // The blackout suppresses the signal itself, exactly as it does in the
            // strategy. Being in a trade does not: the strategy computes its signal
            // first and only then checks that it is flat, so the published Signal
            // series has to be computed the same way or a hosting strategy would see
            // a different set of bars than this file describes.
            if (InNewsBlackout(now))
            {
                DrawPanel(now, null);
                return;
            }

            double price    = Close[0];
            double ema      = EMA(20)[0];
            double emaSlope = (EMA(20)[0] - EMA(20)[5]) / 5.0;
            double adx      = ADX(14)[0];
            double atr      = ATR(14)[0];
            double vwap     = cumVol > 0 ? cumPV / cumVol : price;

            int trend = 0;
            if (!(effUseAdx && adx < effAdxThreshold))
            {
                if (emaSlope > effEmaSlopeMin && price > ema) trend = 1;
                else if (emaSlope < -effEmaSlopeMin && price < ema) trend = -1;
            }
            if (trend == 0)
            {
                DrawPanel(now, null);
                return;
            }

            double level = effPullbackTo == TrendPullbackLevel.Vwap ? vwap
                         : effPullbackTo == TrendPullbackLevel.EmaOrVwap
                             ? (trend == 1 ? Math.Max(ema, vwap) : Math.Min(ema, vwap))
                             : ema;

            if (ShowLevelPlot)
                Values[0][0] = level;

            int signal = 0;
            if (trend == 1 && Low[0] <= level + atr * 0.3 && TriggerFires(1, level)) signal = 1;
            else if (trend == -1 && High[0] >= level - atr * 0.3 && TriggerFires(-1, level)) signal = -1;

            if (signal == 0)
            {
                DrawPanel(now, null);
                return;
            }

            PublishSetup(signal, atr);
            DrawPanel(now, null);
        }

        // Price the order exactly the way the strategy prices it: a limit set
        // EntryRetracePct back inside the trigger bar, with an ATR-scaled bracket whose
        // R multiple comes from the configured stop/target ratio. The numbers are
        // published on the series either way; the follow display only arms when the
        // strategy would actually have been able to take the trade.
        private void PublishSetup(int dir, double atr)
        {
            double rng = High[0] - Low[0];
            double px  = dir == 1 ? Close[0] - EntryRetracePct * rng
                                  : Close[0] + EntryRetracePct * rng;
            if (rng <= 0 || px <= 0) px = Close[0];
            try { px = Instrument.MasterInstrument.RoundToTickSize(px); } catch { }

            // The clamp may only ever WIDEN a configured stop, never tighten it.
            double lo = Math.Max(StopFloorPoints, effStopPoints);
            double hi = Math.Max(StopCapPoints, lo);
            double sp = atr > 0 ? Math.Max(lo, Math.Min(hi, AtrStopMult * atr)) : lo;
            double r  = Math.Min(MaxRMultiple, effStopPoints > 0 ? effTargetPoints / effStopPoints : 1.0);

            double stopDistance, targetDistance;
            if (TickSize > 0)
            {
                stopDistance   = Math.Round(sp / TickSize) * TickSize;
                targetDistance = Math.Round(sp * r / TickSize) * TickSize;
            }
            else
            {
                stopDistance   = sp;
                targetDistance = sp * r;
            }

            Signal[0]         = dir;
            EntryLimit[0]     = px;
            StopDistance[0]   = stopDistance;
            TargetDistance[0] = targetDistance;

            // Already following one, or out of setups for the session: the strategy
            // would decline this, so the chart declines it too and says why.
            if (followState != 0)
            {
                lastOutcome = "SETUP SKIPPED - already in a trade";
                return;
            }
            if (tradesThisSession >= MaxTradesPerSession)
            {
                lastOutcome = "SETUP SKIPPED - session limit reached";
                return;
            }

            stopPts     = stopDistance;
            targetPts   = targetDistance;
            followState = 1;
            followDir   = dir;
            limitPx     = px;
            signalBar   = CurrentBar;
            stopPx      = dir == 1 ? px - stopPts   : px + stopPts;
            targetPx    = dir == 1 ? px + targetPts : px - targetPts;
            drawSeq++;

            if (ShowVisuals && ChartControl != null)
            {
                Brush  b = dir == 1 ? LongBrush : ShortBrush;
                string t = "tp" + drawSeq;
                if (dir == 1) Draw.ArrowUp(this, t + "arw", false, 0, Low[0] - 2 * TickSize, b);
                else          Draw.ArrowDown(this, t + "arw", false, 0, High[0] + 2 * TickSize, b);
                Draw.Text(this, t + "txt", (dir == 1 ? "LONG limit " : "SHORT limit ")
                    + limitPx.ToString("0.00", CultureInfo.InvariantCulture),
                    0, dir == 1 ? Low[0] - 6 * TickSize : High[0] + 6 * TickSize, b);
                DrawFollowLines();
            }

            RaiseAlert("tpSetup", SetupSound, Priority.High,
                (dir == 1 ? "LONG" : "SHORT") + " Trend Pullback setup -- limit "
                + limitPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ", stop " + stopPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ", target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture)
                + ". Valid for one bar.",
                dir == 1 ? LongBrush : ShortBrush);
        }

        // One alert path for every event. A sound of None means no alert is raised for
        // that event at all, which is why the fill and expiry cues ship silent: you opt
        // into them rather than having them appear in your Alerts window uninvited.
        //
        // ShowVisuals gates this as well as EnableAlerts. A strategy hosts this
        // indicator with ShowVisuals = false and inherits every other property from
        // SetDefaults -- including EnableAlerts = true -- so without this the invisible
        // compute-only copy would alert alongside the one on your chart.
        private void RaiseAlert(string id, TrendPullbackSound sound, Priority priority,
            string message, Brush foreground)
        {
            if (!EnableAlerts || !ShowVisuals || sound == TrendPullbackSound.None)
                return;
            try
            {
                Alert(id + drawSeq, priority, message, SoundPath(sound),
                    10, Brushes.Black, foreground);
            }
            catch { }
        }

        // NinjaTrader wants a full path; a bare file name is resolved against the
        // install's own sounds folder, so the stock choices work on any machine.
        private string SoundPath(TrendPullbackSound sound)
        {
            string file = sound == TrendPullbackSound.Custom
                ? (CustomSoundFile ?? string.Empty).Trim()
                : sound.ToString() + ".wav";

            if (file.Length == 0)
                return string.Empty;
            if (file.IndexOf('\\') >= 0 || file.IndexOf('/') >= 0)
                return file;
            return NinjaTrader.Core.Globals.InstallDir + @"sounds\" + file;
        }

        // Resolve a working limit, then manage an open trade. Deliberately pessimistic
        // wherever one bar cannot tell you the order of events:
        //   * on the bar the limit fills, only the stop is checked. A backtest that
        //     credits a target on the fill bar reports profit factors it never earned.
        //   * from the next bar on, a bar that touches both is recorded as the stop.
        // Your real fill may be better than this. It should rarely be worse.
        private void MaintainOpenTrade(int now)
        {
            if (followState == 0)
                return;

            if (followState == 1)
            {
                if (CurrentBar <= signalBar)
                    return;

                bool filled = followDir == 1 ? Low[0] <= limitPx : High[0] >= limitPx;
                if (!filled)
                {
                    RaiseAlert("tpExpiry", ExpirySound, Priority.Medium,
                        "Trend Pullback limit expired unfilled at "
                        + limitPx.ToString("0.00", CultureInfo.InvariantCulture)
                        + " -- cancel the order and stand down.",
                        Brushes.DimGray);
                    CloseFollow("EXPIRED - no fill, stand down", 0, limitPx);
                    return;
                }

                // A gap through the limit fills at the open, in your favour.
                entryPx  = followDir == 1 ? Math.Min(limitPx, Open[0]) : Math.Max(limitPx, Open[0]);
                stopPx   = followDir == 1 ? entryPx - stopPts   : entryPx + stopPts;
                targetPx = followDir == 1 ? entryPx + targetPts : entryPx - targetPts;
                entryBar    = CurrentBar;
                followState = 2;
                tradesThisSession++;
                DrawFollowLines();

                RaiseAlert("tpFill", FillSound, Priority.Medium,
                    (followDir == 1 ? "LONG" : "SHORT") + " Trend Pullback limit filled at "
                    + entryPx.ToString("0.00", CultureInfo.InvariantCulture)
                    + " -- stop " + stopPx.ToString("0.00", CultureInfo.InvariantCulture)
                    + ", target " + targetPx.ToString("0.00", CultureInfo.InvariantCulture) + ".",
                    followDir == 1 ? LongBrush : ShortBrush);

                // Fill bar: stop only.
                if (followDir == 1 ? Low[0] <= stopPx : High[0] >= stopPx)
                    CloseFollow("STOPPED", -1, stopPx);
                return;
            }

            if (now >= HardFlatHHMM && now < HardFlatEndHHMM)
            {
                double points = (Close[0] - entryPx) * followDir;
                CloseFollow("FLAT 15:45 ET - session rule", points < 0 ? -1 : 0, Close[0]);
                return;
            }

            bool hitStop   = followDir == 1 ? Low[0]  <= stopPx   : High[0] >= stopPx;
            bool hitTarget = followDir == 1 ? High[0] >= targetPx : Low[0]  <= targetPx;

            if (hitStop)        CloseFollow("STOPPED", -1, stopPx);
            else if (hitTarget) CloseFollow("TARGET", 1, targetPx);
            else                DrawFollowLines();
        }

        // result: 1 target, -1 stop, 0 neither (an expiry or a flat on the clock).
        private void CloseFollow(string outcome, int result, double markPx)
        {
            if (ShowVisuals && ChartControl != null)
            {
                DrawFollowLines();   // extend the lines to the bar that ended it
                string t = "tp" + drawSeq;
                if (followState == 1)
                    Draw.Dot(this, t + "exp", false, 0, markPx, Brushes.DimGray);
                else
                    Draw.Diamond(this, t + "exit", false, 0, markPx,
                        result > 0 ? TargetBrush : result < 0 ? StopBrush : Brushes.Goldenrod);
            }

            lastOutcome = outcome;
            if (result > 0) sessionWins++;
            if (result < 0) sessionLosses++;
            followState = 0;
            followDir   = 0;
        }

        // Lines run from the bar that created them to the CURRENT bar and are redrawn
        // each update, rather than being projected into the future: one object per
        // setup, and it tracks the trade instead of floating off the right edge.
        private void DrawFollowLines()
        {
            if (!ShowVisuals || ChartControl == null || followState == 0)
                return;

            string t = "tp" + drawSeq;
            Brush  b = followDir == 1 ? LongBrush : ShortBrush;
            int    signalBars = Math.Max(0, CurrentBar - signalBar);

            if (followState == 1)
            {
                Draw.Line(this, t + "lim", false, signalBars, limitPx, 0, limitPx, b, DashStyleHelper.Dash, 2);
                return;
            }

            int entryBars = Math.Max(0, CurrentBar - entryBar);
            Draw.Line(this, t + "lim", false, signalBars, limitPx,  0, limitPx,  b,           DashStyleHelper.Dash,  1);
            Draw.Line(this, t + "stp", false, entryBars,  stopPx,   0, stopPx,   StopBrush,   DashStyleHelper.Solid, 2);
            Draw.Line(this, t + "tgt", false, entryBars,  targetPx, 0, targetPx, TargetBrush, DashStyleHelper.Solid, 2);
        }

        private bool TriggerFires(int dir, double level)
        {
            double o = Open[0], c = Close[0], h = High[0], l = Low[0];
            if (effTrigger == TrendPullbackTriggerMode.Touch)
                return true;

            if (effTrigger == TrendPullbackTriggerMode.Rejection)
            {
                double body = Math.Abs(c - o);
                if (dir == 1)
                {
                    double lowerWick = Math.Min(o, c) - l;
                    return lowerWick > body && l <= level && c > level;
                }
                double upperWick = h - Math.Max(o, c);
                return upperWick > body && h >= level && c < level;
            }

            if (effTrigger == TrendPullbackTriggerMode.Reclaim)
            {
                if (dir == 1) return l < level && c > level;
                return h > level && c < level;
            }
            return false;
        }

        private bool InEntryWindow(int now)
        {
            if (now >= HardNoEntryHHMM && now < HardFlatEndHHMM) return false;
            if (effSessionStart <= effSessionEnd) return now >= effSessionStart && now < effSessionEnd;
            return now >= effSessionStart || now < effSessionEnd;
        }

        private bool InNewsBlackout(int now)
        {
            if (AvoidLunchChop && now >= 1200 && now < 1300) return true;
            if (string.IsNullOrEmpty(NewsBlackoutHHMM)) return false;
            foreach (var range in NewsBlackoutHHMM.Split(';'))
            {
                var parts = range.Split('-');
                if (parts.Length != 2) continue;
                int s, e;
                if (!int.TryParse(parts[0].Trim(), out s)) continue;
                if (!int.TryParse(parts[1].Trim(), out e)) continue;
                if (now >= s && now < e) return true;
            }
            return false;
        }

        // Context only -- the regime never arms or blocks a setup. It is here because
        // "chop with an expanding range" is the state that takes accounts apart, and
        // you are the discretion the strategy does not have.
        private int ClassifyRegime()
        {
            if (CurrentBar < 100) return 0;
            double volRatio = ATR(14)[0] / SMA(ATR(14), 100)[0];
            double adx      = ADX(14)[0];

            bool expanding = (currentRegime == 1 || currentRegime == 4) ? volRatio > 1.00 : volRatio >= 1.20;
            bool trending  = (currentRegime == 1 || currentRegime == 2) ? adx > 18.0      : adx >= 22.0;

            if      ( trending &&  expanding) currentRegime = 1;
            else if ( trending && !expanding) currentRegime = 2;
            else if (!trending && !expanding) currentRegime = 3;
            else                              currentRegime = 4;
            return currentRegime;
        }

        private static string RegimeName(int r)
        {
            switch (r)
            {
                case 1:  return "Breakout (trend + expansion)";
                case 2:  return "Quiet trend";
                case 3:  return "Balance";
                case 4:  return "Chop + expansion";
                default: return "Unknown";
            }
        }

        private void DrawPanel(int now, string windowNote)
        {
            if (!ShowVisuals || !ShowPanel || ChartControl == null)
                return;

            double pointValue = 0;
            try { pointValue = Instrument.MasterInstrument.PointValue; } catch { }

            var sb = new StringBuilder(512);
            sb.Append("TREND PULLBACK - MANUAL FOLLOW").Append('\n');
            sb.Append(effPresetName).Append('\n');
            sb.Append("Clock ").Append(FormatHHMM(now));
            sb.Append("   window ").Append(FormatHHMM(effSessionStart)).Append('-').Append(FormatHHMM(effSessionEnd));
            if (windowNote != null) sb.Append("  [").Append(windowNote).Append(']');
            sb.Append('\n');
            sb.Append("Regime ").Append(RegimeName(currentRegime)).Append('\n');
            sb.Append("------------------------------------------\n");

            if (followState == 1)
            {
                sb.Append(followDir == 1 ? "WORKING LIMIT - LONG" : "WORKING LIMIT - SHORT").Append('\n');
                sb.Append("Valid for THIS BAR ONLY\n");
                sb.Append("Limit  ").Append(limitPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Stop   ").Append(stopPx.ToString("0.00", CultureInfo.InvariantCulture))
                  .Append("   (").Append(stopPts.ToString("0.##", CultureInfo.InvariantCulture)).Append(" pts)").Append('\n');
                sb.Append("Target ").Append(targetPx.ToString("0.00", CultureInfo.InvariantCulture))
                  .Append("   (").Append(targetPts.ToString("0.##", CultureInfo.InvariantCulture)).Append(" pts)").Append('\n');
            }
            else if (followState == 2)
            {
                sb.Append(followDir == 1 ? "IN TRADE - LONG" : "IN TRADE - SHORT").Append('\n');
                sb.Append("Entry  ").Append(entryPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Stop   ").Append(stopPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                sb.Append("Target ").Append(targetPx.ToString("0.00", CultureInfo.InvariantCulture)).Append('\n');
                double open = (Close[0] - entryPx) * followDir;
                sb.Append("Open   ").Append(open.ToString("+0.00;-0.00;0.00", CultureInfo.InvariantCulture)).Append(" pts")
                  .Append("   bars held ").Append(CurrentBar - entryBar).Append('\n');
            }
            else
            {
                sb.Append("NO SETUP - waiting\n");
                if (!string.IsNullOrEmpty(lastOutcome))
                    sb.Append("Last: ").Append(lastOutcome).Append('\n');
            }

            if (followState != 0 && pointValue > 0)
            {
                double riskPerContract = stopPts * pointValue;
                sb.Append("Risk   $").Append(riskPerContract.ToString("0", CultureInfo.InvariantCulture)).Append(" per contract");
                if (RiskPerTradeUsd > 0 && riskPerContract > 0)
                {
                    int size = (int)Math.Floor(RiskPerTradeUsd / riskPerContract);
                    sb.Append("   -> ").Append(size).Append(size == 1 ? " contract" : " contracts")
                      .Append(" at $").Append(RiskPerTradeUsd.ToString("0", CultureInfo.InvariantCulture));
                }
                sb.Append('\n');
            }

            sb.Append("------------------------------------------\n");
            sb.Append("Setups filled today ").Append(tradesThisSession).Append(" / ").Append(MaxTradesPerSession);
            sb.Append("    target ").Append(sessionWins).Append("  stop ").Append(sessionLosses).Append('\n');
            sb.Append("No new entry 15:30 ET  -  flat 15:45 ET\n");
            sb.Append("YOU place the orders. Nothing here trades.");

            Draw.TextFixed(this, "tpPanel", sb.ToString(), CornerToPosition(PanelCorner),
                PanelText, new SimpleFont("Consolas", PanelFontSize), Brushes.Transparent, PanelArea, 60);
        }

        private static string FormatHHMM(int hhmm)
        {
            int h = hhmm / 100, m = hhmm % 100;
            return h.ToString("00", CultureInfo.InvariantCulture) + ":" + m.ToString("00", CultureInfo.InvariantCulture);
        }

        private static TextPosition CornerToPosition(TrendPullbackCorner corner)
        {
            switch (corner)
            {
                case TrendPullbackCorner.TopLeft:     return TextPosition.TopLeft;
                case TrendPullbackCorner.BottomLeft:  return TextPosition.BottomLeft;
                case TrendPullbackCorner.BottomRight: return TextPosition.BottomRight;
                default:                              return TextPosition.TopRight;
            }
        }

        #region Properties
        // Only Preset and ShowVisuals carry [NinjaScriptProperty]: those two are the
        // generated constructor arguments a strategy passes. Holding the signature at
        // two arguments means adding a display option here never breaks the strategy.
        [NinjaScriptProperty]
        [Display(Name = "Preset", Order = 1, GroupName = "1. Setup", Description = "Published configuration to follow. Custom hands control to the parameters below.")]
        public TrendPullbackPreset Preset { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show visuals", Order = 2, GroupName = "1. Setup", Description = "Off when a strategy hosts this indicator for its signals.")]
        public bool ShowVisuals { get; set; }

        [Display(Name = "Use ADX filter", Order = 1, GroupName = "2. Custom rules")]
        public bool UseAdx { get; set; }

        [Range(5, 60)]
        [Display(Name = "ADX threshold", Order = 2, GroupName = "2. Custom rules")]
        public double AdxThreshold { get; set; }

        [Range(0, 20)]
        [Display(Name = "Min EMA(20) slope", Order = 3, GroupName = "2. Custom rules")]
        public double EmaSlopeMin { get; set; }

        [Display(Name = "Pull back to", Order = 4, GroupName = "2. Custom rules")]
        public TrendPullbackLevel PullbackTo { get; set; }

        [Display(Name = "Entry trigger", Order = 5, GroupName = "2. Custom rules")]
        public TrendPullbackTriggerMode EntryTrigger { get; set; }

        [Range(0.25, 200)]
        [Display(Name = "Stop (points)", Order = 6, GroupName = "2. Custom rules", Description = "Floor for the ATR stop and, with the target, the R multiple.")]
        public double StopPoints { get; set; }

        [Range(0.25, 200)]
        [Display(Name = "Target (points)", Order = 7, GroupName = "2. Custom rules")]
        public double TargetPoints { get; set; }

        [Range(0, 2400)]
        [Display(Name = "Session start (HHMM)", Order = 8, GroupName = "2. Custom rules")]
        public int SessionStartHHMM { get; set; }

        [Range(0, 2400)]
        [Display(Name = "Session end (HHMM)", Order = 9, GroupName = "2. Custom rules")]
        public int SessionEndHHMM { get; set; }

        [Range(1, 999)]
        [Display(Name = "Max setups / session", Order = 1, GroupName = "3. Filters")]
        public int MaxTradesPerSession { get; set; }

        [Display(Name = "Avoid lunch chop (12:00-13:00)", Order = 2, GroupName = "3. Filters")]
        public bool AvoidLunchChop { get; set; }

        [Display(Name = "News blackout (HHMM-HHMM;...)", Order = 3, GroupName = "3. Filters", Description = "Your own event windows, entered by hand. Nothing is downloaded.")]
        public string NewsBlackoutHHMM { get; set; }

        [Display(Name = "Show panel", Order = 1, GroupName = "4. Display")]
        public bool ShowPanel { get; set; }

        [Display(Name = "Panel corner", Order = 2, GroupName = "4. Display")]
        public TrendPullbackCorner PanelCorner { get; set; }

        [Range(8, 30)]
        [Display(Name = "Panel font size", Order = 3, GroupName = "4. Display")]
        public int PanelFontSize { get; set; }

        [Display(Name = "Plot pullback level", Order = 4, GroupName = "4. Display", Description = "Plots the EMA/VWAP level the setup is measured against. Style it under Plots.")]
        public bool ShowLevelPlot { get; set; }

        [Range(0, 100000)]
        [Display(Name = "Risk per trade ($, 0 = off)", Order = 6, GroupName = "4. Display", Description = "Shows how many contracts that budget buys at this stop distance. Sizing stays your decision.")]
        public double RiskPerTradeUsd { get; set; }

        [Display(Name = "Enable alerts", Order = 1, GroupName = "5. Alerts", Description = "Master switch. Off means no alert of any kind.")]
        public bool EnableAlerts { get; set; }

        [Display(Name = "Setup armed sound", Order = 2, GroupName = "5. Alerts", Description = "Plays when a setup fires and the limit goes live. None raises no alert for this event.")]
        public TrendPullbackSound SetupSound { get; set; }

        [Display(Name = "Limit filled sound", Order = 3, GroupName = "5. Alerts", Description = "Plays when price reaches the limit. Silent by default.")]
        public TrendPullbackSound FillSound { get; set; }

        [Display(Name = "Limit expired sound", Order = 4, GroupName = "5. Alerts", Description = "Plays when the limit lapses unfilled and you should cancel. Silent by default.")]
        public TrendPullbackSound ExpirySound { get; set; }

        [Display(Name = "Custom sound file", Order = 5, GroupName = "5. Alerts", Description = "Used by any event set to Custom. A .wav name resolves against NinjaTrader 8/sounds; a full path is taken as given.")]
        public string CustomSoundFile { get; set; }

        [XmlIgnore] [Display(Name = "Long", Order = 1, GroupName = "6. Colors")]
        public Brush LongBrush { get; set; }
        [Browsable(false)]
        public string LongBrushSerialize { get { return Serialize.BrushToString(LongBrush); } set { LongBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Short", Order = 2, GroupName = "6. Colors")]
        public Brush ShortBrush { get; set; }
        [Browsable(false)]
        public string ShortBrushSerialize { get { return Serialize.BrushToString(ShortBrush); } set { ShortBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Stop", Order = 3, GroupName = "6. Colors")]
        public Brush StopBrush { get; set; }
        [Browsable(false)]
        public string StopBrushSerialize { get { return Serialize.BrushToString(StopBrush); } set { StopBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Target", Order = 4, GroupName = "6. Colors")]
        public Brush TargetBrush { get; set; }
        [Browsable(false)]
        public string TargetBrushSerialize { get { return Serialize.BrushToString(TargetBrush); } set { TargetBrush = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Panel text", Order = 6, GroupName = "6. Colors")]
        public Brush PanelText { get; set; }
        [Browsable(false)]
        public string PanelTextSerialize { get { return Serialize.BrushToString(PanelText); } set { PanelText = Serialize.StringToBrush(value); } }

        [XmlIgnore] [Display(Name = "Panel background", Order = 7, GroupName = "6. Colors")]
        public Brush PanelArea { get; set; }
        [Browsable(false)]
        public string PanelAreaSerialize { get { return Serialize.BrushToString(PanelArea); } set { PanelArea = Serialize.StringToBrush(value); } }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PhillyFranksTools.TrendPullbackSignal[] cacheTrendPullbackSignal;
		public PhillyFranksTools.TrendPullbackSignal TrendPullbackSignal(TrendPullbackPreset preset, bool showVisuals)
		{
			return TrendPullbackSignal(Input, preset, showVisuals);
		}

		public PhillyFranksTools.TrendPullbackSignal TrendPullbackSignal(ISeries<double> input, TrendPullbackPreset preset, bool showVisuals)
		{
			if (cacheTrendPullbackSignal != null)
				for (int idx = 0; idx < cacheTrendPullbackSignal.Length; idx++)
					if (cacheTrendPullbackSignal[idx] != null && cacheTrendPullbackSignal[idx].Preset == preset && cacheTrendPullbackSignal[idx].ShowVisuals == showVisuals && cacheTrendPullbackSignal[idx].EqualsInput(input))
						return cacheTrendPullbackSignal[idx];
			return CacheIndicator<PhillyFranksTools.TrendPullbackSignal>(new PhillyFranksTools.TrendPullbackSignal(){ Preset = preset, ShowVisuals = showVisuals }, input, ref cacheTrendPullbackSignal);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PhillyFranksTools.TrendPullbackSignal TrendPullbackSignal(TrendPullbackPreset preset, bool showVisuals)
		{
			return indicator.TrendPullbackSignal(Input, preset, showVisuals);
		}

		public Indicators.PhillyFranksTools.TrendPullbackSignal TrendPullbackSignal(ISeries<double> input , TrendPullbackPreset preset, bool showVisuals)
		{
			return indicator.TrendPullbackSignal(input, preset, showVisuals);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PhillyFranksTools.TrendPullbackSignal TrendPullbackSignal(TrendPullbackPreset preset, bool showVisuals)
		{
			return indicator.TrendPullbackSignal(Input, preset, showVisuals);
		}

		public Indicators.PhillyFranksTools.TrendPullbackSignal TrendPullbackSignal(ISeries<double> input , TrendPullbackPreset preset, bool showVisuals)
		{
			return indicator.TrendPullbackSignal(input, preset, showVisuals);
		}
	}
}

#endregion
