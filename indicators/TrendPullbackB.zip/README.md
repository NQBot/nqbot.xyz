# Trend Pullback B — strategy + manual signal indicator (NinjaTrader 8)

Two files. One set of rules.

- **`Indicators/TrendPullbackSignal.cs`** — draws the setup, prices the entry, stop and
  target, alerts you, and places **no orders**. This is the one to use on a funded or
  evaluation account.
- **`Strategies/TrendPullbackB.cs`** — the automated version, for simulation, Market
  Replay and your own capital. It does not contain a copy of the entry rules; it calls
  the indicator for them.

That second point is the whole design. There is exactly one copy of the signal logic in
this package, so the chart cannot drift away from what the strategy does.

---

## The honest record

These strategies ran in a simulated evaluation arena — one NinjaTrader sim account per
strategy, each one playing out a $50,000 / +$3,000 target / $2,000 trailing-drawdown
evaluation over and over.

**Trend Pullback B, 8 July – 17 September 2026: 20 attempts, 9 passed, 11 failed. 45%.**

Read that properly before you get excited:

- **11 of 20 attempts hit the drawdown limit.** More than half of the runs ended in
  failure. A 45% pass rate was the best number in a field of 32, which tells you more
  about how hard evaluations are than about how good this is.
- **A pass rate is not an edge.** What produces passes here is the combination of a
  modest geometric edge, hard discipline rules, and an account guard that stops trading
  the moment the target is banked. Take the discipline away and the number collapses.
- **Simulated fills, one instrument, one ten-week window.** NQ, 1-minute bars, sim
  account fills, no slippage stress, no audit. Nothing here is verified by a third
  party, and nothing here was traded by hand.
- **The manual indicator was not what produced that record** — the automated strategy
  was. Your fills, your reaction time and your nerve are now part of the system.

Past results do not predict future results. This is a tool, not a promise.

---

## What you need

| | |
|---|---|
| Platform | NinjaTrader 8 (8.1.x) |
| Instrument | NQ or MNQ — the stop floor and cap are written in NQ points |
| Chart | **1-minute**, ETH (24-hour) session template |
| Time zone | **US Eastern.** Tools → Options → General → Time zone. Every session hour in this package is Eastern. |
| Warmup | 25 bars minimum; 100+ before the regime line is meaningful |

If you run this on a different instrument, the 15–40 point stop clamp is meaningless and
you must re-derive it. On ES, 15 points is a different animal entirely.

---

## Install

1. NinjaTrader → **Control Center → Tools → Import → NinjaScript Add-On…**
2. Pick `TrendPullbackB.zip`.
3. Restart NinjaTrader, or **Tools → New NinjaScript → Compile**.
4. The indicator appears under **PhillyFranksTools** in the indicator picker.

If the importer objects to the markdown files in the archive, extract it by hand and
copy the two `.cs` files into:

```
Documents\NinjaTrader 8\bin\Custom\Indicators\TrendPullbackSignal.cs
Documents\NinjaTrader 8\bin\Custom\Strategies\TrendPullbackB.cs
```

then compile. **Both files must be present** — the strategy will not compile without
the indicator.

---

## Trading it by hand

Put `TrendPullbackSignal` on a 1-minute NQ chart and leave `Preset` on
`VariantB_European`.

When a setup fires you get an arrow, a sound, and a dashed line at the limit price. The
panel tells you exactly what to place:

```
TREND PULLBACK - MANUAL FOLLOW
Variant B - European (03:00-08:00 ET)
Clock 04:12   window 03:00-08:00
Regime Quiet trend
------------------------------------------
WORKING LIMIT - LONG
Valid for THIS BAR ONLY
Limit  24310.25
Stop   24292.00   (18.25 pts)
Target 24346.75   (36.5 pts)
Risk   $365 per contract
------------------------------------------
Setups filled today 1 / 99
No new entry 15:30 ET  -  flat 15:45 ET
YOU place the orders. Nothing here trades.
```

**The limit is live for one bar only.** Place it as a limit order with a one-minute
life, or cancel it at the close of the next bar. Roughly a third of setups never come
back to the limit and are simply skipped — that is the design, not a missed trade. The
system refuses to chase the end of the bar that triggered it.

Once filled, the indicator tracks the trade: stop and target lines, open points, and a
diamond when the simulated bracket resolves. That tracking is a simulation of your
trade, not your actual position — it has no idea what you really did.

### What the markers mean

| Marker | Meaning |
|---|---|
| Arrow up / down | Setup fired on this bar's close |
| Dashed line | The limit price, live for one bar |
| Grey dot | Limit expired unfilled — stand down |
| Solid red / green lines | Stop and target once filled |
| Diamond | Simulated bracket resolved (green target, red stop, gold session flat) |

### Sounds

Three moments can be given a sound, each chosen from the sounds NinjaTrader ships with
(or `Custom`, which plays the file you name in **Custom sound file**). `None` means no
alert is raised for that event at all — it will not appear in your Alerts window either.

| Event | Default | Why you might want it |
|---|---|---|
| Setup armed | `Alert1` | The limit is live and you have one bar to place it |
| Limit filled | `None` | Price reached the limit — the strategy would now be in |
| Limit expired | `None` | It lapsed unfilled. Cancel the order and stand down |

**Enable alerts** is the master switch; off means silence regardless of the three
choices above. The copy of this indicator that the strategy runs internally never
alerts, so you will not hear anything twice.

### Deliberately pessimistic

The simulated tracking is conservative on purpose:

- On the bar the limit fills, **only the stop is checked**. Crediting a target on the
  fill bar is the single most common way a backtest reports profit it never made.
- After that, a bar that touches both the stop and the target is recorded as a **stop**.
- A gap through your limit is filled at the open, in your favour — that part is real.

Your live result should be at least this good and often slightly better.

---

## Running the strategy

For simulation, Market Replay and accounts that are yours. Most funding companies do
not allow a fully automated strategy on an evaluation or funded account — check your
own contract, and when in doubt use the indicator.

The strategy adds what the indicator deliberately does not have:

- order submission and the bracket
- an **account guard**: profit target, trailing drawdown, daily loss limit
- a **target limit exit** — once the profit target is in reach it converts the bracket
  target to the exact price that banks it, as a resting limit. A market flatten cannot
  reliably catch a target line; a measured live attempt triggered at $53,060 and filled
  at $52,921, failing by $79.

### Account mode

Who enforces the account rules — the strategy, or your funding company. One setting with
three values, because Sim and Eval are mutually exclusive.

| Mode | Daily loss limit | Trailing drawdown | Profit target |
|---|---|---|---|
| **Sim** | strategy | strategy | strategy |
| **Eval** | *your provider* | strategy | strategy |
| **Off** | nobody | nobody | nobody |

**Sim** — nothing else is watching a simulation account, so the strategy enforces
everything: it goes flat for the day at the daily loss limit, stops dead at the trailing
drawdown, and stops and banks the profit target.

**Eval** — your provider already stops the account at its own daily loss number, so the
strategy does not duplicate that rule. Duplicating it would only ever stop you *earlier*
than the account requires, on a figure this strategy estimates rather than one your
provider publishes. It still stops at the profit target and still converts the bracket
into a resting limit to bank it.

**Off** — no account limits at all. It trades until you stop it.

The trailing-drawdown check stays live in Sim and Eval both. On an evaluation it is
redundant with the provider's own liquidation, but it can only ever stop trading on an
account that is already finished, so it costs nothing.

### Account guard settings

| Setting | Default | Notes |
|---|---|---|
| Account mode | Sim | Sim / Eval / Off, as above |
| Starting balance ($) | 50000 | Your account's starting balance |
| Profit target ($) | 3000 | Trading stops, terminally, when this is banked |
| Trailing drawdown ($) | 2000 | Threshold = highest end-of-day balance − this |
| Trailing locks at start balance | true | The common "stops trailing once it reaches your start" rule |
| Daily loss limit ($) | 950 | Sim only. **Set it below your provider's hard number**, not equal to it |
| Use target limit exit | true | Resting limit at the exact profit-target price |

The guard can only act on trades **it** placed. It cannot see or stop anything you do by
hand on the same account, and it reads your account's own P&L — put anything else on
that account and the numbers it is working from are not only its own. It is not a
substitute for reading your contract.

---

## The setup, in plain English

1. **Trend.** EMA(20) rising faster than the slope minimum, with price above it (or the
   mirror image, short). Variant A also requires ADX(14) above 25.
2. **Pullback.** Price comes back to within 0.3 × ATR(14) of the level — the EMA, the
   window VWAP, or whichever of the two is further from price, depending on variant.
3. **Trigger.** Variant B takes the touch. Variant A wants a rejection wick that closes
   back on the right side of the level.
4. **Entry.** A limit 25% of the trigger bar's range back inside it. Live for one bar.
5. **Bracket.** Stop = 1.5 × ATR(14), clamped to 15–40 points. Target = stop × 2.
6. **Clock.** No new entry from 15:30 ET. Anything open is flat at 15:45 ET.

### Presets

| Preset | Window (ET) | ADX | Slope | Level | Trigger |
|---|---|---|---|---|---|
| VariantB_European | 03:00–08:00 | off | 0.3 | EMA or VWAP | touch |
| VariantA_Asian | 20:00–01:30 | ≥ 25 | 0.5 | VWAP | rejection |
| VariantA_US | 09:30–15:30 | ≥ 25 | 0.5 | VWAP | rejection |
| Custom | yours | yours | yours | yours | yours |

The European window was cut from 02:00–09:00 to 03:00–08:00 on 25 Aug 2026: the 02:00
hour was the worst block of the day, and the window now opens at the London cash open
and closes before the 08:30 ET US data releases.

**A tuned Custom run is your configuration, not a published one.** The record above
belongs to `VariantB_European` and nothing else.

### Custom hours and bracket

Set `Preset` to `Custom` on the indicator or the strategy and the session window and
bracket become yours. The strategy has a **3. Custom** group for this and hands the values
to the indicator it hosts, so the chart and the strategy still follow one set of rules.
Under any other preset the group is ignored.

| Setting | Default | Notes |
|---|---|---|
| Session start / end (HHMM) | 0300 / 0800 | Read from the chart's clock, so set NinjaTrader to US Eastern |
| Fixed bracket | off | Off: ATR stop with the stop below as its floor, target scaled to it. On: the stop and target below exactly as typed |
| Stop (points) | 15 | The ATR floor, or the exact stop when Fixed bracket is on |
| Target (points) | 30 | With the stop, sets the R multiple; the exact target when Fixed bracket is on |

The other Custom rules (ADX, slope, level, trigger) are on the indicator and start at the
Variant B values.

---

## Things you should know before relying on it

- **The VWAP is not a session VWAP.** It accumulates only on bars inside the entry
  window and resets at midnight, so it is anchored to the first bar of the window. That
  is what produced the results, so it is reproduced exactly. Do not "fix" it.
- **Everything evaluates on bar close.** The indicator forces `Calculate` back to
  `OnBarClose` if you change it, because an intrabar version would show setups that
  vanish as the bar moves.
- **The news blackout is empty and manual.** Event dates move every month, so nothing is
  guessed for you and nothing is downloaded. Fill in `NewsBlackoutHHMM` yourself
  (`0830-0900;1400-1430`) or leave it blank.
- **Max 99 setups per session by default** — effectively no cap. Lower it if you want a
  hard limit on how many times a day you are allowed to be wrong.
- **Nothing in this package fails silently.** Anything that goes wrong prints to the
  NinjaScript Output window (Control Center → New → NinjaScript Output). Look there
  first.

---

## Files

```
Indicators/TrendPullbackSignal.cs   the signal engine + manual display
Strategies/TrendPullbackB.cs        order handling, account guard, clock rules
CLAUDE.md                           working notes for Claude Code
AGENTS.md                           working notes for any coding agent
LICENSE                             MIT
Info.xml                            NinjaTrader import descriptor
```

`CLAUDE.md` and `AGENTS.md` are there for anyone who opens this package in an AI coding
tool. They record the invariants — above all, that the signal rules live in one file and
must never be duplicated into the other.

---

## Risk, licence, and what these numbers are not

MIT licence. See `LICENSE`. Use it, change it, ship it.

**This package generates trade signals, and half of it places live orders.** The
indicator tells you a direction, an entry price, a stop and a target. The strategy sends
real orders to whatever account you attach it to. Both are trade signals in every sense
that matters; treat them that way.

**The pass rate above is simulated, and it is not a track record.** It comes from a
simulated evaluation account filled by NinjaTrader's simulator, not from money at risk.
Simulated fills do not model slippage, queue position, partial fills, rejected orders or
a thin book, and they never miss a fill a real broker would have missed. Results of this
kind are also produced with the benefit of hindsight, over the same period used to
measure them. **No claim is made or implied that any account will achieve results like
these.** The same applies to the simulated outcomes the indicator draws on your chart --
those diamonds are a model of what the rules would have done, not a record of trades
anyone took.

**Most attempts failed.** That is not a footnote, it is the shape of the thing: across
all 43 arena strategies, 88 of 326 attempts passed. Samples this small cannot rank
anything, and none of these rates should be expected to repeat.

**Automation can breach your funding agreement.** Most prop firms restrict or prohibit
fully automated trading on evaluation and funded accounts, and the rule is theirs to
change without telling you. That is why the manual indicator exists. Read your own
contract -- a rule violation can cost you the account whether or not you were profitable.

**The account guard is not a safety net.** It only knows about orders it placed itself.
It cannot see anything you do by hand on the same account, it depends on values you
configure correctly, and like any software it can fail.

**Nothing here is financial advice.** The author is not a registered investment adviser,
commodity trading advisor, or broker, and nothing in this package is a recommendation to
buy or sell anything or a solicitation to trade. It is published for education and
research. Trading futures carries a substantial risk of loss, is not suitable for every
investor, and you can lose more than you deposit. Past performance -- simulated
performance especially -- does not indicate future results.

**You are responsible for every order that reaches the market from your machine**, and
for knowing the rules of whatever account you are trading. Test in simulation first, for
long enough to watch it lose, and never run this on money you cannot afford to lose.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND. See `LICENSE`.
