#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.PhillyFranksTools
{
	public class FloatingBarTimer : Indicator
	{
        protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Floating bar timer for Tick/Minute/Second charts.";
				Name										= "SakuraFloatingBarTimer";
				Calculate									= Calculate.OnEachTick;
				DisplayInDataBox	= false;
				DrawOnPricePanel	= false;
				IsChartOnly			= true;
				IsOverlay			= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive					= true;
				// Variables
				TextFont = new NinjaTrader.Gui.Tools.SimpleFont("Arial", 14);
				TextColor = Brushes.Black;
				MarginToRight = 15;
				HeightMargin = 0;
			}
			else if (State == State.Configure)
			{
			}
		}

		private string periodType;
		private int barMax;
		private Dictionary<string, bool> supportedTimes = new Dictionary<string, bool>()
		{
			{ "Tick", true },
			{ "Minute", true },
			{ "Second", true },
		};
		protected override void OnBarUpdate()
		{
			// Get time frame for chart
			if (CurrentBar == 0)
			{
				string[] chartString = Bars.ToChartString().Split('(');
				string cleanedData = chartString[chartString.Length - 1];
				cleanedData = cleanedData.Remove(cleanedData.Length - 1, 1);
				string[] parsedData = cleanedData.Split(' ');
				if (supportedTimes.ContainsKey(parsedData[1].ToString()))
				{
					periodType = parsedData[1].ToString();
					barMax = Int32.Parse(parsedData[0].ToString());
				}
			}
		}

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			//SETUP
			base.OnRender(chartControl, chartScale);
			if (Bars == null || ChartControl == null)
				return;

			// POSITION LOGIC
			float x = (chartControl.GetXByBarIndex(ChartBars, CurrentBar) + MarginToRight);
			float y = chartScale.GetYByValue((High.GetValueAt(CurrentBar) - ((High.GetValueAt(CurrentBar) - Low.GetValueAt(CurrentBar)) / 2)) + HeightMargin);

			// Setting text to draw
			string text = getDistance(Bars.PercentComplete, Bars.TickCount);

            //DRAW
            DrawTextLayout(
				RenderTarget,
				ChartPanel,
				x,
				y,
				text,
				TextFont,
				TextColor
			);
        }

        private void DrawTextLayout(SharpDX.Direct2D1.RenderTarget renderTarget, ChartPanel chartPanel, float x, float y, string text, SimpleFont font, Brush b)
		{
			SharpDX.Vector2 origin = new SharpDX.Vector2(x, y);
			SharpDX.DirectWrite.TextFormat textFormat = font.ToDirectWriteTextFormat();
			SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory,
														text, textFormat, chartPanel.X + chartPanel.W,
														textFormat.FontSize);
			SharpDX.Direct2D1.Brush dxBrush = b.ToDxBrush(renderTarget);
			
			renderTarget.DrawTextLayout(origin, textLayout, dxBrush);
			textFormat.Dispose();
			textFormat = null;
			textLayout.Dispose();
			textLayout = null;
		}

		private string getDistance(double percent, int tickCount = 0)
		{
			if (periodType == "Tick")
				return (Math.Abs(barMax - tickCount)).ToString();
			else if (periodType == "Second")
				return (Math.Abs(barMax - Math.Floor(barMax * percent))).ToString();
			else if (periodType == "Minute")
			{
				int maxSeconds = barMax * 60;
				int secondsPassed = (int)Math.Floor(maxSeconds * percent);
				int minutesLeft = (maxSeconds - secondsPassed) / 60;
				int secondsLeft = (maxSeconds - secondsPassed) % 60;
				return minutesLeft.ToString() + "m " + secondsLeft.ToString() + "s";
			}
			else return "";
		}

		#region Properties
		[NinjaScriptProperty]
		[XmlIgnore]
        [Display(Name = "Font, size, type, style", Description = "Select font, style, size to display on chart", GroupName = "Text", Order = 1)]
        public NinjaTrader.Gui.Tools.SimpleFont TextFont
        { get; set; }

        [NinjaScriptProperty]
		[XmlIgnore]
        [Display(Name = "Text Color", Description = "Color of text", Order = 2, GroupName = "Text")]
        public Brush TextColor
        { get; set; }
        [Browsable(false)]
        public string TextColorSerialize
        {
            get { return Serialize.BrushToString(TextColor); }
            set { TextColor = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "MarginToRight", Description = "Distance from bar to timer", Order = 3, GroupName = "Display Options")]
		public int MarginToRight
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "HeightMargin", Description = "How far above/below the bar the timer is", Order = 4, GroupName = "Display Options")]
		public float HeightMargin 
		{ get; set; }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PhillyFranksTools.FloatingBarTimer[] cacheFloatingBarTimer;
		public PhillyFranksTools.FloatingBarTimer FloatingBarTimer(NinjaTrader.Gui.Tools.SimpleFont textFont, Brush textColor, int marginToRight, float heightMargin)
		{
			return FloatingBarTimer(Input, textFont, textColor, marginToRight, heightMargin);
		}

		public PhillyFranksTools.FloatingBarTimer FloatingBarTimer(ISeries<double> input, NinjaTrader.Gui.Tools.SimpleFont textFont, Brush textColor, int marginToRight, float heightMargin)
		{
			if (cacheFloatingBarTimer != null)
				for (int idx = 0; idx < cacheFloatingBarTimer.Length; idx++)
					if (cacheFloatingBarTimer[idx] != null && cacheFloatingBarTimer[idx].TextFont == textFont && cacheFloatingBarTimer[idx].TextColor == textColor && cacheFloatingBarTimer[idx].MarginToRight == marginToRight && cacheFloatingBarTimer[idx].HeightMargin == heightMargin && cacheFloatingBarTimer[idx].EqualsInput(input))
						return cacheFloatingBarTimer[idx];
			return CacheIndicator<PhillyFranksTools.FloatingBarTimer>(new PhillyFranksTools.FloatingBarTimer(){ TextFont = textFont, TextColor = textColor, MarginToRight = marginToRight, HeightMargin = heightMargin }, input, ref cacheFloatingBarTimer);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PhillyFranksTools.FloatingBarTimer FloatingBarTimer(NinjaTrader.Gui.Tools.SimpleFont textFont, Brush textColor, int marginToRight, float heightMargin)
		{
			return indicator.FloatingBarTimer(Input, textFont, textColor, marginToRight, heightMargin);
		}

		public Indicators.PhillyFranksTools.FloatingBarTimer FloatingBarTimer(ISeries<double> input , NinjaTrader.Gui.Tools.SimpleFont textFont, Brush textColor, int marginToRight, float heightMargin)
		{
			return indicator.FloatingBarTimer(input, textFont, textColor, marginToRight, heightMargin);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PhillyFranksTools.FloatingBarTimer FloatingBarTimer(NinjaTrader.Gui.Tools.SimpleFont textFont, Brush textColor, int marginToRight, float heightMargin)
		{
			return indicator.FloatingBarTimer(Input, textFont, textColor, marginToRight, heightMargin);
		}

		public Indicators.PhillyFranksTools.FloatingBarTimer FloatingBarTimer(ISeries<double> input , NinjaTrader.Gui.Tools.SimpleFont textFont, Brush textColor, int marginToRight, float heightMargin)
		{
			return indicator.FloatingBarTimer(input, textFont, textColor, marginToRight, heightMargin);
		}
	}
}

#endregion
